#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <linux/tcp.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <getopt.h>

#define VER "0.9b"

struct phdr {
  unsigned long int saddr,daddr;
  char wee,protocol;
  unsigned short tcplen;
};

struct ohfuck {
  unsigned long int saddr;
  struct ohfuck *next;
};
struct ohfuck *maina=NULL,*curr=NULL;

u_short cksum(u_short *buf, int nwords);
unsigned long int res(char *p);
unsigned short fport,tport=139;


void gonow(char *lip, char *net, char *file, unsigned short port, char bflag);
int scan(char *rip,  char *file, unsigned long int lip, unsigned short port);
void dol(char *f,char *s);
void adds(unsigned int long saddr);
void delsa();
                                                                                                        
void syntax(char *wee)
{
  printf("%s -d 194.23.4.x -o filename.txt -b\n",wee);
  printf("Would scan 194.23.4.* for 95 or NT and put the result in filename.txt\n");
  printf("compile batmaker.c to make a windows bat file that will connect all machines found pronto!\n");
  exit(-3);
}

void main(argc,argv)
int argc;
char **argv;
{
  char i,bflag=0,lip[512],net[512],file[512];
  unsigned short port=139;
  
  printf("Winhacker %s - ShhhhhiT - WinhackGold '98\n\n",VER);
  bzero(&file,1024);  
  gethostname(lip,512);
  while((i=getopt(argc,argv,"o:d:p:l:bh?")) != -1) {
    switch(i) {
      case 'b':
        bflag=1;
        break;
      case 'p':
        port=atoi(optarg);
        break;
      case '?':
      case 'h':
        syntax(argv[0]);
      case 'l':
        strcpy(lip,optarg);
        break;
      case 'd':
        strcpy(net,optarg);
        break;
      case 'o':
        strcpy(file,optarg);
        break;
      default:
        syntax(argv[0]);
    }
  }
  if(!net[0] || (bflag && !file[0]))
    syntax(argv[0]);  

  if(geteuid()!=0)
    printf("User luser detected\n"),exit(-4);
    
  if(bflag)
    if(fork()>0)
      exit(0);
  if(file[0])
    unlink(file);
  srand(time(NULL)+getpid());
  fport=htons(rand());
  gonow(lip,net,file,port,bflag);
}

void gonow(char *lip, char *net, char *file, unsigned short port, char bflag)
{
  unsigned long int damdidam;
  
  damdidam=res(lip);
  if(damdidam<0) {
    if(!bflag)
      printf("Can't resolve %s!\n",lip);
    exit(-2);
  }
  scan(net,file,damdidam,port);  
}

unsigned long int res(char *p)
{
  struct hostent *h;
  unsigned long int rv;

  h=gethostbyname(p);
  if(h!=NULL)
    memcpy(&rv,h->h_addr,h->h_length);
  else
    rv=inet_addr(p);
  return rv;
}

/*
 * 150% optimized
 * <GRIN>
 */

int scan(char *net, char *file, unsigned long int lip, unsigned short port)
{
  char   ba[512];
  struct tcphdr tr;
  struct iphdr ir;
  
  struct tcphdr t;
  struct iphdr i;
  struct phdr p;
  struct sockaddr_in sin;
  char   buf[32];
  int    sock,sockr;
  unsigned short dp,sp;
  struct in_addr in;

  char ib[512],*to[6];
  int j,ch;
  unsigned char a,b,c,d;
  unsigned char aa,bb,cc;
  unsigned char ob,oc;
  
  strcpy(ib,net);

  to[j=0]=strtok(ib,".");
  while(1)
  {
    to[++j]=strtok(NULL,".");
    if(!to[j] || j>5)
      break;
  }
  to[j]=NULL;
  if(*to[0] == 'x')
    aa=255,a=0;
  else 
    a=atoi(to[0]),aa=a+1;
  
  if(*to[1] == 'x')
    bb=255,b=0;
  else 
    b=atoi(to[1]),bb=b+1;
  
  if(*to[2] == 'x')
    cc=255,c=0;
  else 
    c=atoi(to[2]),cc=c+1;
  
  ob=b;
  oc=c;
  
  sock=socket(AF_INET,SOCK_RAW,255);
  bzero(&p,52);
  bzero(&sin,sizeof(sin));
  
  i.ihl=5;
  i.version=4;
  i.ttl=255;
  i.protocol=6;
  i.tot_len=htons(40);
  i.saddr=lip;
  
  t.syn=1;
  t.doff=5;
  t.window=htons(512);
  t.dest=htons(port);
  t.source=fport;
  
  p.saddr=i.saddr;
  p.protocol=6;
  p.tcplen=htons(20);
  
  sin.sin_family=AF_INET;
  sin.sin_port=htons(port);

  dp=t.source;sp=t.dest;
  if((ch=fork())!=0) {
    for(;a<aa;a++) 
      for(b=ob;b<bb;b++) 
        for(c=oc;c<cc;c++) 
          for(j=1;j<255;j++) {
            bzero(&ib,sizeof(ib));
            sprintf(ib,"%d.%d.%d.%d",a,b,c,j);
            i.daddr=inet_addr(ib);
            i.check=0;
            i.check=cksum((u_short *)&i,20>>1);
            p.daddr=i.daddr;
            t.check=0;
            memcpy(buf,&p,12);
            memcpy(buf+12,&t,20);
            t.check=cksum((u_short *)buf,32>>1);
            sin.sin_addr.s_addr=i.daddr;
            sendto(sock,&i,40,0,(struct sockaddr *)&sin,sizeof(sin));
            usleep(1);
          }
    sleep(5);
    kill(ch,9);
    return;
  }
  sockr=socket(AF_INET,SOCK_RAW,6);
      
  while(1)
  {
    read(sockr,&ir,40);
    if(tr.dest == dp && tr.source == sp) {
      if(tr.ack && tr.syn) {
        if(!isin(ir.saddr)) {
          memcpy(&in,&ir.saddr,sizeof(ir.saddr));
          if(file[0])
            dol(file,inet_ntoa(in));
          else
            printf("%s\n",inet_ntoa(in));
          adds(ir.saddr); 
        }
      }
    }
  }
  close(sock);close(sockr);
  delsa();
  exit(0);
}

void adds(unsigned int long saddr)
{
  struct ohfuck *a;
  
  a=malloc(sizeof(struct ohfuck));  
  a->saddr=saddr;
  if(maina==NULL) {
    maina=a;
    curr=a;
  }
  else {
    curr->next=a;
    curr=a;
  }
  a->next=NULL;
}

void delsa()
{
  struct ohfuck *a,*b;
  
  a=maina;
  while(a!=NULL) 
  {
    b=a->next;
    free(a);
    a=b;
  }
  maina=NULL;
}

int isin(unsigned long int saddr)
{
  struct ohfuck *a;
  
  a=maina;
  while(a!=NULL)
  {
    if(a->saddr==saddr)
      return 1;
    a=a->next;
  }
  return 0;
}

u_short cksum(u_short *buf, int nwords) {
        unsigned long sum;

        for ( sum = 0; nwords > 0; nwords -- )
                sum += *buf++;
        sum = ( sum >> 16) + ( sum & 0xffff );
        sum += ( sum >> 16 );
        return ~sum ;
}

void dol(char *f,char *s)
{
  FILE *a;
  char b[512];
  
  sprintf(b,"%s\n",s);
  a=fopen(f,"a");
  fputs(b,a);
  fclose(a);
}
